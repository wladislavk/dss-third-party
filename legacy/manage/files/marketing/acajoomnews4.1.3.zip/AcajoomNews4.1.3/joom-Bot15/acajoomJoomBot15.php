<?php
defined('_JEXEC') OR defined('_VALID_MOS') OR die('...Direct Access to this location is not allowed...');
global $mainframe;
### Copyright (C) 2006-2009 Acajoom Services. All rights reserved.
### http://www.ijoobi.com/index.php?option=com_content&view=article&id=12&Itemid=54

$mainframe->registerEvent( 'acajoombot_transformall', 'acajoombot_compatibility' );

 function acajoombot_compatibility($html, $text) {
	global  $mainframe;

	$row->title = 'Fake content';
	$row->introtext = '';
	$row->fulltext = $html;
	$row->images = '';
	$row->attribs = 'pageclass_sfx=';
	$row->state=1;
	$row->created_by=62;
	$row->text = $html;
	$row->mask = 0;
	$row->checked_out = 0;
	$row->id = 0;
	$row->section = 0;
	$row->catid = 0;

	JPluginHelper::importPlugin( 'content' );
	$bot_results = $mainframe->triggerEvent( 'onPrepareContent', array( &$row, &$params, 0 ), true );

	$html = $row->text;

	$row->fulltext = $text;
	$row->text = $text;
	$bot_results = $mainframe->triggerEvent( 'onPrepareContent', array( &$row, &$params, 0 ), true );
	$text = $row->text;
 }
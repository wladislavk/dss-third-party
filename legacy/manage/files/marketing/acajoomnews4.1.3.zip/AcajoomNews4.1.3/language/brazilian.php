<?php
if ( !defined('_JEXEC') && defined('_VALID_MOS') ) define( '_JEXEC', true );
 defined('_JEXEC') or die('...Direct Access to this location is not allowed...');

/**
 * <p>Potuguese language.</p>
 * @copyright (c) 2006 Acajoom Services / All Rights Reserved
 * @author  Ricardo Simões <support@acajoom.com>
 * @version $Id: brazilian.php 442 2007-01-07 11:52:33Z divivo $
 * @link http://www.acajoom.com
 */

/**
 * <p>Tradução Português Brasil.</p>
 * @copyright (c) 2006 Acajoom Services / All Rights Reserved
 * @author  Jorgito Inocencio Santos <jorgito@riodasostras.net>
 * @version $Id: brazilian_portuguese.php 442 2008-11-24 23:40:33
 * @link http://www.riodasostras.net
 */

### General ###
 //acajoom Description
define('_ACA_DESC_NEWS', compa::encodeutf('Acajoom é uma ferramenta de listas de mailing, envio de informativos, auto-respostas, e seguimento, para comunicação eficaz com os seus usuários e clientes. ' .
		'Acajoom, O Seu Parceiro De Comunicação!'));
define('_ACA_FEATURES', compa::encodeutf('Acajoom, o seu parceiro de comunicação!'));

// Type of lists
define('_ACA_NEWSLETTER', compa::encodeutf('Informativo'));
define('_ACA_AUTORESP', compa::encodeutf('Auto-resposta'));
define('_ACA_AUTORSS', compa::encodeutf('Auto-RSS'));
define('_ACA_ECARD', compa::encodeutf('Cartão Eletrônico'));
define('_ACA_POSTCARD', compa::encodeutf('Cartão Postal'));
define('_ACA_PERF', compa::encodeutf('Performance'));
define('_ACA_COUPON', compa::encodeutf('Cupon'));
define('_ACA_CRON', compa::encodeutf('Tarefa Agendada'));
define('_ACA_MAILING', compa::encodeutf('Mailing'));
define('_ACA_LIST', compa::encodeutf('Lista'));

 //acajoom Menu
define('_ACA_MENU_LIST', compa::encodeutf('Gestão de Listas'));
define('_ACA_MENU_SUBSCRIBERS', compa::encodeutf('Assinantes'));
define('_ACA_MENU_NEWSLETTERS', compa::encodeutf('Informativos'));
define('_ACA_MENU_AUTOS', compa::encodeutf('Auto-Respostas'));
define('_ACA_MENU_COUPONS', compa::encodeutf('Cupons'));
define('_ACA_MENU_CRONS', compa::encodeutf('Tarefas Agendadas'));
define('_ACA_MENU_AUTORSS', compa::encodeutf('Auto-RSS'));
define('_ACA_MENU_ECARD', compa::encodeutf('Cartões Eletrônicos'));
define('_ACA_MENU_POSTCARDS', compa::encodeutf('Cartões Postais'));
define('_ACA_MENU_PERFS', compa::encodeutf('Performances'));
define('_ACA_MENU_TAB_LIST', compa::encodeutf('Listas'));
define('_ACA_MENU_MAILING_TITLE', compa::encodeutf('Mailings'));
define('_ACA_MENU_MAILING', compa::encodeutf('Mailings para '));
define('_ACA_MENU_STATS', compa::encodeutf('Estatísticas'));
define('_ACA_MENU_STATS_FOR', compa::encodeutf('Estatísticas para '));
define('_ACA_MENU_CONF', compa::encodeutf('Configuração'));
define('_ACA_MENU_UPDATE', compa::encodeutf('Importar'));
define('_ACA_MENU_ABOUT', compa::encodeutf('Sobre'));
define('_ACA_MENU_LEARN', compa::encodeutf('Centro de Educação'));
define('_ACA_MENU_MEDIA', compa::encodeutf('Gestão de Media'));
define('_ACA_MENU_HELP', compa::encodeutf('Ajuda'));
define('_ACA_MENU_CPANEL', compa::encodeutf('Painel de Controle'));
define('_ACA_MENU_IMPORT', compa::encodeutf('Importar'));
define('_ACA_MENU_EXPORT', compa::encodeutf('Exportar'));
define('_ACA_MENU_SUB_ALL', compa::encodeutf('Inscrever Tudo'));
define('_ACA_MENU_UNSUB_ALL', compa::encodeutf('Não-Inscrever Tudo'));
define('_ACA_MENU_VIEW_ARCHIVE', compa::encodeutf('Arquivo'));
define('_ACA_MENU_PREVIEW', compa::encodeutf('Pré-visualizar'));
define('_ACA_MENU_SEND', compa::encodeutf('Enviar'));
define('_ACA_MENU_SEND_TEST', compa::encodeutf('Enviar Email de Teste'));
define('_ACA_MENU_SEND_QUEUE', compa::encodeutf('Fila de Processamento'));
define('_ACA_MENU_VIEW', compa::encodeutf('Ver'));
define('_ACA_MENU_COPY', compa::encodeutf('Copiar'));
define('_ACA_MENU_VIEW_STATS', compa::encodeutf('Ver Estado'));
define('_ACA_MENU_CRTL_PANEL', compa::encodeutf(' Painel De Controle'));
define('_ACA_MENU_LIST_NEW', compa::encodeutf(' Criar Lista'));
define('_ACA_MENU_LIST_EDIT', compa::encodeutf(' Editar Lista'));
define('_ACA_MENU_BACK', compa::encodeutf('Retroceder'));
define('_ACA_MENU_INSTALL', compa::encodeutf('Instalar'));
define('_ACA_MENU_TAB_SUM', compa::encodeutf('Sumário'));
define('_ACA_STATUS', compa::encodeutf('Estado'));

// messages
define('_ACA_ERROR', compa::encodeutf(' Ocorreu um erro! '));
define('_ACA_SUB_ACCESS', compa::encodeutf('Direitos de Acesso'));
define('_ACA_DESC_CREDITS', compa::encodeutf('Créditos'));
define('_ACA_DESC_INFO', compa::encodeutf('Informação'));
define('_ACA_DESC_HOME', compa::encodeutf('Página Oficial'));
define('_ACA_DESC_MAILING', compa::encodeutf('Lista de Mailing'));
define('_ACA_DESC_SUBSCRIBERS', compa::encodeutf('Assinantes'));
define('_ACA_PUBLISHED', compa::encodeutf('Publicado'));
define('_ACA_UNPUBLISHED', compa::encodeutf('Não-Publicado'));
define('_ACA_DELETE', compa::encodeutf('Apagar'));
define('_ACA_FILTER', compa::encodeutf('Filtrar'));
define('_ACA_UPDATE', compa::encodeutf('Atualizar'));
define('_ACA_SAVE', compa::encodeutf('Salvar'));
define('_ACA_CANCEL', compa::encodeutf('Cancelar'));
define('_ACA_NAME', compa::encodeutf('Nome'));
define('_ACA_EMAIL', compa::encodeutf('E-mail'));
define('_ACA_SELECT', compa::encodeutf('Selecionar'));
define('_ACA_ALL', compa::encodeutf('Todas as'));
define('_ACA_SEND_A', compa::encodeutf('Enviar a '));
define('_ACA_SUCCESS_DELETED', compa::encodeutf(' apagado com sucesso'));
define('_ACA_LIST_ADDED', compa::encodeutf('Lista criada com sucesso'));
define('_ACA_LIST_COPY', compa::encodeutf('Lista copiada com sucesso'));
define('_ACA_LIST_UPDATED', compa::encodeutf('Lista atualizada com sucesso'));
define('_ACA_MAILING_SAVED', compa::encodeutf('Mailing salvado com sucesso.'));
define('_ACA_UPDATED_SUCCESSFULLY', compa::encodeutf('atualizado com sucesso.'));

### Subscribers information ###
//subscribe and unsubscribe info
define('_ACA_SUB_INFO', compa::encodeutf('Informação do Assinante'));
define('_ACA_VERIFY_INFO', compa::encodeutf('Por favor verifique o link que submeteu, falta alguma informação.'));
define('_ACA_INPUT_NAME', compa::encodeutf('Nome'));
define('_ACA_INPUT_EMAIL', compa::encodeutf('E-mail'));
define('_ACA_RECEIVE_HTML', compa::encodeutf('Receber em HTML?'));
define('_ACA_TIME_ZONE', compa::encodeutf('Zona de Fuso-Horário'));
define('_ACA_BLACK_LIST', compa::encodeutf('Lista Negra'));
define('_ACA_REGISTRATION_DATE', compa::encodeutf('Data de registo do usuário'));
define('_ACA_USER_ID', compa::encodeutf('ID do Usuário'));
define('_ACA_DESCRIPTION', compa::encodeutf('Descrição'));
define('_ACA_ACCOUNT_CONFIRMED', compa::encodeutf('A sua conta foi ativada.'));
define('_ACA_SUB_SUBSCRIBER', compa::encodeutf('Assinante'));
define('_ACA_SUB_PUBLISHER', compa::encodeutf('Editor'));
define('_ACA_SUB_ADMIN', compa::encodeutf('Administrador'));
define('_ACA_REGISTERED', compa::encodeutf('Registrado'));
define('_ACA_SUBSCRIPTIONS', compa::encodeutf('Inscrições'));
define('_ACA_SEND_UNSUBCRIBE', compa::encodeutf('Enviar mensagem de Cancelamento de Subscrição'));
define('_ACA_SEND_UNSUBCRIBE_TIPS', compa::encodeutf('Clique SIM para enviar um email de confirmação para cancelamento da inscrição.'));
define('_ACA_SUBSCRIBE_SUBJECT_MESS', compa::encodeutf('Por favor confirme a sua inscrição'));
define('_ACA_UNSUBSCRIBE_SUBJECT_MESS', compa::encodeutf('Confirmação de Cancelamento de Inscricrição'));
define('_ACA_DEFAULT_SUBSCRIBE_MESS', compa::encodeutf('Olá [NAME],<br />' .
		'Apenas mais um passo e se inscreverá na lista.  Por favor clique no link seguinte para confirmar a sua inscrição.' .
		'<br /><br />[CONFIRM]<br /><br />Para estas questões, favor contactar o Webmaster.'));
define('_ACA_DEFAULT_UNSUBSCRIBE_MESS', compa::encodeutf('Este é um e-mail de confirmação de que você foi removido da nossa lista. Lamentamos que tenha decidido cancelar a sua inscrição, caso queira voltar a se inscrever, faça pelo no nosso site.  Caso tenha alguma dúvida, por favor contacte o nosso Webmaster.'));

// Acajoom subscribers
define('_ACA_SIGNUP_DATE', compa::encodeutf('Data de Inscrição'));
define('_ACA_CONFIRMED', compa::encodeutf('Confirmado'));
define('_ACA_SUBSCRIB', compa::encodeutf('Inscrever'));
define('_ACA_HTML', compa::encodeutf('Mailings em HTML'));
define('_ACA_RESULTS', compa::encodeutf('Resultados'));
define('_ACA_SEL_LIST', compa::encodeutf('Selecione uma Lista'));
define('_ACA_SEL_LIST_TYPE', compa::encodeutf('- Selecione Tipo de Lista -'));
define('_ACA_SUSCRIB_LIST', compa::encodeutf('Lista Total de Assinantes'));
define('_ACA_SUSCRIB_LIST_UNIQUE', compa::encodeutf('assinantes para : '));
define('_ACA_NO_SUSCRIBERS', compa::encodeutf('Nenhum assinante encontrado para esta(s) lista(s).'));
define('_ACA_COMFIRM_SUBSCRIPTION', compa::encodeutf('Foi enviado um e-mail de confirmação para você.  Por favor verifique o seu e-mail e clique no link fornecido.<br />' .
		'O seu e-mail necessita ser confirmado para que a sua inscrição possa ter efeito.'));
define('_ACA_SUCCESS_ADD_LIST', compa::encodeutf('Você foi adicionado a lista com sucesso.'));


 // Subcription info
define('_ACA_CONFIRM_LINK', compa::encodeutf('Clique aqui para confirmar a sua inscrição'));
define('_ACA_UNSUBSCRIBE_LINK', compa::encodeutf('Clique aqui para remover-se da lista'));
define('_ACA_UNSUBSCRIBE_MESS', compa::encodeutf('O seu e-mail foi removido da lista'));

define('_ACA_QUEUE_SENT_SUCCESS', compa::encodeutf('Todos os mailings agendados foram enviados com sucesso.'));
define('_ACA_MALING_VIEW', compa::encodeutf('Ver todos os mailings'));
define('_ACA_UNSUBSCRIBE_MESSAGE', compa::encodeutf('Tem a certeza que quer remover-se da lista?'));
define('_ACA_MOD_SUBSCRIBE', compa::encodeutf('Inscrever'));
define('_ACA_SUBSCRIBE', compa::encodeutf('Inscrever'));
define('_ACA_UNSUBSCRIBE', compa::encodeutf('Desinscrever'));
define('_ACA_VIEW_ARCHIVE', compa::encodeutf('Ver arquivo'));
define('_ACA_SUBSCRIPTION_OR', compa::encodeutf(' ou clique aqui para atualizar a sua informação'));
define('_ACA_EMAIL_ALREADY_REGISTERED', compa::encodeutf('Este endereço de e-mail já se encontra registrado. Favor averiguar.'));
define('_ACA_SUBSCRIBER_DELETED', compa::encodeutf('Assinante apagado com sucesso.'));


### UserPanel ###
 //User Menu
define('_UCP_USER_PANEL', compa::encodeutf('Painel de Controle do Usuário'));
define('_UCP_USER_MENU', compa::encodeutf('Menu do Usuário'));
define('_UCP_USER_CONTACT', compa::encodeutf('As minhas inscrições'));
 //Acajoom Cron Menu
define('_UCP_CRON_MENU', compa::encodeutf('Gestão de tarefa agendada'));
define('_UCP_CRON_NEW_MENU', compa::encodeutf('Novo agendamento'));
define('_UCP_CRON_LIST_MENU', compa::encodeutf('Listar o meu agendamento'));
 //Acajoom Coupon Menu
define('_UCP_COUPON_MENU', compa::encodeutf('Gestão de Cupons'));
define('_UCP_COUPON_LIST_MENU', compa::encodeutf('Lista de Cupons'));
define('_UCP_COUPON_ADD_MENU', compa::encodeutf('Adicionar um Cupon'));

### lists ###
// Tabs
define('_ACA_LIST_T_GENERAL', compa::encodeutf('Descrição'));
define('_ACA_LIST_T_LAYOUT', compa::encodeutf('Layout'));
define('_ACA_LIST_T_SUBSCRIPTION', compa::encodeutf('Inscrição'));
define('_ACA_LIST_T_SENDER', compa::encodeutf('Informação do Remetente'));

define('_ACA_LIST_TYPE', compa::encodeutf('Tipo de Lista'));
define('_ACA_LIST_NAME', compa::encodeutf('Nome da Lista'));
define('_ACA_LIST_ISSUE', compa::encodeutf('Edição N #'));
define('_ACA_LIST_DATE', compa::encodeutf('Data de Envio'));
define('_ACA_LIST_SUB', compa::encodeutf('Assunto do Mailing'));
define('_ACA_ATTACHED_FILES', compa::encodeutf('Arquivos Anexados'));
define('_ACA_SELECT_LIST', compa::encodeutf('Por favor selecione uma lista para editar!'));

// Auto Responder box
define('_ACA_AUTORESP_ON', compa::encodeutf('Tipo de Lista'));
define('_ACA_AUTO_RESP_OPTION', compa::encodeutf('Opções de Auto-resposta'));
define('_ACA_AUTO_RESP_FREQ', compa::encodeutf('Assinantes podem escolher a frequência'));
define('_ACA_AUTO_DELAY', compa::encodeutf('Atraso (em dias)'));
define('_ACA_AUTO_DAY_MIN', compa::encodeutf('Frequência Mínima'));
define('_ACA_AUTO_DAY_MAX', compa::encodeutf('Frequência Máxima'));
define('_ACA_FOLLOW_UP', compa::encodeutf('Especificar seguimento de auto-resposta'));
define('_ACA_AUTO_RESP_TIME', compa::encodeutf('Assinantes podem escolher hora'));
define('_ACA_LIST_SENDER', compa::encodeutf('Remetente da Lista'));

define('_ACA_LIST_DESC', compa::encodeutf('Descrição da Lista'));
define('_ACA_LAYOUT', compa::encodeutf('Layout'));
define('_ACA_SENDER_NAME', compa::encodeutf('Nome do Remetente'));
define('_ACA_SENDER_EMAIL', compa::encodeutf('E-mail do Remetente'));
define('_ACA_SENDER_BOUNCE', compa::encodeutf('Endereço de bounce do Remetente'));
define('_ACA_LIST_DELAY', compa::encodeutf('Atraso'));
define('_ACA_HTML_MAILING', compa::encodeutf('Mailing em HTML?'));
define('_ACA_HTML_MAILING_DESC', compa::encodeutf('(se modificar isto, você terá de salvar e retornar a esta tela para visualizar as mudanças.)'));
define('_ACA_HIDE_FROM_FRONTEND', compa::encodeutf('Esconder do Síte-Principal?'));
define('_ACA_SELECT_IMPORT_FILE', compa::encodeutf('Selecione um arquivo para importação'));;
define('_ACA_IMPORT_FINISHED', compa::encodeutf('Importação terminada'));
define('_ACA_DELETION_OFFILE', compa::encodeutf('Eliminação do arquivo'));
define('_ACA_MANUALLY_DELETE', compa::encodeutf('falhou, deverá apagar o arquivo manualmente'));
define('_ACA_CANNOT_WRITE_DIR', compa::encodeutf('Não é possível escrever no diretório. Favor verificar permissões!'));
define('_ACA_NOT_PUBLISHED', compa::encodeutf('Não foi possível enviar o mailing, a Lista não está publicada.'));

//  List info box
define('_ACA_INFO_LIST_PUB', compa::encodeutf('Clique em SIM para publicar a Lista'));
define('_ACA_INFO_LIST_NAME', compa::encodeutf('Introduza o nome da sua Lista aqui. Poderá identificar a Lista com este nome.'));
define('_ACA_INFO_LIST_DESC', compa::encodeutf('Introduza uma breve descrição da sua Lista aqui. Esta descrição será visível aos visitantes no seu site.'));
define('_ACA_INFO_LIST_SENDER_NAME', compa::encodeutf('Introduza o nome do Remetente do mailing. Este nome será visível quando os assinantes receberem mensagens desta lista.'));
define('_ACA_INFO_LIST_SENDER_EMAIL', compa::encodeutf('Introduza o endereço de e-mail de onde as mensagens serão enviadas.'));
define('_ACA_INFO_LIST_SENDER_BOUNCED', compa::encodeutf('Introduza o endereço de e-mail para onde os usuários poderão responder. É altamente recomendado que seja igual ao do remetente, visto que existem filtros de SPAM que poderão atribuir uma probabilidade de SPAM elevada se forem diferentes.'));
define('_ACA_INFO_LIST_AUTORESP', compa::encodeutf('Escolha o tipo de mailings para esta Lista. <br />' .
		'Informativo: informativo normal<br />' .
		'Auto-resposta: uma Auto-resposta é uma Lista que é enviada automaticamente através da página web em intervalos regulares.'));
define('_ACA_INFO_LIST_FREQUENCY', compa::encodeutf('Permitir aos usuários escolher quantas vezes recebem a Lista. Atribui mais flexibilidade ao usuário.'));
define('_ACA_INFO_LIST_TIME', compa::encodeutf('Deixar que o usuário escolha a hora do dia que ele prefere receber a Lista.'));
define('_ACA_INFO_LIST_MIN_DAY', compa::encodeutf('Definir qual é a frequência mínima que o usuário pode escolher para receber a lista'));
define('_ACA_INFO_LIST_DELAY', compa::encodeutf('Especificar qual o atraso entre esta auto-resposta e a anterior.'));
define('_ACA_INFO_LIST_DATE', compa::encodeutf('Especificar a data para publicação da lista de notícias, caso queira atrasar a publicação. <br /> FORMATO : AAAA-MM-DD HH:MM:SS'));
define('_ACA_INFO_LIST_MAX_DAY', compa::encodeutf('Definir qual é a frequência máxima que o usuário pode escolher para receber a lista'));
define('_ACA_INFO_LIST_LAYOUT', compa::encodeutf('Introduza o layout da sua lista de mailing aqui. Pode introduzir qualquer layou para o seu mailing aqui.'));
define('_ACA_INFO_LIST_SUB_MESS', compa::encodeutf('Esta mensagem será enviada ao assinante quando ele ou ela se registam pela primeira vez. Pode definir aqui qualquer texto que goste.'));
define('_ACA_INFO_LIST_UNSUB_MESS', compa::encodeutf('Esta mensagem será enviada ao assinante quando ele ou ela cancelarem a subscrição. Pode inserir aqui qualquer mensagem.'));
define('_ACA_INFO_LIST_HTML', compa::encodeutf('Selecione se desejar enviar mailing em HTML. Os assinantes poderão especificar se preferem receber mensagens em HTML, ou mensagens de apenas texto aquando da subscrição de uma lista HTML.'));
define('_ACA_INFO_LIST_HIDDEN', compa::encodeutf('Clique SIM para esconder a lista do sítio-principal, os usuários não poderão subscrever mas você poderá mesmo assim enviar mailings.'));
define('_ACA_INFO_LIST_ACA_AUTO_SUB', compa::encodeutf('Deseja subscrição automática dos usuários para esta lista?<br /><B>Novos Utilizadores:</B> registará cada novo usuário que se registe no site.<br /><B>Todos os Utilizadores:</B> registará cada usuário registado na base de dados.<br />(todas aquelas opções suportam Community Builder)'));
define('_ACA_INFO_LIST_ACC_LEVEL', compa::encodeutf('Selecione o nível de acesso do sítio-principal. Isto mostrará ou esconderá o mailing para os grupos de usuários que não têm acesso a ele, para que não sejam capazes do o subscrever.'));
define('_ACA_INFO_LIST_ACC_USER_ID', compa::encodeutf('Selecione o nível de acesso do grupo de usuários a quem permite edição. Esse grupo de usuários e superiores serão capazes de editar o mailing e enviá-lo, quer do sítio-principal quer do sítio de administração.'));
define('_ACA_INFO_LIST_FOLLOW_UP', compa::encodeutf('Se quiser que a auto-resposta mova-se para outra assim que atingir a última mensagem, pode especificar aqui a auto-resposta seguinte.'));
define('_ACA_INFO_LIST_ACA_OWNER', compa::encodeutf('Esta é a ID da pessoa que criou a lista.'));
define('_ACA_INFO_LIST_WARNING', compa::encodeutf(' Esta última opção apenas está disponível uma vez aquando da criação da lista.'));
define('_ACA_INFO_LIST_SUBJET', compa::encodeutf(' Assunto do mailing.  Este é o assunto do e-mail que o assinante receberá.'));
define('_ACA_INFO_MAILING_CONTENT', compa::encodeutf('Este é o corpo do e-mail que você quer enviar.'));
define('_ACA_INFO_MAILING_NOHTML', compa::encodeutf('Introduza o corpo do e-mail que você quer enviar para os assinantes que escolheram receber apenas mailings NÃO-HTML. <BR/> NOTA: se deixar em branco o Acajoom converterá automaticamente o texto HTML para apenas texto.'));
define('_ACA_INFO_MAILING_VISIBLE', compa::encodeutf('Clique SIM para mostrar mailing no sítio-principal.'));
define('_ACA_INSERT_CONTENT', compa::encodeutf('Insira o conteúdo existente'));

// Coupons
define('_ACA_SEND_COUPON_SUCCESS', compa::encodeutf('Cupon enviado com sucesso!'));
define('_ACA_CHOOSE_COUPON', compa::encodeutf('Escolha um cupon'));
define('_ACA_TO_USER', compa::encodeutf(' para este usuário'));

### Cron options
//drop down frequency(CRON)
define('_ACA_FREQ_CH1', compa::encodeutf('Cada hora'));
define('_ACA_FREQ_CH2', compa::encodeutf('Cada 6 horas'));
define('_ACA_FREQ_CH3', compa::encodeutf('Cada 12 horas'));
define('_ACA_FREQ_CH4', compa::encodeutf('Diariamente'));
define('_ACA_FREQ_CH5', compa::encodeutf('Semanalmente'));
define('_ACA_FREQ_CH6', compa::encodeutf('Mensalmente'));
define('_ACA_FREQ_NONE', compa::encodeutf('Não'));
define('_ACA_FREQ_NEW', compa::encodeutf('Novos usuários'));
define('_ACA_FREQ_ALL', compa::encodeutf('Todos os usuários'));

//Label CRON form
define('_ACA_LABEL_FREQ', compa::encodeutf('Agendar Acajoom?'));
define('_ACA_LABEL_FREQ_TIPS', compa::encodeutf('Clique em SIM se quiser utilizar isto para uma agenda Acajoom, NÃO para qualquer outra tarefa agendada.<br />' .
		'Se clicar em SIM não necessita de especificar o endereço da agenda, este será automaticamente adicionado.'));
define('_ACA_SITE_URL', compa::encodeutf('O endereço URL do seu site'));
define('_ACA_CRON_FREQUENCY', compa::encodeutf('Frequência da Agenda'));
define('_ACA_STARTDATE_FREQ', compa::encodeutf('Data de Início'));
define('_ACA_LABELDATE_FREQ', compa::encodeutf('Especifique a Data'));
define('_ACA_LABELTIME_FREQ', compa::encodeutf('Especifique a Hora'));
define('_ACA_CRON_URL', compa::encodeutf('URL da Agenda'));
define('_ACA_CRON_FREQ', compa::encodeutf('Frequência'));
define('_ACA_TITLE_CRONLIST', compa::encodeutf('Lista de Agenda'));
define('_NEW_LIST', compa::encodeutf('Criar uma nova lista'));

//title CRON form
define('_ACA_TITLE_FREQ', compa::encodeutf('Editar Agenda'));
define('_ACA_CRON_SITE_URL', compa::encodeutf('Por favor introduza um endereço URL válido, começado por http://'));

### Mailings ###
define('_ACA_MAILING_ALL', compa::encodeutf('Todos os mailings'));
define('_ACA_EDIT_A', compa::encodeutf('Editar um '));
define('_ACA_SELCT_MAILING', compa::encodeutf('Por favor selecione a Lista na caixa de possibilidades com vista a adicionar um novo mailing.'));
define('_ACA_VISIBLE_FRONT', compa::encodeutf('Visível no página principal'));

// mailer
define('_ACA_SUBJECT', compa::encodeutf('Assunto'));
define('_ACA_CONTENT', compa::encodeutf('Conteúdo'));
define('_ACA_NAMEREP', compa::encodeutf('[NAME] = Isto será substituído pelo nome que o assinante introduziu, você estará a enviar e-mails personalizados ao usar isto.<br />'));
define('_ACA_FIRST_NAME_REP', compa::encodeutf('[FIRSTNAME] = Isto será substituído pelo PRIMEIRO nome que o assinante introduziu.<br />'));
define('_ACA_NONHTML', compa::encodeutf('Versão Não-html'));
define('_ACA_ATTACHMENTS', compa::encodeutf('Anexos'));
define('_ACA_SELECT_MULTIPLE', compa::encodeutf('Carregue na tecla CONTROL (ou COMANDO) para selecionar múltiplos anexos.<br />' .
		'Os arquivos apresentados nesta lista de anexos estão localizados no diretório de anexos, pode alterar esta localização no painel de controlo em Configuração.'));
define('_ACA_CONTENT_ITEM', compa::encodeutf('Item do Conteúdo'));
define('_ACA_SENDING_EMAIL', compa::encodeutf('A enviar e-mail'));
define('_ACA_MESSAGE_NOT', compa::encodeutf('A Mensagem não pode ser enviada'));
define('_ACA_MAILER_ERROR', compa::encodeutf('Erro no Mailer'));
define('_ACA_MESSAGE_SENT_SUCCESSFULLY', compa::encodeutf('Mensagem enviada com sucesso'));
define('_ACA_SENDING_TOOK', compa::encodeutf('O envio deste mailing foi de'));
define('_ACA_SECONDS', compa::encodeutf('segundos'));
define('_ACA_NO_ADDRESS_ENTERED', compa::encodeutf('Nenhum assinante ou endereço de e-mail fornecido'));
define('_ACA_CHANGE_SUBSCRIPTIONS', compa::encodeutf('Modificar'));
define('_ACA_CHANGE_EMAIL_SUBSCRIPTION', compa::encodeutf('Modificar a sua inscrição'));
define('_ACA_WHICH_EMAIL_TEST', compa::encodeutf('Indique o endereço de e-mail para enviar um teste ou selecione pré-visualizar'));
define('_ACA_SEND_IN_HTML', compa::encodeutf('Enviar em HTML (para mailings html)?'));
define('_ACA_VISIBLE', compa::encodeutf('Visível'));
define('_ACA_INTRO_ONLY', compa::encodeutf('Apenas Introdução'));

// stats
define('_ACA_GLOBALSTATS', compa::encodeutf('Estatísticas Globais'));
define('_ACA_DETAILED_STATS', compa::encodeutf('Estatísticas Detalhadas'));
define('_ACA_MAILING_LIST_DETAILS', compa::encodeutf('Detalhes de Listas'));
define('_ACA_SEND_IN_HTML_FORMAT', compa::encodeutf('Envio em formato HTML'));
define('_ACA_VIEWS_FROM_HTML', compa::encodeutf('Vistos (de e-mails em html)'));
define('_ACA_SEND_IN_TEXT_FORMAT', compa::encodeutf('Envio em formtato Texto'));
define('_ACA_HTML_READ', compa::encodeutf('Lidos HTML'));
define('_ACA_HTML_UNREAD', compa::encodeutf('Não-Lidos HTML'));
define('_ACA_TEXT_ONLY_SENT', compa::encodeutf('Apenas Texto'));

// Configuration panel
// main tabs
define('_ACA_MAIL_CONFIG', compa::encodeutf('Mail'));
define('_ACA_LOGGING_CONFIG', compa::encodeutf('Hist. & Estat.'));
define('_ACA_SUBSCRIBER_CONFIG', compa::encodeutf('Assinantes'));
define('_ACA_AUTO_CONFIG', compa::encodeutf('Agenda'));
define('_ACA_MISC_CONFIG', compa::encodeutf('Miscelânea'));
define('_ACA_MAIL_SETTINGS', compa::encodeutf('Definições de E-Mail'));
define('_ACA_MAILINGS_SETTINGS', compa::encodeutf('Definições de Mailings'));
define('_ACA_SUBCRIBERS_SETTINGS', compa::encodeutf('Definições de Assinantes'));
define('_ACA_CRON_SETTINGS', compa::encodeutf('Definições de Agenda'));
define('_ACA_SENDING_SETTINGS', compa::encodeutf('Definições de Envio'));
define('_ACA_STATS_SETTINGS', compa::encodeutf('Definições de Estatísticas'));
define('_ACA_LOGS_SETTINGS', compa::encodeutf('Definições de Históricos'));
define('_ACA_MISC_SETTINGS', compa::encodeutf('Definições de Miscelânea'));
// mail settings
define('_ACA_SEND_MAIL_FROM', compa::encodeutf('E-mail do remetente'));
define('_ACA_SEND_MAIL_NAME', compa::encodeutf('Nome do remetente'));
define('_ACA_MAILSENDMETHOD', compa::encodeutf('Método do Mailer'));
define('_ACA_SENDMAILPATH', compa::encodeutf('Caminho do Sendmail'));
define('_ACA_SMTPHOST', compa::encodeutf('SMTP host'));
define('_ACA_SMTPAUTHREQUIRED', compa::encodeutf('Requer Autenticação SMTP'));
define('_ACA_SMTPAUTHREQUIRED_TIPS', compa::encodeutf('Selecione SIM se o seu servidor SMTP require autenticação'));
define('_ACA_SMTPUSERNAME', compa::encodeutf('nome da conta SMTP'));
define('_ACA_SMTPUSERNAME_TIPS', compa::encodeutf('Introduza o nome da conta para o SMTP quando o seu servidor SMTP requerer autenticação'));
define('_ACA_SMTPPASSWORD', compa::encodeutf('palavra-passe SMTP'));
define('_ACA_SMTPPASSWORD_TIPS', compa::encodeutf('Introduza a palavra-passe para o SMTP quando o seu servidor SMTP requerer autenticação'));
define('_ACA_USE_EMBEDDED', compa::encodeutf('Usar imagens embebidas'));
define('_ACA_USE_EMBEDDED_TIPS', compa::encodeutf('Selecione SIM se as imagens dos items de conteúdo anexo deverão ser embebidas no e-mail para mensagens em html, ou NÃO para usar as tags de imagem por defeito que fazem link para as imagens no site.'));
define('_ACA_UPLOAD_PATH', compa::encodeutf('Caminho de Envio/Anexos'));
define('_ACA_UPLOAD_PATH_TIPS', compa::encodeutf('Pode especificar um diretório para envio.<br />' .
		'Certifique-se que o diretório especificado existe, caso contrário crie-o.'));

// subscribers settings
define('_ACA_ALLOW_UNREG', compa::encodeutf('Permitir não-registrados'));
define('_ACA_ALLOW_UNREG_TIPS', compa::encodeutf('Selecione SIM se quiser permitir usuários se inscreverem listas sem estarem registrados no site.'));
define('_ACA_REQ_CONFIRM', compa::encodeutf('Requerer Confirmação'));
define('_ACA_REQ_CONFIRM_TIPS', compa::encodeutf('Selecione SIM se quiser obrigar os usuários assinantes não-registados a confirmar o seu endereço de e-mail.'));
define('_ACA_SUB_SETTINGS', compa::encodeutf('Definições de Inscrição'));
define('_ACA_SUBMESSAGE', compa::encodeutf('Email de Inscrição'));
define('_ACA_SUBSCRIBE_LIST', compa::encodeutf('Inscrever uma lista'));

define('_ACA_USABLE_TAGS', compa::encodeutf('Tags utilizáveis'));
define('_ACA_NAME_AND_CONFIRM', compa::encodeutf('<b>[CONFIRM]</b> = Isto cria um link clicável onde o assinante pode confirmar a sua Inscrição. Isto é <strong>obrigatório</strong> para que o Acajoom funcione corretamente.<br />'
.'<br />[NAME] = Isto será substituído pelo nome que o assinante introduziu, estará a enviar e-mails personalizados ao usar isto.<br />'
.'<br />[FIRSTNAME] = Isto será substituído pelo PRIMEIRO nome do assinante, o primeiro nome é DEFINIDO pelo primeiro nome introduzido pelo assinante.<br />'));
define('_ACA_CONFIRMFROMNAME', compa::encodeutf('Confirmar o nome do Remetente'));
define('_ACA_CONFIRMFROMNAME_TIPS', compa::encodeutf('Introduza o nome do remetente a mostrar na confirmação das listas.'));
define('_ACA_CONFIRMFROMEMAIL', compa::encodeutf('Confirmar o e-mail do remetente'));
define('_ACA_CONFIRMFROMEMAIL_TIPS', compa::encodeutf('Introduza o endereço de e-mail do remetente a mostrar na confirmação das listas.'));
define('_ACA_CONFIRMBOUNCE', compa::encodeutf('Endereço de Bounce'));
define('_ACA_CONFIRMBOUNCE_TIPS', compa::encodeutf('Introduza o endereço de bounce do remetente a mostrar na confirmação das listas.'));
define('_ACA_HTML_CONFIRM', compa::encodeutf('Confirmar HTML'));
define('_ACA_HTML_CONFIRM_TIPS', compa::encodeutf('Selecione SIM se as listas de confirmação devem ser em HTML se o usuário permitir HTML.'));
define('_ACA_TIME_ZONE_ASK', compa::encodeutf('Perguntar Zona de Fuso Horário'));
define('_ACA_TIME_ZONE_TIPS', compa::encodeutf('Selecione SIM se quiser perguntar ao usuário qual a sua zona de fuso horário. Quando aplicável, os mailings em espera serão enviados baseados na zona de fuso horário'));

 // Cron Set up
define('_ACA_TIME_OFFSET_URL', compa::encodeutf('clique aqui para definir a zona de fuso horário no painel de configuração global do Joomla -> Separador Locale'));
define('_ACA_TIME_OFFSET_TIPS', compa::encodeutf('Defina a zona de fuso horário do seu servidor para que a data e hora guardadas sejam exactas'));
define('_ACA_TIME_OFFSET', compa::encodeutf('Fuso Horário'));
define('_ACA_CRON_TITLE', compa::encodeutf('Definir uma função de agenda'));
define('_ACA_CRON_DESC', compa::encodeutf('<br />Usar a função agenda automatica de tarefas para o seu site Joomla!<br />' .
		'Para a accionar precisa de adicionar no painel de controle (separador cron)o seguinte comando:<br />' .
		'<b>' . ACA_JPATH_LIVE . '/index.php?option=com_acajoom&act=cron</b> ' .
		'<br /><br />Se precisar de ajuda para parametrizar ou tiver problemas, por favor consulte o nosso forum <a href="http://www.acajoom.com" target="_blank">http://www.acajoom.com</a>'));
// sending settings
define('_ACA_PAUSEX', compa::encodeutf('Pausa em segundos por cada quantidade de e-mails cadastrados'));
define('_ACA_PAUSEX_TIPS', compa::encodeutf('Introduza o número de segundos que o Acajoom dará ao servidor de SMTP para enviar as mensagens antes de proceder a novo envio do grupo seguinte de mensagens.'));
define('_ACA_EMAIL_BET_PAUSE', compa::encodeutf('E-mails entre pausas'));
define('_ACA_EMAIL_BET_PAUSE_TIPS', compa::encodeutf('Número de e-mails a enviar antes de fazer pausa.'));
define('_ACA_WAIT_USER_PAUSE', compa::encodeutf('Esperar por ação do usuário numa pausa'));
define('_ACA_WAIT_USER_PAUSE_TIPS', compa::encodeutf('Caso o script deva esperar por acção do usuário quando pausado entre conjuntos de mailings.'));
define('_ACA_SCRIPT_TIMEOUT', compa::encodeutf('Tempo de intervalo do Script'));
define('_ACA_SCRIPT_TIMEOUT_TIPS', compa::encodeutf('Número de minutos que o script deverá ter para correr (0 para ilimitados).'));
// Stats settings
define('_ACA_ENABLE_READ_STATS', compa::encodeutf('Ativar leitura de estatísticas'));
define('_ACA_ENABLE_READ_STATS_TIPS', compa::encodeutf('Selecione SIM se quiser guardar no histórico o número de visualizações. Esta técnica só pode ser usada com mailings em html'));
define('_ACA_LOG_VIEWSPERSUB', compa::encodeutf('Guardar histórico de visualizações por assinante'));
define('_ACA_LOG_VIEWSPERSUB_TIPS', compa::encodeutf('Selecione SIM se quiser guardar no histórico o número de visualizações por assinante. Esta técnica só pode ser usada com mailings em html'));
// Logs settings
define('_ACA_DETAILED', compa::encodeutf('Históricos detalhados'));
define('_ACA_SIMPLE', compa::encodeutf('Históricos simplificados'));
define('_ACA_DIAPLAY_LOG', compa::encodeutf('Mostrar históricos'));
define('_ACA_DISPLAY_LOG_TIPS', compa::encodeutf('Selecione SIM se quiser mostrar os históricos enquanto envia mailings.'));
define('_ACA_SEND_PERF_DATA', compa::encodeutf('Envio de performance para fora'));
define('_ACA_SEND_PERF_DATA_TIPS', compa::encodeutf('Selecione SIM se quiser permitir ao Acajoom enviar relatórios ANÔNIMOS sobre a sua configuração, número de assinantes de uma lista e o tempo que levou e enviar o mailing. Isto dá-nos uma ideia acerca da performance do Acajoom e AJUDA-NOS a melhorar o Acajoom em futuros desenvolvimentos.'));
define('_ACA_SEND_AUTO_LOG', compa::encodeutf('Histórico de envio para o Auto-resposta'));
define('_ACA_SEND_AUTO_LOG_TIPS', compa::encodeutf('Selecione SIM se quiser enviar um e-mail com histórico cada vez que a fila for processada.  AVISO: isto pode resultar numa grande quantidade de e-mails.'));
define('_ACA_SEND_LOG', compa::encodeutf('Histórico de envio'));
define('_ACA_SEND_LOG_TIPS', compa::encodeutf('Caso deva ser enviado um e-mail com o histórico do mailing para o endereço de e-mail do usuário que envioou o mailing.'));
define('_ACA_SEND_LOGDETAIL', compa::encodeutf('Detalhe do histórico de envio'));
define('_ACA_SEND_LOGDETAIL_TIPS', compa::encodeutf('DETALHADO inclúe a informação de sucesso ou falha para cada assinante e um resumo geral da informação. SIMPLES apenas envia o resumo geral.'));
define('_ACA_SEND_LOGCLOSED', compa::encodeutf('Enviar histórico se a conexão for fechada'));
define('_ACA_SEND_LOGCLOSED_TIPS', compa::encodeutf('Com esta opção activada o usuário que enviou o mailing receberá na mesma o relatório por e-mail.'));
define('_ACA_SAVE_LOG', compa::encodeutf('Salvar Histórico'));
define('_ACA_SAVE_LOG_TIPS', compa::encodeutf('Caso o histórico do mailing deva ser anexado ao arquivo do histórico.'));
define('_ACA_SAVE_LOGDETAIL', compa::encodeutf('Guardar histórico detalhado'));
define('_ACA_SAVE_LOGDETAIL_TIPS', compa::encodeutf('DETALHADO inclui a informação de sucesso ou falha para cada assinante e um resumo geral da informação. SIMPLES apenas envia o resumo geral.'));
define('_ACA_SAVE_LOGFILE', compa::encodeutf('Salvar arquivo de Histórico'));
define('_ACA_SAVE_LOGFILE_TIPS', compa::encodeutf('Arquivo ao qual a informção de histórico será anexada. Este arquivo poderá ficar muito grande.'));
define('_ACA_CLEAR_LOG', compa::encodeutf('Limpar Histórico'));
define('_ACA_CLEAR_LOG_TIPS', compa::encodeutf('Limpa o arquivo de Histórico.'));

### control panel
define('_ACA_CP_LAST_QUEUE', compa::encodeutf('Última fila executada'));
define('_ACA_CP_TOTAL', compa::encodeutf('Total'));
define('_ACA_MAILING_COPY', compa::encodeutf('Mailing copiado com sucesso!'));

// Miscellaneous settings
define('_ACA_SHOW_GUIDE', compa::encodeutf('Mostrar Guia'));
define('_ACA_SHOW_GUIDE_TIPS', compa::encodeutf('Mostra o Guia no início para ajudar novos usuários a criar um informativo, uma auto-resposta e parametrizar corretamente o Acajoom.'));
define('_ACA_AUTOS_ON', compa::encodeutf('Usar Auto-respostas'));
define('_ACA_AUTOS_ON_TIPS', compa::encodeutf('Selecione NÃO se não quiser usar Auto-respostas, todas as opções de auto-respostas serão desactivadas.'));
define('_ACA_NEWS_ON', compa::encodeutf('Usar Informativos'));
define('_ACA_NEWS_ON_TIPS', compa::encodeutf('Selecione NÃO se não quiser usar Informativos, todas as opções de informativos serão desactivadas.'));
define('_ACA_SHOW_TIPS', compa::encodeutf('Mostrar Dicas'));
define('_ACA_SHOW_TIPS_TIPS', compa::encodeutf('Mostra dicas para ajudar os usuários a usar o Acajoom de forma eficaz.'));
define('_ACA_SHOW_FOOTER', compa::encodeutf('Mostrar Rodapé'));
define('_ACA_SHOW_FOOTER_TIPS', compa::encodeutf('Caso deva ou não ser mostrado os direitos de cópia no rodapé.'));
define('_ACA_SHOW_LISTS', compa::encodeutf('Mostrar Listas no sítio-principal'));
define('_ACA_SHOW_LISTS_TIPS', compa::encodeutf('Quando o usuário não está registrado, é mostrada uma relação das listas que o mesmo pode se inscrver, clicando através no botão do arquivo dos informativos ou simplesmente preechendo um formulário de login, para que se possam registrar.'));
define('_ACA_CONFIG_UPDATED', compa::encodeutf('Os detalhes da configuração foram atualizados!'));
define('_ACA_UPDATE_URL', compa::encodeutf('URL de Atualização'));
define('_ACA_UPDATE_URL_WARNING', compa::encodeutf('AVISO! Não mude esta URL, a não ser que lhe seja pedido pela equipa técnica do Acajoom.<br />'));
define('_ACA_UPDATE_URL_TIPS', compa::encodeutf('Por exemplo: http://www.acajoom.com/update/ (inclua a barra no final)'));

// module
define('_ACA_EMAIL_INVALID', compa::encodeutf('O endereço de e-mail introduzido é inválido.'));
define('_ACA_REGISTER_REQUIRED', compa::encodeutf('É necessário registar-se primeiro no site para poder ser assinante de uma lista.'));

// Access level box
define('_ACA_OWNER', compa::encodeutf('Criador da Lista:'));
define('_ACA_ACCESS_LEVEL', compa::encodeutf('Definir nível de acesso para a lista'));
define('_ACA_ACCESS_LEVEL_OPTION', compa::encodeutf('Opções de nível de acesso'));
define('_ACA_USER_LEVEL_EDIT', compa::encodeutf('Selecione que nível de usuário tem permissão para editar um mailing (seja da página principal ou na área de administração) '));

//  drop down options
define('_ACA_AUTO_DAY_CH1', compa::encodeutf('Diariamente'));
define('_ACA_AUTO_DAY_CH2', compa::encodeutf('Diariamente, excepto fim-de-semana'));
define('_ACA_AUTO_DAY_CH3', compa::encodeutf('Dia sim, dia não'));
define('_ACA_AUTO_DAY_CH4', compa::encodeutf('Dia sim, dia não, excepto fim-de-semana'));
define('_ACA_AUTO_DAY_CH5', compa::encodeutf('Semanalmente'));
define('_ACA_AUTO_DAY_CH6', compa::encodeutf('Bi-semanal'));
define('_ACA_AUTO_DAY_CH7', compa::encodeutf('Mensal'));
define('_ACA_AUTO_DAY_CH9', compa::encodeutf('Anual'));
define('_ACA_AUTO_OPTION_NONE', compa::encodeutf('Não'));
define('_ACA_AUTO_OPTION_NEW', compa::encodeutf('Novos Usuários'));
define('_ACA_AUTO_OPTION_ALL', compa::encodeutf('Todos os Usuários'));

//
define('_ACA_UNSUB_MESSAGE', compa::encodeutf('Email para Não-Inscrição'));
define('_ACA_UNSUB_SETTINGS', compa::encodeutf('Definições de Não-Inscrição'));
define('_ACA_AUTO_ADD_NEW_USERS', compa::encodeutf('Inscrição automática de Usuários?'));

// Update and upgrade messages
define('_ACA_NO_UPDATES', compa::encodeutf('Não existem atualizações disponíveis de momento.'));
define('_ACA_VERSION', compa::encodeutf('Versão Acajoom'));
define('_ACA_NEED_UPDATED', compa::encodeutf('Arquivos que precisam de ser atualizados:'));
define('_ACA_NEED_ADDED', compa::encodeutf('Arquivos que precisam de ser adicionados:'));
define('_ACA_NEED_REMOVED', compa::encodeutf('Arquivos que precisam de ser removidos:'));
define('_ACA_FILENAME', compa::encodeutf('Arquivo:'));
define('_ACA_CURRENT_VERSION', compa::encodeutf('Versão actual:'));
define('_ACA_NEWEST_VERSION', compa::encodeutf('Última versão:'));
define('_ACA_UPDATING', compa::encodeutf('Atualizando'));
define('_ACA_UPDATE_UPDATED_SUCCESSFULLY', compa::encodeutf('Os arquivos foram atualizados com sucesso.'));
define('_ACA_UPDATE_FAILED', compa::encodeutf('A Atualização Falhou!'));
define('_ACA_ADDING', compa::encodeutf('Adicionando'));
define('_ACA_ADDED_SUCCESSFULLY', compa::encodeutf('Adicionado com sucesso.'));
define('_ACA_ADDING_FAILED', compa::encodeutf('A Adição Falhou!'));
define('_ACA_REMOVING', compa::encodeutf('Removendo'));
define('_ACA_REMOVED_SUCCESSFULLY', compa::encodeutf('Removido com sucesso.'));
define('_ACA_REMOVING_FAILED', compa::encodeutf('A Remoção Falhou!'));
define('_ACA_INSTALL_DIFFERENT_VERSION', compa::encodeutf('Instale uma versão diferente'));
define('_ACA_CONTENT_ADD', compa::encodeutf('Adicionar conteúdo'));
define('_ACA_UPGRADE_FROM', compa::encodeutf('Importar dados (informativos e informação de assinantes) de '));
define('_ACA_UPGRADE_MESS', compa::encodeutf('Não existem riscos para os seus dados existentes. <br /> Este processo simplesmente apenas importa dados para a base de dados do Acajoom.'));
define('_ACA_CONTINUE_SENDING', compa::encodeutf('Continuar e enviar'));

// Acajoom message
define('_ACA_UPGRADE1', compa::encodeutf('Você pode facilmente importar os seus usuários e informativos '));
define('_ACA_UPGRADE2', compa::encodeutf(' para o Acajoom no painel de atualizações.'));
define('_ACA_UPDATE_MESSAGE', compa::encodeutf('Está disponível uma nova versão do Acajoom! '));
define('_ACA_UPDATE_MESSAGE_LINK', compa::encodeutf('Clique aqui para atualizar!'));
define('_ACA_CRON_SETUP', compa::encodeutf('Para que as auto-respostas sejam enviadas tem de configurar uma tarefa Cron.'));
define('_ACA_THANKYOU', compa::encodeutf('Obrigado por escolher Acajoom, o Seu Parceiro de Comunicação!'));
define('_ACA_NO_SERVER', compa::encodeutf('Servidor de actualização não disponível, por favor verifique mais tarde.'));
define('_ACA_MOD_PUB', compa::encodeutf('O módulo Acajoom não está publicado.'));
define('_ACA_MOD_PUB_LINK', compa::encodeutf('Clique aqui para o publicar!'));
define('_ACA_IMPORT_SUCCESS', compa::encodeutf('importado com sucesso'));
define('_ACA_IMPORT_EXIST', compa::encodeutf('assinante já está na base de dados'));


// Acajoom\'s Guide
define('_ACA_GUIDE', compa::encodeutf('Assistente'));
define('_ACA_GUIDE_FIRST_ACA_STEP', compa::encodeutf('<p>O Acajoom tem muitas caracteristicas grandiosas e este assistente vai guia-lo através de um processo de 4 passos fáceis para que começe a enviar informativos e auto-respostas!<p />'));
define('_ACA_GUIDE_FIRST_ACA_STEP_DESC', compa::encodeutf('Primeiro, precisa de adicionar uma lista.  Uma lista pode ser de dois tipos, informativo ou auto-resposta.' .
		'  Na lista você define todos os diferentes parâmetros para activar o envio de seus informativos ou auto-respostas: nome do remetente, layout, mensagem de boas-vindas aos assinantes\' , etc...
<br /><br />Pode criar a sua primeira lista aqui: <a href="index2.php?option=com_acajoom&act=list" >criar uma lista</a> e clicar no botão novo.'));
define('_ACA_GUIDE_FIRST_ACA_STEP_UPGRADE', compa::encodeutf('O Acajoom proporciona-lhe uma maneira fácil de importar toda a informação de um sistema prévio de informativo.<br />' .
		' Vá ao painel de Actualizações e escolha o seu sistema prévio de informativo para importar todas os seus informativos e assinantes.<br /><br />' .
		'<span style="color:#FF5E00;" >IMPORTANTE: a inmporatação é LIVRE de risco e não afecta de forma alguma a informação do seu sistema prévio de informativo</span><br />' .
		'Depois da importação será capaz de gerir os seus assinantes e mailings directamente a partir do Acajoom.<br /><br />'));
define('_ACA_GUIDE_SECOND_ACA_STEP', compa::encodeutf('Optimo a sua primeira lista está criada!  Agora pode escrever o seu primeiro %s.  Para criar vá para: '));
define('_ACA_GUIDE_SECOND_ACA_STEP_AUTO', compa::encodeutf('Gestão de Auto-responder'));
define('_ACA_GUIDE_SECOND_ACA_STEP_NEWS', compa::encodeutf('Gestão de Informativos'));
define('_ACA_GUIDE_SECOND_ACA_STEP_FINAL', compa::encodeutf(' e selecione o seu %s. <br /> Depois escolha o seu %s na lista de possibilidades.  Crie o seu primeiro mailing clicando em NOVO '));

define('_ACA_GUIDE_THRID_ACA_STEP_NEWS', compa::encodeutf('Antes de enviar o seu primeiro informativo, você poderá querer verificar a configuração de mail.  ' .
		'Vá para <a href="index2.php?option=com_acajoom&act=configuration" >Página de Configuração</a> para verificar as definições de mail. <br />'));
define('_ACA_GUIDE_THRID2_ACA_STEP_NEWS', compa::encodeutf('<br />Quando estiver pronto retroceda para o Menu Informativos, selecione o seu mailing e clique em ENVIAR'));

define('_ACA_GUIDE_THRID_ACA_STEP_AUTOS', compa::encodeutf('Para que as suas auto-respostas sejam enviadas necessita que primeiro esteja criada uma tarefa Cron no seu servidor. ' .
		' Por favor refira-se ao separador Cron no painel de configuração.' .
		' <a href="index2.php?option=com_acajoom&act=configuration" >clique aqui</a> para aparender como criar uma tarefa Cron. <br />'));

define('_ACA_GUIDE_MODULE', compa::encodeutf(' <br />Certifique também que publicou o módulo Acajoom para que as pessoas possam assinar a lista.'));

define('_ACA_GUIDE_FOUR_ACA_STEP_NEWS', compa::encodeutf(' Pode agora criar uma auto-resposta.'));
define('_ACA_GUIDE_FOUR_ACA_STEP_AUTOS', compa::encodeutf(' Pode agora também criar um informativo.'));

define('_ACA_GUIDE_FOUR_ACA_STEP', compa::encodeutf('<p><br />Aí está! Está agora pronto para comunicar de forma eficaz com os seus visitantes e usuários. Este assistente terminará assim que você introduzir um segundo mailing ou então pode desliga-lo no <a href="index2.php?option=com_acajoom&act=configuration" >Painel de Configuração</a>.' .
		'<br /><br />  Se tiver alguma questão enquanto usar o Acajoom, por favor refira-se ao ' .
		'<a target="_blank" href="http://www.acajoom.com/index.php?option=com_joomlaboard&Itemid=26&task=listcat&catid=22" >forum</a>. ' .
		' Encontrará também muita informação sobre como comunicar de forma eficaz com os seus assinantes em <a href="http://www.acajoom.com/" target="_blank" >www.Acajoom.com</a>.' .
		'<p /><br /><b>Obrigado por usar o Acajoom. O Seu Parceiro de Comunicação!</b> '));
define('_ACA_GUIDE_TURNOFF', compa::encodeutf('O assitente esta agora a ser desligado!'));
define('_ACA_STEP', compa::encodeutf('STEP '));

// Acajoom Install
define('_ACA_INSTALL_CONFIG', compa::encodeutf('Configuração Acajoom'));
define('_ACA_INSTALL_SUCCESS', compa::encodeutf('Instalação com Sucesso'));
define('_ACA_INSTALL_ERROR', compa::encodeutf('Erro na instalação'));
define('_ACA_INSTALL_BOT', compa::encodeutf('Plugin (Bot) Acajoom'));
define('_ACA_INSTALL_MODULE', compa::encodeutf('Módulo Acajoom'));
//Others
define('_ACA_JAVASCRIPT', compa::encodeutf('!Aviso! Para uma correcta operação o Javascript deve estar activado.'));
define('_ACA_EXPORT_TEXT', compa::encodeutf('Os assinantes exportados são baseados na lista que escolheu. <br />Exportar assinantes para lista'));
define('_ACA_IMPORT_TIPS', compa::encodeutf('Importar assinantes. A informação no arquivo precisa de ter o seguinte formato: <br />' .
		'Nome,e-mail,recebeHTML(1/0),<span style="color: rgb(255, 0, 0);">confirmado(1/0)</span>'));
define('_ACA_SUBCRIBER_EXIT', compa::encodeutf('já é assinante'));
define('_ACA_GET_STARTED', compa::encodeutf('Clique aqui para começar!'));

//News since 1.0.1
define('_ACA_WARNING_1011', compa::encodeutf('Aviso: 1011: A Atualização não funcionará por causa das restrições do seu server.'));
define('_ACA_SEND_MAIL_FROM_TIPS', compa::encodeutf('Escolha que endereço de e-mail será mostrado como remetente.'));
define('_ACA_SEND_MAIL_NAME_TIPS', compa::encodeutf('Escolha que nome se mostrado como remetente.'));
define('_ACA_MAILSENDMETHOD_TIPS', compa::encodeutf('Escolha que mailer deseja usar: PHP mail function, <span>Sendmail</span> ou SMTP Server.'));
define('_ACA_SENDMAILPATH_TIPS', compa::encodeutf('Esta é o caminho do servidor de E-Mail'));
define('_ACA_LIST_T_TEMPLATE', compa::encodeutf('Tema Padrão'));
define('_ACA_NO_MAILING_ENTERED', compa::encodeutf('Nenhum mailing fornecido'));
define('_ACA_NO_LIST_ENTERED', compa::encodeutf('Nenhuma lista fornecida'));
define('_ACA_SENT_MAILING', compa::encodeutf('Mailings Enviados'));
define('_ACA_SELECT_FILE', compa::encodeutf('Por favor selecione um arquivo para '));
define('_ACA_LIST_IMPORT', compa::encodeutf('Verifique a(s) lista(s) que você quer que tenha(m) assinantes associados.'));
define('_ACA_PB_QUEUE', compa::encodeutf('Assinante inserido, mas existe um problema para se registrar essa pessoa para a lista(s). Verifique manualmente.'));
define('_ACA_UPDATE_MESS', compa::encodeutf(''));
define('_ACA_UPDATE_MESS1', compa::encodeutf('Atualização Altamente Recomendada!'));
define('_ACA_UPDATE_MESS2', compa::encodeutf('Remendo e pequenas correções.'));
define('_ACA_UPDATE_MESS3', compa::encodeutf('Novo lançamento.'));
define('_ACA_UPDATE_MESS5', compa::encodeutf('É obrigatório Joomla 1.5 para atualizar.'));
define('_ACA_UPDATE_IS_AVAIL', compa::encodeutf(' está disponível!'));
define('_ACA_NO_MAILING_SENT', compa::encodeutf('Nenhum mailing enviado!'));
define('_ACA_SHOW_LOGIN', compa::encodeutf('Mostra formulário de login'));
define('_ACA_SHOW_LOGIN_TIPS', compa::encodeutf('Selecione SIM para mostrar um formulário de login no sítio-principal do Painel de Controlo do Acajoom para que o usuário possa registar-se no site.'));
define('_ACA_LISTS_EDITOR', compa::encodeutf('Editor de Descrição da Lista'));
define('_ACA_LISTS_EDITOR_TIPS', compa::encodeutf('Selecione SIM para usar um editor HTML para editar o campo Descrição da Lista.'));
define('_ACA_SUBCRIBERS_VIEW', compa::encodeutf('Ver assinantes'));

//News since 1.0.2
define('_ACA_FRONTEND_SETTINGS', compa::encodeutf('Definiçoes do Sítio-Principal'));
define('_ACA_SHOW_LOGOUT', compa::encodeutf('Mostra botão de logout'));
define('_ACA_SHOW_LOGOUT_TIPS', compa::encodeutf('Selecione SIM para mostrar um botão de logout no front-end do painal de controlo do Acajoom.'));

//News since 1.0.3 CB integration
define('_ACA_CONFIG_INTEGRATION', compa::encodeutf('Integração'));
define('_ACA_CB_INTEGRATION', compa::encodeutf('Integração com o Community Builder'));
define('_ACA_INSTALL_PLUGIN', compa::encodeutf('Plugin Community Builder (Integração Acajoom) '));
define('_ACA_CB_PLUGIN_NOT_INSTALLED', compa::encodeutf('O plugin Acajoom para o Community Builder ainda não está instalado!'));
define('_ACA_CB_PLUGIN', compa::encodeutf('Listas aquando do registo'));
define('_ACA_CB_PLUGIN_TIPS', compa::encodeutf('Selecione SIM para mostrar as listas de mailing no formulário de registo do community builder'));
define('_ACA_CB_LISTS', compa::encodeutf('Listas de IDs'));
define('_ACA_CB_LISTS_TIPS', compa::encodeutf('ESTE CAMPO É OBRIGATÓRIO. Introduza o número de ID das listas que você quer permitir aos usuários assinar separados por vírgula ,  (0 mostra todas as listas)'));
define('_ACA_CB_INTRO', compa::encodeutf('Texto de Introdução'));
define('_ACA_CB_INTRO_TIPS', compa::encodeutf('Um texto aparecerá antes da listagem. DEIXE EM BRANCO PARA NÃO MOSTRAR NADA.  Use cb_pretext para layout CSS.'));
define('_ACA_CB_SHOW_NAME', compa::encodeutf('Mostra Nome da Lista'));
define('_ACA_CB_SHOW_NAME_TIPS', compa::encodeutf('Selecione se deve ou não mostrar o nome da lista depois da introdução.'));
define('_ACA_CB_LIST_DEFAULT', compa::encodeutf('Verifica lista por defeito'));
define('_ACA_CB_LIST_DEFAULT_TIPS', compa::encodeutf('Selecione se quer ou não, ter uma caixa de verificação para cada lista verificado por defeito.'));
define('_ACA_CB_HTML_SHOW', compa::encodeutf('Mostra Receber HTML'));
define('_ACA_CB_HTML_SHOW_TIPS', compa::encodeutf('Escolha SIM para permitir aos usuários decidir se querem ou não, receber e-mails em HTML. Escolha NÃO para usar o receber HTML por defeito.'));
define('_ACA_CB_HTML_DEFAULT', compa::encodeutf('Receber HTML por defeito'));
define('_ACA_CB_HTML_DEFAULT_TIPS', compa::encodeutf('Escolha esta opção para mostrar a configuração de mail em HTML por defeito. Se o Mostra Receber Html estiver para NÃO então esta será a opção por defeitot.'));

// Since 1.0.4
define('_ACA_BACKUP_FAILED', compa::encodeutf('Não foi possível efetuar a cópia de segurança do arquivo! O arquivo não foi substituído.'));
define('_ACA_BACKUP_YOUR_FILES', compa::encodeutf('Foi efectuada uma cópia de segurança dos arquivos da versão antiga na seguinte directória:'));
define('_ACA_SERVER_LOCAL_TIME', compa::encodeutf('Hora local do Servidor'));
define('_ACA_SHOW_ARCHIVE', compa::encodeutf('Mostrar botão de Arquivo'));
define('_ACA_SHOW_ARCHIVE_TIPS', compa::encodeutf('Selecione SIM para mostrar o botão de Arquivo no front-end das listas de Informativo'));
define('_ACA_LIST_OPT_TAG', compa::encodeutf('Tags'));
define('_ACA_LIST_OPT_IMG', compa::encodeutf('Imagens'));
define('_ACA_LIST_OPT_CTT', compa::encodeutf('Conteúdo'));
define('_ACA_INPUT_NAME_TIPS', compa::encodeutf('Introduza o seu nome completo (primeiro nome primeiro)'));
define('_ACA_INPUT_EMAIL_TIPS', compa::encodeutf('Introduza o seu endereço de e-mail (Certifique-se de que este é um endereço de e-mail válido para que possa receber as nossas Informativos.)'));
define('_ACA_RECEIVE_HTML_TIPS', compa::encodeutf('Escolha SIM se quiser receber mails em HTML - NÃO para receber mails em apenas texto'));
define('_ACA_TIME_ZONE_ASK_TIPS', compa::encodeutf('Especifique a sua zona de fuso horário.'));


// Since 1.0.5
define('_ACA_FILES', compa::encodeutf('Arquivos'));
define('_ACA_FILES_UPLOAD', compa::encodeutf('Envio'));
define('_ACA_MENU_UPLOAD_IMG', compa::encodeutf('Envio de Imagens'));
define('_ACA_TOO_LARGE', compa::encodeutf('Tamanho do arquivo demasiado grande. O tamanho máximo permitido é'));
define('_ACA_MISSING_DIR', compa::encodeutf('O directório de destino não existe'));
define('_ACA_IS_NOT_DIR', compa::encodeutf('O directório de destino não existe ou é um arquivo regular.'));
define('_ACA_NO_WRITE_PERMS', compa::encodeutf('O directório de destino não tem permissão de escrita.'));
define('_ACA_NO_USER_FILE', compa::encodeutf('Não selecionou nenhum arquivo para envio.'));
define('_ACA_E_FAIL_MOVE', compa::encodeutf('Impossível mover o arquivo.'));
define('_ACA_FILE_EXISTS', compa::encodeutf('O arquivo destino já existe.'));
define('_ACA_CANNOT_OVERWRITE', compa::encodeutf('O arquivo destino já existe e não pode ser sobreposto.'));
define('_ACA_NOT_ALLOWED_EXTENSION', compa::encodeutf('Extensão de arquivo não permitida.'));
define('_ACA_PARTIAL', compa::encodeutf('O arquivo foi enviado apenas parcialmente.'));
define('_ACA_UPLOAD_ERROR', compa::encodeutf('Erro de envio:'));
define('DEV_NO_DEF_FILE', compa::encodeutf('O arquivo foi enviado apenas parcialmente.'));
define('_ACA_CONTENTREP', compa::encodeutf('[SUBSCRIPTIONS] = Isto será substituído pelos links de inscrição.' .
		' Isto é <strong>obrigatório</strong> para que o Acajoom funcione corretamente.<br />' .
		'Se colocar algum outro conteúdo nesta caixa o mesmo será mostrado em todos os mailings correspondentes a esta Lista.' .
		' <br />Adicione a sua mensagem de inscrição no final. O Acajoom adicionará automaticamente um link para que o assinante altere a informação dele, e um link para remover-se da Lista.'));

// since 1.0.6
define('_ACA_NOTIFICATION', compa::encodeutf('Notificação'));  // shortcut for Email notification
define('_ACA_NOTIFICATIONS', compa::encodeutf('Notificações'));
define('_ACA_USE_SEF', compa::encodeutf('SEF nos mailings'));
define('_ACA_USE_SEF_TIPS', compa::encodeutf('É recomendado que escolha NÃO.  No entanto se desejar que o URL incluído nos seus mailings use SEF então escolha SIM.' .
		' <br /><b>Os links funcionarão de igual forma para ambas as opções.  NÃO, assegurará que os links nos mailings funcionarão sempre mesmo que altere o seu SEF.</b> '));
define('_ACA_ERR_NB', compa::encodeutf('Erro #: ERR'));
define('_ACA_ERR_SETTINGS', compa::encodeutf('Definições de manuseamento de Erros'));
define('_ACA_ERR_SEND', compa::encodeutf('Enviar relatório de erros'));
define('_ACA_ERR_SEND_TIPS', compa::encodeutf('Se deseja que o Acajoom seja um produto melhor por favor selecione SIM.  Isto envia-nos um relatório de erros.  Por isso nunca mais necessita de reportar bugs ;-) <br /> <b>NENHUMA INFORMAÇÃO PRIVADA É ENVIADA</b>.  Nós nem sequer saberemos a que site pertençe o erro. Apenas enviamos informação sobre o Acajoom , a instalação PHP e queries SQL. '));
define('_ACA_ERR_SHOW_TIPS', compa::encodeutf('Escolha SIM para mostrar o número do erro no ecrán.  Usado principalmente para efeitos de debuging. '));
define('_ACA_ERR_SHOW', compa::encodeutf('Mostra erros'));
define('_ACA_LIST_SHOW_UNSUBCRIBE', compa::encodeutf('Mostra links de remoção'));
define('_ACA_LIST_SHOW_UNSUBCRIBE_TIPS', compa::encodeutf('Selecione SIM para mostrar links de remoção no rodapé dos mailings para que os usuários possam mudar as suas subscrições. <br /> NÃO, desactiva os links e rodapé.'));
define('_ACA_UPDATE_INSTALL', compa::encodeutf('<span style="color: rgb(255, 0, 0);">NOTÍCIA IMPORTANTE!</span> <br />Se está a fazer uma actualização a partir de uma versão anterior do Acajoom, precisa de atualizar a estrutura da sua base de dados clicando no botão seguinte (A sua informação ficará íntegra)'));
define('_ACA_UPDATE_INSTALL_BTN', compa::encodeutf('Actualizar tabelas e configuração'));
define('_ACA_MAILING_MAX_TIME', compa::encodeutf('Tempo máximo da fila'));
define('_ACA_MAILING_MAX_TIME_TIPS', compa::encodeutf('Define o tempo máximo para cada conjunto de e-mails enviados pela fila. Recomendado entre 30s e 2mins.'));

// virtuemart integration beta
define('_ACA_VM_INTEGRATION', compa::encodeutf('Integração com VirtueMart'));
define('_ACA_VM_COUPON_NOTIF', compa::encodeutf('Notificação de ID do Cupão'));
define('_ACA_VM_COUPON_NOTIF_TIPS', compa::encodeutf('Especifica o número de ID do mailing que quiser usar para enviar cupões para os seus clientes.'));
define('_ACA_VM_NEW_PRODUCT', compa::encodeutf('Notificação de ID de novos produtos'));
define('_ACA_VM_NEW_PRODUCT_TIPS', compa::encodeutf('Especifica o número de ID do mailing que quiser usar para enviar notificação de novos produtos.'));


// since 1.0.8
// create forms for subscriptions
define('_ACA_FORM_BUTTON', compa::encodeutf('Criar Formulário'));
define('_ACA_FORM_COPY', compa::encodeutf('Código HTML'));
define('_ACA_FORM_COPY_TIPS', compa::encodeutf('Copie o código HTML gerado para a sua página HTML.'));
define('_ACA_FORM_LIST_TIPS', compa::encodeutf('Selecione a lista que quer incluir neste formulário'));
// update messages
define('_ACA_UPDATE_MESS4', compa::encodeutf('Não pode ser atualizado automaticamente.'));
define('_ACA_WARNG_REMOTE_FILE', compa::encodeutf('Não há maneira de conseguir o arquivo remoto.'));
define('_ACA_ERROR_FETCH', compa::encodeutf('Erro de acesso ao arquivo.'));

define('_ACA_CHECK', compa::encodeutf('Verificar'));
define('_ACA_MORE_INFO', compa::encodeutf('Mais informação'));
define('_ACA_UPDATE_NEW', compa::encodeutf('Atualizar para nova versão'));
define('_ACA_UPGRADE', compa::encodeutf('Atualizar para produto mais atual'));
define('_ACA_DOWNDATE', compa::encodeutf('Voltar a instalar versão anterior'));
define('_ACA_DOWNGRADE', compa::encodeutf('Voltar para o produto básico'));
define('_ACA_REQUIRE_JOOM', compa::encodeutf('Requer Joomla'));
define('_ACA_TRY_IT', compa::encodeutf('Experimentar!'));
define('_ACA_NEWER', compa::encodeutf('Novo'));
define('_ACA_OLDER', compa::encodeutf('Antigo'));
define('_ACA_CURRENT', compa::encodeutf('Atual'));

// since 1.0.9
define('_ACA_CHECK_COMP', compa::encodeutf('Experimentar um dos outros componentes'));
define('_ACA_MENU_VIDEO', compa::encodeutf('Tutoriais de Vídeo'));
define('_ACA_AUTO_SCHEDULE', compa::encodeutf('Temporizador'));
define('_ACA_SCHEDULE_TITLE', compa::encodeutf('Definições de funções automáticas temporizadas'));
define('_ACA_ISSUE_NB_TIPS', compa::encodeutf('Atribuir número automaticamente gerado pelo sistema'));
define('_ACA_SEL_ALL', compa::encodeutf('Todos os mailings'));
define('_ACA_SEL_ALL_SUB', compa::encodeutf('Todas as listas'));
define('_ACA_INTRO_ONLY_TIPS', compa::encodeutf('Se assinalar esta caixa apenas a introdução do artigo será inserida no mailing com um link LER MAIS para a leitura completa do mesmo no seu site.'));
define('_ACA_TAGS_TITLE', compa::encodeutf('Tag de conteúdo'));
define('_ACA_TAGS_TITLE_TIPS', compa::encodeutf('Copie e cole esta tag para o seu mailing, no sítio onde quer colocar o conteúdo.'));
define('_ACA_PREVIEW_EMAIL_TEST', compa::encodeutf('Indica o endereço de e-mail para onde enviar um teste'));
define('_ACA_PREVIEW_TITLE', compa::encodeutf('Pré-visualizar'));
define('_ACA_AUTO_UPDATE', compa::encodeutf('Nova notificação de atualização'));
define('_ACA_AUTO_UPDATE_TIPS', compa::encodeutf('Selecione SIM se quiser ser notificado de novas atualizações para o seu componente. <br />IMPORTANTE!! Mostrar Dicas tem de estar activado para que esta função funcione.'));

// since 1.1.0
define('_ACA_LICENSE', compa::encodeutf('Informação de Licenceamento'));


// since 1.1.1
define('_ACA_NEW', compa::encodeutf('Novo'));
define('_ACA_SCHEDULE_SETUP', compa::encodeutf('Para que as auto-respostas sejam enviadas tem que definir uma agenda na configuração.'));
define('_ACA_SCHEDULER', compa::encodeutf('Agendador'));
define('_ACA_ACAJOOM_CRON_DESC', compa::encodeutf('se não tem acesso à administração de tarefas agendadas no seu website, pode registar-se para uma Conta Tarefa Cron Acajoom Grátis em:'));
define('_ACA_CRON_DOCUMENTATION', compa::encodeutf('Pode encontrar mais informação sobre como definir o Agendador Acajoom no url seguinte:'));
define('_ACA_CRON_DOC_URL', compa::encodeutf('<a href="http://www.acajoom.com/index.php?option=com_content&task=blogcategory&id=29"
 target="_blank">http://www.acajoom.com/index.php?option=com_content&task=blogcategory&id=29</a>'));
define( '_ACA_QUEUE_PROCESSED', compa::encodeutf('Fila processada com sucesso...'));
define( '_ACA_ERROR_MOVING_UPLOAD', compa::encodeutf('Erro ao mover arquivo importado'));

//since 1.1.4
define( '_ACA_SCHEDULE_FREQUENCY', compa::encodeutf('Frequência do Agenda'));
define( '_ACA_CRON_MAX_FREQ', compa::encodeutf('Frequência Máxima da Agenda'));
define( '_ACA_CRON_MAX_FREQ_TIPS', compa::encodeutf('Especifica a frequência máxima que a agenda pode ser executada ( em minutos ).  Isto limitará a atenda mesmo que a tarefa cron esteja definida com maior frequência.'));
define( '_ACA_CRON_MAX_EMAIL', compa::encodeutf('Máximo de e-mails por tarefa'));
define( '_ACA_CRON_MAX_EMAIL_TIPS', compa::encodeutf('Especifica o número máximo de e-mails enviados por tarefa (0 ilimitados).'));
define( '_ACA_CRON_MINUTES', compa::encodeutf(' minutos'));
define( '_ACA_SHOW_SIGNATURE', compa::encodeutf('Mostra rodapé do e-mail'));
define( '_ACA_SHOW_SIGNATURE_TIPS', compa::encodeutf('Caso queira ou não promover o Acajoom no rodapé dos e-mails.'));
define( '_ACA_QUEUE_AUTO_PROCESSED', compa::encodeutf('Auto-respostas processadas com successo...'));
define( '_ACA_QUEUE_NEWS_PROCESSED', compa::encodeutf('Informativos agendadas processadas com sucesso...'));
define( '_ACA_MENU_SYNC_USERS', compa::encodeutf('Sincronizar Usuários'));
define( '_ACA_SYNC_USERS_SUCCESS', compa::encodeutf('Sincronização de Usuários processada com sucesso!'));

// compatibility with Joomla 15
if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', compa::encodeutf('Sair'));
if (!defined('_CMN_YES')) define( '_CMN_YES', compa::encodeutf('Sim'));
if (!defined('_CMN_NO')) define( '_CMN_NO', compa::encodeutf('Não'));
if (!defined('_HI')) define( '_HI', compa::encodeutf('Olá'));
if (!defined('_CMN_TOP')) define( '_CMN_TOP', compa::encodeutf('Topo'));
if (!defined('_CMN_BOTTOM')) define( '_CMN_BOTTOM', compa::encodeutf('Fundo'));
//if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', compa::encodeutf('Logout'));

// For include title only or full article in content item tab in newsletter edit - p0stman911
define('_ACA_TITLE_ONLY_TIPS', compa::encodeutf('Se selecionar isto, apenas o título do artigo será inserido no mailing como link para o artigo completo no seu site.'));
define('_ACA_TITLE_ONLY', compa::encodeutf('Apenas Título'));
define('_ACA_FULL_ARTICLE_TIPS', compa::encodeutf('Se selecionar isto o artigo completo será inserido no mailing'));
define('_ACA_FULL_ARTICLE', compa::encodeutf('Artigo Completo'));
define('_ACA_CONTENT_ITEM_SELECT_T', compa::encodeutf('Selecione um item de conteúdo para ser adicionado à mensagem. <br />Copie e cole o<b>content tag</b> para o mailing.  Pode escolher ter a totalidade do texto, apenas introdução, ou apenas título com (0, 1, ou 2 respectivamente). '));
define('_ACA_SUBSCRIBE_LIST2', compa::encodeutf('Lista(s) de Mailing'));

// smart-newsletter function
define('_ACA_AUTONEWS', compa::encodeutf('Smart-Informativo'));
define('_ACA_MENU_AUTONEWS', compa::encodeutf('Smart-Informativos'));
define('_ACA_AUTO_NEWS_OPTION', compa::encodeutf('Opções do Smart-Informativo'));
define('_ACA_AUTONEWS_FREQ', compa::encodeutf('Frequência do Informativo'));
define('_ACA_AUTONEWS_FREQ_TIPS', compa::encodeutf('Especifica a frequência com que deseja enviar as smart-informativo.'));
define('_ACA_AUTONEWS_SECTION', compa::encodeutf('Secção de Artigos'));
define('_ACA_AUTONEWS_SECTION_TIPS', compa::encodeutf('Especifica a secção de que quer escolher os artigos.'));
define('_ACA_AUTONEWS_CAT', compa::encodeutf('Categoria do Artigo'));
define('_ACA_AUTONEWS_CAT_TIPS', compa::encodeutf('Especifica a categoria de que quer escolher os artigos (TODAS para todos os artigos naquela secção).'));
define('_ACA_SELECT_SECTION', compa::encodeutf('Selecione secção'));
define('_ACA_SELECT_CAT', compa::encodeutf('Todas as Categorias'));
define('_ACA_AUTO_DAY_CH8', compa::encodeutf('Quaternalmente'));
define('_ACA_AUTONEWS_STARTDATE', compa::encodeutf('Data de começo'));
define('_ACA_AUTONEWS_STARTDATE_TIPS', compa::encodeutf('Especifica a data para começar a enviar a Smart Informativo.'));
define('_ACA_AUTONEWS_TYPE', compa::encodeutf('Renderização do Conteúdo'));// how we see the content which is included in the newsletter
define('_ACA_AUTONEWS_TYPE_TIPS', compa::encodeutf('Artigo Completo: irá incluir todo o artigo no informativo.<br />' .
		'Apenas Introdução: será incluida apenas a introdução do artigo na informativo.<br/>' .
		'Apenas Título: será incluido apenas o título do artigo no informativo.'));
define('_ACA_TAGS_AUTONEWS', compa::encodeutf('[SMARTNEWSLETTER] = Isto será substituído pela Smart-informativo.'));

//since 1.1.3
define('_ACA_MALING_EDIT_VIEW', compa::encodeutf('Criar / Visualizar Mailings'));
define('_ACA_LICENSE_CONFIG', compa::encodeutf('Licença'));
define('_ACA_ENTER_LICENSE', compa::encodeutf('Entre com a licença'));
define('_ACA_ENTER_LICENSE_TIPS', compa::encodeutf('Digite seu número de licença e salve.'));
define('_ACA_LICENSE_SETTING', compa::encodeutf('Configurações da Licença'));
define('_ACA_GOOD_LIC', compa::encodeutf('Sua licença é válida.'));
define('_ACA_NOTSO_GOOD_LIC', compa::encodeutf('Sua licença não é válida: '));
define('_ACA_PLEASE_LIC', compa::encodeutf('Por favor, entre em contato com o suporte técnico de Acajoom para atualizar sua licença ( license@acajoom.com ).'));

define('_ACA_DESC_PLUS', compa::encodeutf('Acajoom Plus é o primeiro auto-resposta sequencial para Joomla CMS.  ' . _ACA_FEATURES));
define('_ACA_DESC_PRO', compa::encodeutf('Acajoom PRO the ultimate mailing system for Joomla CMS.  ' . _ACA_FEATURES));

//since 1.1.4   JIS
define('_ACA_ENTER_TOKEN', compa::encodeutf('Digite o código'));
define('_ACA_ENTER_TOKEN_TIPS', compa::encodeutf('Por favor digite o código que você recebeu por e-mail, quando você comprou Acajoom. '));
define('_ACA_ACAJOOM_SITE', compa::encodeutf('Acajoom site:'));
define('_ACA_MY_SITE', compa::encodeutf('Meu site:'));
define( '_ACA_LICENSE_FORM', compa::encodeutf(' ' . 'Clique aqui para ir para a licença.</a>'));
define('_ACA_PLEASE_CLEAR_LICENSE', compa::encodeutf('Por favor limpe o campo de licença para que ele esteja vazio e tente novamente.<br />  Se o problema persistir, '));
define( '_ACA_LICENSE_SUPPORT', compa::encodeutf('Se você ainda tiver dúvidas, ' . _ACA_PLEASE_LIC ));
define( '_ACA_LICENSE_TWO', compa::encodeutf('você pode obter a sua licença manual, digitando o código e URL do site (com um destaque em verde no alto desta página) na forma de licença. '
					. _ACA_LICENSE_FORM . '<br /><br/>' . _ACA_LICENSE_SUPPORT ));
define('_ACA_ENTER_TOKEN_PATIENCE', compa::encodeutf('Depois de salvar seu código a licença será gerada automaticamente. ' .
		' Geralmente o código é validado em 2 minutos. Porém, em alguns casos, pode levar até 15 minutos.<br />' .
		'<br />Verifique novamente este painel de controle em poucos minutos.  <br /><br />' .
						'Se você não receber uma chave de licença válida em 15 minutos, '. _ACA_LICENSE_TWO));
define( '_ACA_ENTER_NOT_YET', compa::encodeutf('Seu código ainda não foi validado.'));
define( '_ACA_UPDATE_CLICK_HERE', compa::encodeutf('Por favor visite <a href="http://www.acajoom.com" target="_blank">www.acajoom.com</a> para download da última versão.'));
define( '_ACA_NOTIF_UPDATE', compa::encodeutf('Para ser notificado das novas atualizações, digite o seu endereço de e-mail e clique em inscrever '));

define('_ACA_THINK_PLUS', compa::encodeutf('Se você quiser mais recursos do seu sistema de correio mude para a versão Plus!'));
define('_ACA_THINK_PLUS_1', compa::encodeutf('Sequencial auto-responders'));
define('_ACA_THINK_PLUS_2', compa::encodeutf('Agende a entrega do seu boletim informativo para uma data previamente definida'));
define('_ACA_THINK_PLUS_3', compa::encodeutf('Não há mais limitação do servidor'));
define('_ACA_THINK_PLUS_4', compa::encodeutf('e muito mais ...'));


//since 1.2.2
define( '_ACA_LIST_ACCESS', compa::encodeutf('Lista de acesso'));
define( '_ACA_INFO_LIST_ACCESS', compa::encodeutf('Specify what group of users can view and subscribe to this list'));
define( 'ACA_NO_LIST_PERM', compa::encodeutf('You don\'t have enough permission to subscribe to this list'));

//Archive Configuration
 define('_ACA_MENU_TAB_ARCHIVE', compa::encodeutf('Arquivo'));
 define('_ACA_MENU_ARCHIVE_ALL', compa::encodeutf('Arquivar todas'));

//Archive Lists
 define('_FREQ_OPT_0', compa::encodeutf('Nenhuma'));
 define('_FREQ_OPT_1', compa::encodeutf('Toda Semana'));
 define('_FREQ_OPT_2', compa::encodeutf('A cada 2 semanas'));
 define('_FREQ_OPT_3', compa::encodeutf('Todo mês'));
 define('_FREQ_OPT_4', compa::encodeutf('Todas as quartas'));
 define('_FREQ_OPT_5', compa::encodeutf('Todo ano'));
 define('_FREQ_OPT_6', compa::encodeutf('Outros'));

define('_DATE_OPT_1', compa::encodeutf('Data de criação'));
define('_DATE_OPT_2', compa::encodeutf('Data de modificação'));

define('_ACA_ARCHIVE_TITLE', compa::encodeutf('Configurando a freqüência do auto-arquivo'));
define('_ACA_FREQ_TITLE', compa::encodeutf('Freqüência de arquivo'));
define('_ACA_FREQ_TOOL', compa::encodeutf('Definir quantas vezes você quiser que o Gerenciador de Arquivo para arquivar o conteúdo de seu website.'));
define('_ACA_NB_DAYS', compa::encodeutf('Número de dias'));
define('_ACA_NB_DAYS_TOOL', compa::encodeutf('Isto é somente para a outra opção! Especifique o número de dias entre cada arquivo.'));
define('_ACA_DATE_TITLE', compa::encodeutf('Tipo de date'));
define('_ACA_DATE_TOOL', compa::encodeutf('Definir se o arquivamento deve ser feito sobre a data de criação ou modificação.'));

define('_ACA_MAINTENANCE_TAB', compa::encodeutf('Manutenção das configurações'));
define('_ACA_MAINTENANCE_FREQ', compa::encodeutf('Freqüência de manutenção'));
define( '_ACA_MAINTENANCE_FREQ_TIPS', compa::encodeutf('Especificar a freqüência com que você deseja executar a manutenção de rotina.'));
define( '_ACA_CRON_DAYS', compa::encodeutf('hora(s)'));

define( '_ACA_LIST_NOT_AVAIL', compa::encodeutf('Não existe uma lista disponível.'));
define( '_ACA_LIST_ADD_TAB', compa::encodeutf('Adicionar/Editar'));

define( '_ACA_LIST_ACCESS_EDIT', compa::encodeutf('Mailing - Adicionar/Editar acesso'));
define( '_ACA_INFO_LIST_ACCESS_EDIT', compa::encodeutf('Especificar qual grupo de usuários pode adicionar ou editar uma nova mailing para esta lista'));
define( '_ACA_MAILING_NEW_FRONT', compa::encodeutf('Criar nova Mailing'));

define('_ACA_AUTO_ARCHIVE', compa::encodeutf('Auto-Arquivar'));
define('_ACA_MENU_ARCHIVE', compa::encodeutf('Auto-Arquivo'));

//Extra tags:
define('_ACA_TAGS_ISSUE_NB', compa::encodeutf('[ISSUENB] = Este será substituído pelo número de informativo.'));
define('_ACA_TAGS_DATE', compa::encodeutf('[DATE] = Este será substituído pela data de envio.'));
define('_ACA_TAGS_CB', compa::encodeutf('[CBTAG:{field_name}] = Este será substituído pelo valor retirado do campo da Comunidade Builder: por exemplo. [CBTAG:firstname] '));
define( '_ACA_MAINTENANCE', compa::encodeutf('Manutenção'));


define('_ACA_THINK_PRO', compa::encodeutf('Quando você tem necessidades profissionais, utilize componentes profissionais!'));
define('_ACA_THINK_PRO_1', compa::encodeutf('Smart-Informativos'));
define('_ACA_THINK_PRO_2', compa::encodeutf('Define nível de acesso para a sua lista'));
define('_ACA_THINK_PRO_3', compa::encodeutf('Define quem pode adicionar/editar mailings'));
define('_ACA_THINK_PRO_4', compa::encodeutf('Mais tags: adicionar os seus campos da Comunidade Builder'));
define('_ACA_THINK_PRO_5', compa::encodeutf('Auto arquivar conteúdos Joomla'));
define('_ACA_THINK_PRO_6', compa::encodeutf('Otimização da base de dados'));

define('_ACA_LIC_NOT_YET', compa::encodeutf('Sua licença ainda não é válida. Confira o código da licença no painel de configuração.'));
define('_ACA_PLEASE_LIC_GREEN', compa::encodeutf('Certifique-se de prestar informações em destaque verde na parte superior da guia à nossa equipe de suporte.'));

define('_ACA_FOLLOW_LINK', compa::encodeutf('Pegue sua licença'));
define( '_ACA_FOLLOW_LINK_TWO', compa::encodeutf('Você pode obter a sua licença, digitando o código e a URL do site (com destaque em verde no alto desta página) em forma de licença. '));
define( '_ACA_ENTER_TOKEN_TIPS2', compa::encodeutf('Depois clique no botão \"Aplicar\" no canto superior direito do menu.'));
define( '_ACA_ENTER_LIC_NB', compa::encodeutf('Digite sua licença'));
define( '_ACA_UPGRADE_LICENSE', compa::encodeutf('Atualize sua licença'));
define( '_ACA_UPGRADE_LICENSE_TIPS', compa::encodeutf('Se você recebeu um código para atualizar a sua licença, por favor digite-o aqui, clique em \"Aplicar\" e procederá ao número <b>2</b> para pegar seu novo número de licença.'));

define( '_ACA_MAIL_FORMAT', compa::encodeutf('Formato da Codificação'));
define( '_ACA_MAIL_FORMAT_TIPS', compa::encodeutf('Qual formato que pretende utilizar para codificar os seus mailings, Texto somente or MIME'));
define( '_ACA_ACAJOOM_CRON_DESC_ALT', compa::encodeutf('Se você não tem acesso a configuração da agenda do seu site, você pode usar o componente jCron (free) para criar uma tarefa agendada do seu site.'));

//since 1.3.1
define('_ACA_SHOW_AUTHOR', compa::encodeutf('Mostrar nome do autor'));
define('_ACA_SHOW_AUTHOR_TIPS', compa::encodeutf('Selecione Sim, se você quiser acrescentar o nome do autor quando você adicionar um artigo no Mailing'));

//since 1.3.5
define('_ACA_REGWARN_NAME', compa::encodeutf('Por favor, informe seu nome.'));
define('_ACA_REGWARN_MAIL', compa::encodeutf('Por favor, informe um endereço de e-mail válido.'));

//since 1.5.6
define('_ACA_ADDEMAILREDLINK_TIPS', compa::encodeutf('Se você selecionar Sim, o e-mail do usuário será adicionado como um parâmetro no final da URL de seu redirecionamento (redireccionar a URL para seu módulo externo ou para Acajoom).<br/>Isso pode ser útil se você quiser executar um script especial em sua página de redirecionamento.'));
define('_ACA_ADDEMAILREDLINK', compa::encodeutf('Adicionar e-mail para a URL de redirecionamento'));

//since 1.6.3
define('_ACA_ITEMID', compa::encodeutf('ItemId'));
define('_ACA_ITEMID_TIPS', compa::encodeutf('Este itemId será adicionado ao seu Acajoom links.'));

//since 1.6.5
define('_ACA_SHOW_JCALPRO', compa::encodeutf('jCalPRO'));
define('_ACA_SHOW_JCALPRO_TIPS', compa::encodeutf('Mostrar a integração para jCalPRO <br/>(somente se jCalPRO estiver instalado em seu website!)'));
define('_ACA_JCALTAGS_TITLE', compa::encodeutf('jCalPRO Tag:'));
define('_ACA_JCALTAGS_TITLE_TIPS', compa::encodeutf('Copie e cole essa tag na mailing onde pretende ter o evento a ser colocado.'));
define('_ACA_JCALTAGS_DESC', compa::encodeutf('Descrição:'));
define('_ACA_JCALTAGS_DESC_TIPS', compa::encodeutf('Selecione \"Yes\" se você quer inserir a descrição dos eventos'));
define('_ACA_JCALTAGS_START', compa::encodeutf('Data de início:'));
define('_ACA_JCALTAGS_START_TIPS', compa::encodeutf('Selecione \"Yes\" se você quer inserir o início da data do evento'));
define('_ACA_JCALTAGS_READMORE', compa::encodeutf('Leia mais:'));
define('_ACA_JCALTAGS_READMORE_TIPS', compa::encodeutf('Selecione \"Yes\" se você quer inserir um link <b>\"Leia mais\"</b> para este evento'));
define('_ACA_REDIRECTCONFIRMATION', compa::encodeutf('URL a Redirecionar'));
define('_ACA_REDIRECTCONFIRMATION_TIPS', compa::encodeutf('Se você precisar de uma confirmação por e-mail, o usuário será confirmado com esta URL, e redirecionado para ele clicar no link de confirmação.'));

//since 2.0.0 compatibility with Joomla 1.5
if(!defined('_CMN_SAVE') and defined('CMN_SAVE')) define('_CMN_SAVE',CMN_SAVE);
if(!defined('_CMN_SAVE')) define('_CMN_SAVE','Salvar');
if(!defined('_NO_ACCOUNT')) define('_NO_ACCOUNT','Não tem conta ainda?');
if(!defined('_CREATE_ACCOUNT')) define('_CREATE_ACCOUNT','Registrar');
if(!defined('_NOT_AUTH')) define('_NOT_AUTH','Você não está autorizado pra visualizar este recurso.');

//since 3.0.0
define('_ACA_DISABLETOOLTIP', compa::encodeutf('Disabilitar Tooltip'));
define('_ACA_DISABLETOOLTIP_TIPS', compa::encodeutf('Disabilitar o tooltip da tela inicial'));
define('_ACA_MINISENDMAIL', compa::encodeutf('Usar Mini SendMail'));
define('_ACA_MINISENDMAIL_TIPS', compa::encodeutf('Se seu servidor usa Mini SendMail, selecione este opção para não adicionar o nome do usuário no header do e-mail'));

//Since 3.1.5
define('_ACA_READMORE','Read more...');
define('_ACA_VIEWARCHIVE','Click here');

//since 4.0.0
define('_ACA_SHOW_JLINKS','Link Tracking');
define('_ACA_SHOW_JLINKS_TIPS','Enables the integration with jLinks to be able to do link tracking for each links in the newsletter.');

//since 4.1.0
define( '_ACA_MAIL_ENCODING', 'Mail encoding' );
define( '_ACA_MAIL_ENCODING_TIPS', 'What encoding format do you want to use UTF-8 (highly recommended) or ISO-8859-2' );
define( '_ACA_COPY_SUBJECT', 'Copy Subject' );

﻿<?php
defined('_JEXEC') OR defined('_VALID_MOS') OR die('...Direct Access to this location is not allowed...');

/**
* <p>Finnish language file</p>
* @author Tero Kankaanperä <tero@terokankaanpera.fi>
* @version $Id: finnish.php 491 2007-02-01 22:56:07Z divivo $
* @link http://terokankaanpera.fi
*/

#######    NOTE TO TRANSLATORS  #######
# If you wish to translate the language file to your own language, please feel free to do so
# We would apprecaite if you could send you translation to the specified email
# so that other people could benefit from your contribution
# If you feel that the file is too long feel free to do as much as you want and probably
# someone else will be happy to pick up were you stopped.
#  We did our bestt to organize the subject by order of priority so start at the top
# If you update your translation please send you updates to translation@acajoom.com
# IMPORTANT: make sure respect as much as posible the punctionation and spacing because
# sometimes the word constant are conbined...
# Don't ever remove a define as it will create an error in the code.
# when using apostrophy  '   add a back-slash before like this:  \'  otherwise it will create an error.
# sometimes you will see html tag in the define, please leave it the way it is.

# DONT FORGET if you want to be credited fro your work, make sure to change the credit
# with your name and email if you want people to contact you otherwise leave the email as it is.
# We will use that information to also include you into the About section of the component
# Thank you very much for your contribution translating in your language

### General ###
 //acajoom Description
define('_ACA_DESC_NEWS', 'Acajoom on sähköpostilista, uutiskirje, automaattivastaaja ja seurantatyökalu tehokkaaseen viestimiseen käyttäjiesi ja asiakkaidesi kanssa.  ' .
		'Acajoom, Your Communication Partner!');
define('_ACA_FEATURES', 'Acajoom, your communication partner!');

// Type of lists
define('_ACA_NEWSLETTER', 'Uutiskirje');
define('_ACA_AUTORESP', 'Automaattivastaaja');
define('_ACA_AUTORSS', 'Auto-RSS');
define('_ACA_ECARD', 'eKortti');
define('_ACA_POSTCARD', 'Postikortti');
define('_ACA_PERF', 'Näytös');
define('_ACA_COUPON', 'Kuponki');
define('_ACA_CRON', 'Cron tehtävä');
define('_ACA_MAILING', 'Postitus');
define('_ACA_LIST', 'Lista');

 //acajoom Menu
define('_ACA_MENU_LIST', 'Listat');
define('_ACA_MENU_SUBSCRIBERS', 'Tilaajat');
define('_ACA_MENU_NEWSLETTERS', 'Uutiskirjeet');
define('_ACA_MENU_AUTOS', 'Automaattivastaajat');
define('_ACA_MENU_COUPONS', 'Kupongit');
define('_ACA_MENU_CRONS', 'Cron tehtävät');
define('_ACA_MENU_AUTORSS', 'Auto-RSS');
define('_ACA_MENU_ECARD', 'eKortit');
define('_ACA_MENU_POSTCARDS', 'Postikortit');
define('_ACA_MENU_PERFS', 'Näytökset');
define('_ACA_MENU_TAB_LIST', 'Listat');
define('_ACA_MENU_MAILING_TITLE', 'Postitukset');
define('_ACA_MENU_MAILING' , 'Postitukset ');
define('_ACA_MENU_STATS', 'Tilastot');
define('_ACA_MENU_STATS_FOR', 'Tilastot ');
define('_ACA_MENU_CONF', 'Asetukset');
define('_ACA_MENU_UPDATE', 'Tuonti');
define('_ACA_MENU_ABOUT', 'Tietoa');
define('_ACA_MENU_LEARN', 'Oppimiskeskus');
define('_ACA_MENU_MEDIA', 'Medianhallinta');
define('_ACA_MENU_HELP', 'Ohje');
define('_ACA_MENU_CPANEL', 'Ohjauspaneeli');
define('_ACA_MENU_IMPORT', 'Tuo');
define('_ACA_MENU_EXPORT', 'Vie');
define('_ACA_MENU_SUB_ALL', 'Tilaa kaikki');
define('_ACA_MENU_UNSUB_ALL', 'Peru kaikki');
define('_ACA_MENU_VIEW_ARCHIVE', 'Arkisto');
define('_ACA_MENU_PREVIEW', 'Esikatselu');
define('_ACA_MENU_SEND', 'Lähetä');
define('_ACA_MENU_SEND_TEST', 'Tee koelähetys');
define('_ACA_MENU_SEND_QUEUE', 'Suorita jono');
define('_ACA_MENU_VIEW', 'Katso');
define('_ACA_MENU_COPY', 'Kopioi');
define('_ACA_MENU_VIEW_STATS' , 'Katso tilastot');
define('_ACA_MENU_CRTL_PANEL' , ' Ohjauspaneeli');
define('_ACA_MENU_LIST_NEW' , ' Luo lista');
define('_ACA_MENU_LIST_EDIT' , ' Muokkaa listaa');
define('_ACA_MENU_BACK', 'Takaisin');
define('_ACA_MENU_INSTALL', 'Asennus');
define('_ACA_MENU_TAB_SUM', 'Yhteenveto');
define('_ACA_STATUS' , 'Status');

// messages
define('_ACA_ERROR' , ' Tapahtui virhe! ');
define('_ACA_SUB_ACCESS' , 'Käyttöoikeudet');
define('_ACA_DESC_CREDITS', 'Credits');
define('_ACA_DESC_INFO', 'Tietoa');
define('_ACA_DESC_HOME', 'Kotisivu');
define('_ACA_DESC_MAILING', 'Postituslista');
define('_ACA_DESC_SUBSCRIBERS', 'Tilaajat');
define('_ACA_PUBLISHED','Julkaistu');
define('_ACA_UNPUBLISHED','Piilotettu');
define('_ACA_DELETE','Poista');
define('_ACA_FILTER','Suodata');
define('_ACA_UPDATE','Päivitä');
define('_ACA_SAVE','Tallena');
define('_ACA_CANCEL','Peru');
define('_ACA_NAME','Nimi');
define('_ACA_EMAIL','Sähköpostiosoite');
define('_ACA_SELECT','Valitse');
define('_ACA_ALL','Kaikki');
define('_ACA_SEND_A', 'Lähetä ');
define('_ACA_SUCCESS_DELETED', ' poistettiin onnistuneesti');
define('_ACA_LIST_ADDED', 'Lista luotiin onnistuneesti');
define('_ACA_LIST_COPY', 'Lista kopioitiin onnistuneesti');
define('_ACA_LIST_UPDATED', 'Lista päivitettiin onnistuneesti');
define('_ACA_MAILING_SAVED', 'Postitus tallennettiin onnistuneesti.');
define('_ACA_UPDATED_SUCCESSFULLY', 'päivitettiin onnistuneesti.');

### Subscribers information ###
//subscribe and unsubscribe info
define('_ACA_SUB_INFO', 'Tilaajan tiedot');
define('_ACA_VERIFY_INFO', 'Ole hyvä ja varmista linkki, tietoa puuttuu.');
define('_ACA_INPUT_NAME', 'Nimi');
define('_ACA_INPUT_EMAIL', 'Sähköpostiosoite');
define('_ACA_RECEIVE_HTML', 'HTML muotoilu?');
define('_ACA_TIME_ZONE', 'Aikavyöhyke');
define('_ACA_BLACK_LIST', 'Mustalista');
define('_ACA_REGISTRATION_DATE', 'Käyttäjäksi rekisteröitymispvm');
define('_ACA_USER_ID', 'Käyttäjän id');
define('_ACA_DESCRIPTION', 'Kuvaus');
define('_ACA_ACCOUNT_CONFIRMED', 'Tilisi on aktivoitu.');
define('_ACA_SUB_SUBSCRIBER', 'Tilaaja');
define('_ACA_SUB_PUBLISHER', 'Julkaisija');
define('_ACA_SUB_ADMIN', 'Ylläpitäjä');
define('_ACA_REGISTERED', 'Rekisteröitynyt');
define('_ACA_SUBSCRIPTIONS', 'Tilauksesi');
define('_ACA_SEND_UNSUBCRIBE', 'Lähetä peruutusviesti');
define('_ACA_SEND_UNSUBCRIBE_TIPS', 'Napsauta Kyllä lähettääksesi peruutusviestin vahvistusviesti.');
define('_ACA_SUBSCRIBE_SUBJECT_MESS', 'Ole hyvä ja varmista tilauksesi');
define('_ACA_UNSUBSCRIBE_SUBJECT_MESS', 'Peruutusvahvistus');
define('_ACA_DEFAULT_SUBSCRIBE_MESS', 'Hei [NAME],<br />' .
		'Vielä yksi askel ja olet tilannut uutiskirjeen.  Ole hyvä ja napsauta seuraavaa linkkiä vahvistaaksesi tilauksesi.' .
		'<br /><br />[CONFIRM]<br /><br />Jos sinulla on kysyttävää ota yhteyttä ylläpitäjään.');
define('_ACA_DEFAULT_UNSUBSCRIBE_MESS', 'Tämä on varmistusviesti että olet peruuttanut uutiskirjeemme tilauksesi.  Olemme pahoillamme siitä, että päätit peruuttaa tilauksesi ja haluamme muistuttaa että voit uudistaa tilauksesi koska tahansa kotisivuillamme.  Jos sinulla on kysyttävää, ota yhteyttä ylläpitoomme.');

// Acajoom subscribers
define('_ACA_SIGNUP_DATE', 'Tilauspäivämäärä');
define('_ACA_CONFIRMED', 'Vahvistettu');
define('_ACA_SUBSCRIB', 'Tilaa');
define('_ACA_HTML', 'HTML muotoilu');
define('_ACA_RESULTS', 'Tulokset');
define('_ACA_SEL_LIST', 'Valitse lista');
define('_ACA_SEL_LIST_TYPE', '- Valitse listan tyyppi -');
define('_ACA_SUSCRIB_LIST', 'Listaa kaikki tilaajat');
define('_ACA_SUSCRIB_LIST_UNIQUE', 'Tilaajat listalle : ');
define('_ACA_NO_SUSCRIBERS', 'Listalle ei löydy tilaajia.');
define('_ACA_COMFIRM_SUBSCRIPTION', 'Vahvistus sähköposti on lähetetty sähköpostiosoitteeseesi.  Ole hyvä ja tarkista viestisi ja napsauta viestissä olevaa linkkiä.<br />' .
		'Sinun täytyy varmistaa sähköpostiosoitteesi tilauksesi voimaan saattamiseksi.');
define('_ACA_SUCCESS_ADD_LIST', 'Sinut on onnistuneesti liitetty listalle.');


 // Subcription info
define('_ACA_CONFIRM_LINK', 'Napsauta tästä vahvistaaksesi tilauksesi');
define('_ACA_UNSUBSCRIBE_LINK', 'Napsauta tästä poistaaksesi itsesi listalta');
define('_ACA_UNSUBSCRIBE_MESS', 'Sähköpostiosoitteesi on poistettu listalta');

define('_ACA_QUEUE_SENT_SUCCESS' , 'Kaikki ajastetut postitukset on onnistuneesti lähetetty.');
define('_ACA_MALING_VIEW', 'Katso kaikki postitukset');
define('_ACA_UNSUBSCRIBE_MESSAGE', 'Oletko varma että haluat peruuttaa tämän listan tilauksesi?');
define('_ACA_MOD_SUBSCRIBE', 'Tilaa');
define('_ACA_SUBSCRIBE', 'Tilaa');
define('_ACA_UNSUBSCRIBE', 'Peru tilaus');
define('_ACA_VIEW_ARCHIVE', 'Katso arkisto');
define('_ACA_SUBSCRIPTION_OR', ' tai napsauta tästä päivittääksesi tietosi');
define('_ACA_EMAIL_ALREADY_REGISTERED', 'Tämä sähköpostiosoite on jo rekisteröity.');
define('_ACA_SUBSCRIBER_DELETED', 'Tilaaja on poistettu onnistuneesti.');


### UserPanel ###
 //User Menu
define('_UCP_USER_PANEL', 'Käyttäjän ohjauspaneeli');
define('_UCP_USER_MENU', 'Käyttäjän valikko');
define('_UCP_USER_CONTACT', 'Tilaukseni');
 //Acajoom Cron Menu
define('_UCP_CRON_MENU', 'Cron tehtävien hallinta');
define('_UCP_CRON_NEW_MENU', 'Uusi ajastus');
define('_UCP_CRON_LIST_MENU', 'Listaa Cron tehtävät');
 //Acajoom Coupon Menu
define('_UCP_COUPON_MENU', 'Kuponkien hallinta');
define('_UCP_COUPON_LIST_MENU', 'Lista kupongit');
define('_UCP_COUPON_ADD_MENU', 'Lisää kuponki');

### lists ###
// Tabs
define('_ACA_LIST_T_GENERAL', 'Kuvaus');
define('_ACA_LIST_T_LAYOUT', 'Ulkoasu');
define('_ACA_LIST_T_SUBSCRIPTION', 'Tilaukset');
define('_ACA_LIST_T_SENDER', 'Lähettäjätiedot');

define('_ACA_LIST_TYPE', 'Listan tyyppi');
define('_ACA_LIST_NAME', 'Listan nimi');
define('_ACA_LIST_ISSUE', 'Numero ');
define('_ACA_LIST_DATE', 'Lähetyspäivä');
define('_ACA_LIST_SUB', 'Postituksen otsikko');
define('_ACA_ATTACHED_FILES', 'Liitetiedostot');
define('_ACA_SELECT_LIST', 'Ole hyvä ja valitse lista muokattavaksi!');

// Auto Responder box
define('_ACA_AUTORESP_ON', 'Listan tyyppi');
define('_ACA_AUTO_RESP_OPTION', 'Automaattivastaajan asetukset');
define('_ACA_AUTO_RESP_FREQ', 'Tilaajat voivat valita taajuuden');
define('_ACA_AUTO_DELAY', 'Viive (päivissä)');
define('_ACA_AUTO_DAY_MIN', 'Vähimmäistaajuus');
define('_ACA_AUTO_DAY_MAX', 'Enimmäistaajuus');
define('_ACA_FOLLOW_UP', 'Seuranta automaattivastaaja');
define('_ACA_AUTO_RESP_TIME', 'Tilaajat voivat valita ajan');
define('_ACA_LIST_SENDER', 'Listan lähettäjä');

define('_ACA_LIST_DESC', 'Listan kuvaus');
define('_ACA_LAYOUT', 'Ulkoasu');
define('_ACA_SENDER_NAME', 'Lähettäjän nimi');
define('_ACA_SENDER_EMAIL', 'Lähettäjän sähköpostiosoite');
define('_ACA_SENDER_BOUNCE', 'Lähettäjän reply-to osoite');
define('_ACA_LIST_DELAY', 'Viive');
define('_ACA_HTML_MAILING', 'HTML muotoilu?');
define('_ACA_HTML_MAILING_DESC', '(jos muutat tätä, sinun täytyy tallentaa ja palata tälle ruudulle nähdäksesi muutokset.)');
define('_ACA_HIDE_FROM_FRONTEND', 'Piilota julkisesta liittymästä?');
define('_ACA_SELECT_IMPORT_FILE', 'Valitse tuontitiedosto');;
define('_ACA_IMPORT_FINISHED', 'Tuonti suoritettu');
define('_ACA_DELETION_OFFILE', 'Tiedoston poistaminen');
define('_ACA_MANUALLY_DELETE', 'epäonnistui, sinun täytyy poistaa tiedosto manuaalisesti');
define('_ACA_CANNOT_WRITE_DIR', 'Hakemistoon ei voi kirjoittaa');
define('_ACA_NOT_PUBLISHED', 'Postitusta ei voitu lähettää, listaa ei ole julkaistu.');

//  List info box
define('_ACA_INFO_LIST_PUB', 'Napsauta Kyllä julkaistaksesi lista');
define('_ACA_INFO_LIST_NAME', 'Kirjoita listan nimi tähän. Voit tunnistaa listan tällä nimellä.');
define('_ACA_INFO_LIST_DESC', 'Kirjoita lyhyt kuvaus listasta tähän. Tämä kuvaus on sivustosi käyttäjien luettavissa.');
define('_ACA_INFO_LIST_SENDER_NAME', 'Anna listan postitusten lähettäjän käytetty nimi. Nimi näkyy tilaajille heidän saamissaan viesteissä.');
define('_ACA_INFO_LIST_SENDER_EMAIL', 'Anna sähköpostiosoite, josta listan viestit lähtevät. ');
define('_ACA_INFO_LIST_SENDER_BOUNCED', 'Anna sähköpostiosoite, johon listan vastaanottajat voivat vastata. Tämän suositellaan vakavasti olevan sama kuin lähettäjän osoite, koska roskapostisuodattimet antavat viestillesi korkeammat pisteet jos ne ovat eri osoitteita.');
define('_ACA_INFO_LIST_AUTORESP', 'Valitse postitusten tyyppi tälle listalle. <br />' .
		'Uutiskirje: tavallinen uutiskirje<br />' .
		'Automaattivastaaja: automaattivastaaja on lista, joka lähetetään sivuston kautta säännöllisin välein.');
define('_ACA_INFO_LIST_FREQUENCY', 'Anna käyttäjien valita miten usein he saavat viestin.  Tämä anta enemmän joustavuutta käyttäjille.');
define('_ACA_INFO_LIST_TIME', 'Anna käyttäjien valita mihin aikaan he haluavat saada viestin listalta.');
define('_ACA_INFO_LIST_MIN_DAY', 'Määrittele mikä on vähimmäistaajuus, jolla käyttäjät voivat listan tilata.');
define('_ACA_INFO_LIST_DELAY', 'Määrittele viive tämän ja edellisen automaattivastaajan välille.');
define('_ACA_INFO_LIST_DATE', 'Määrittele päivämäärä, jolloin haluat julkaista uutislistan jos haluat viivyttää sen julkaisemista. <br /> MUOTO : VVVV-KK-PP TT:MM:SS');
define('_ACA_INFO_LIST_MAX_DAY', 'Määrittele mikä on enimmäistaajuus, jolla käyttäjät voivat listan tilata.');
define('_ACA_INFO_LIST_LAYOUT', 'Syotä listan viestien ulkoasu tähän. Voit määritellä ulkoasun täysin vapaasti.');
define('_ACA_INFO_LIST_SUB_MESS', 'Tämä viesti lähetetään käyttäjälle kun hän ensimmäisen kerran rekisteröityy. Voit määritellä tekstin vapaasti.');
define('_ACA_INFO_LIST_UNSUB_MESS', 'Tämä viestin lähetetään tilaajalle kun hän peruuttaa tilauksensa. Mikä tahansa viesti voidaan asettaa tässä.');
define('_ACA_INFO_LIST_HTML', 'Valitse tämä ruutu jos haluat lähettää HTML-muotoiltuja viestejä. Käyttäjät voivat HTML-listaa tilatessaan määritellä haluavatko he vastaanottaa HTML-muotoiltuja vai pelkkänä tekstinä lähetettyjä viestejä.');
define('_ACA_INFO_LIST_HIDDEN', 'Valitse Kyllä piilottaaksesi tämä lista julkisesta liittymästä, käyttäjät eivät voi tilata listaa, mutta sinä voit edelleen lähettää viestejä sille.');
define('_ACA_INFO_LIST_ACA_AUTO_SUB', 'Haluatko automaattisesti liittää uudet käyttäjät tälle listalle?<br /><B>Uudet käyttäjät:</B> liittää kaikki uudet sivustolle rekisteröityvät.<br /><B>Kaikki käyttäjät:</B> liittää kaikki tietokannan rekisteröidyt käyttäjät.<br />(kaikki vaihtoehdot tukevat Community Builderia)');
define('_ACA_INFO_LIST_ACC_LEVEL', 'Valitse julkisen liittymän käyttöoikeustaso. Tämä näyttää tai piilottaa listan käyttäjäryhmiltä joilla ei ole riittäviä oikeusia siihen, jotta he eivät voi tilata sitä.');
define('_ACA_INFO_LIST_ACC_USER_ID', 'Valitse käyttöoikeusryhmä, jolle haluat antaa muokkausoikeuden. Tähän ja ylempiin ryhmiin kuuluvat voivat muokata postitusta ja lähettää sen, julkisesta tai ylläpitoliittymästä.');
define('_ACA_INFO_LIST_FOLLOW_UP', 'Jos haluat että automaattivastaaja siirtyy listasta toiseen kun viimeinen viesti on lähetetty voi määritellä tässä seuraavan listan.');
define('_ACA_INFO_LIST_ACA_OWNER', 'Tämä on listan luoneen henkilön ID.');
define('_ACA_INFO_LIST_WARNING', '   Tämä viimeinen asetus on asetettavissa vain kerran listan luomisen yhteydessä.');
define('_ACA_INFO_LIST_SUBJET', ' Postituksen otsikko.  Tämä on tilaajien saaman sähköpostiviestin otsikko.');
define('_ACA_INFO_MAILING_CONTENT', 'Tämä on lähettämäsi sähköpostiviestin runko (sisältö).');
define('_ACA_INFO_MAILING_NOHTML', 'Lisää tähän pelkkänä tekstinä lähetettävän viestin runko (sisältö) niille käyttäjille, jotka valitsivat pelkän tekstimuotoisen viestin <BR/> HUOMAA: jos jätät tämän tyhjäksi Acajoom konvertoi HTML-muotoisen viestin automaattisesti pelkäksi tekstiksi.');
define('_ACA_INFO_MAILING_VISIBLE', 'Valitse Kyllä näyttääksesi postitus julkisessa liittymässä.');
define('_ACA_INSERT_CONTENT', 'Lisää olemassa olevaa sisältöä.');

// Coupons
define('_ACA_SEND_COUPON_SUCCESS', 'Kuponki onnistuneesti lähetetty!');
define('_ACA_CHOOSE_COUPON', 'Valitse kuponki');
define('_ACA_TO_USER', ' tälle käyttäjälle');

### Cron options
//drop down frequency(CRON)
define('_ACA_FREQ_CH1', 'Joka x. tunti');
define('_ACA_FREQ_CH2', 'Joka 6. tunti');
define('_ACA_FREQ_CH3', 'Joka 12. tunti');
define('_ACA_FREQ_CH4', 'Päivittäin');
define('_ACA_FREQ_CH5', 'Viikoittain');
define('_ACA_FREQ_CH6', 'kuukausittain');
define('_ACA_FREQ_NONE', 'Ei');
define('_ACA_FREQ_NEW', 'Uudet käyttäjät');
define('_ACA_FREQ_ALL', 'Kaikki käyttäjät');

//Label CRON form
define('_ACA_LABEL_FREQ', 'Acajoom Cron?');
define('_ACA_LABEL_FREQ_TIPS', 'Valitse Kyllä jos haluat käyttää tätä Acajoom Cron-ajatukseen, Ei mitä tahansa muuta Cron-ajastusta varten.<br />' .
		'Jos valitset Kyllä sinun ei tarvitse määritellä Cron osoitetta, se lisätään automaattisesti.');
define('_ACA_SITE_URL' , 'Sivustosi URL');
define('_ACA_CRON_FREQUENCY' , 'Cron taajuus');
define('_ACA_STARTDATE_FREQ' , 'Aloitus päivämäärä');
define('_ACA_LABELDATE_FREQ' , 'Määrittele päivä');
define('_ACA_LABELTIME_FREQ' , 'Määrittele aika');
define('_ACA_CRON_URL', 'Cron URL');
define('_ACA_CRON_FREQ', 'Taajuus');
define('_ACA_TITLE_CRONLIST', 'Cron lista');
define('_NEW_LIST', 'Luo uusi lista');

//title CRON form
define('_ACA_TITLE_FREQ', 'Cron muokkaa');
define('_ACA_CRON_SITE_URL', 'Ole hyvä ja anna toimiva sivuston url, alkaen http://');

### Mailings ###
define('_ACA_MAILING_ALL', 'Kaikki postitukset');
define('_ACA_EDIT_A', 'Muokkaa ');
define('_ACA_SELCT_MAILING', 'Valitse lista alasvetovalikosta lisätäksesi uusi postitus.');
define('_ACA_VISIBLE_FRONT', 'Näkyy julkisessa liittymässä');

// mailer
define('_ACA_SUBJECT', 'Otsikko');
define('_ACA_CONTENT', 'Sisältö');
define('_ACA_NAMEREP', '[NAME] = Tämä korvataan tilaajan antamalla nimellä, lähetät kohdistettua sähköpostia kun käytät tätä.<br />');
define('_ACA_FIRST_NAME_REP', '[FIRSTNAME] = Tämä korvataan tilaajan antamalla etunimellä.<br />');
define('_ACA_NONHTML', 'HTML:tön versio');
define('_ACA_ATTACHMENTS', 'Liitteet');
define('_ACA_SELECT_MULTIPLE', 'Pidä CTRL (tai command) pohjassa valitaksesi useita liitteitä.<br />' .
		'Tässä listassa näytetyt liitteet ovat liitehakemistossa, voit muuttaa sijaintia ohjauspaneelista.');
define('_ACA_CONTENT_ITEM', 'Sisältönimike');
define('_ACA_SENDING_EMAIL', 'Lähetetään sähköpostia');
define('_ACA_MESSAGE_NOT', 'Viestiä ei voitu lähettää');
define('_ACA_MAILER_ERROR', 'Postitusohjelma virhe');
define('_ACA_MESSAGE_SENT_SUCCESSFULLY', 'Viesti lähetetty onnistuneesti');
define('_ACA_SENDING_TOOK', 'Tämän postituksen lähettäminen kesti');
define('_ACA_SECONDS', 'sekuntia');
define('_ACA_NO_ADDRESS_ENTERED', 'Ei sähköpostiosoitteita tai tilaajia käytettävissä');
define('_ACA_CHANGE_SUBSCRIPTIONS', 'Muuta');
define('_ACA_CHANGE_EMAIL_SUBSCRIPTION', 'Muuta tilaustasi');
define('_ACA_WHICH_EMAIL_TEST', 'Anna sähköpostiosoite johon koeviesti lähetetään tai valitse esikatselu');
define('_ACA_SEND_IN_HTML', 'Lähetä HTML-muotoiltuna (HTML-listoille)?');
define('_ACA_VISIBLE', 'Näkyvä');
define('_ACA_INTRO_ONLY', 'Vain ingressi');

// stats
define('_ACA_GLOBALSTATS', 'Kokonaistilastot');
define('_ACA_DETAILED_STATS', 'Yksityiskohtaiset tilastot');
define('_ACA_MAILING_LIST_DETAILS', 'Listan yksityiskohdat');
define('_ACA_SEND_IN_HTML_FORMAT', 'Lähetetty HTML muodossa');
define('_ACA_VIEWS_FROM_HTML', 'Lukukerrat (HTML-viesteistä)');
define('_ACA_SEND_IN_TEXT_FORMAT', 'Lähetetty tekstimuodossa');
define('_ACA_HTML_READ', 'HTML luettu');
define('_ACA_HTML_UNREAD', 'HTML lukematta');
define('_ACA_TEXT_ONLY_SENT', 'Vain teksti');

// Configuration panel
// main tabs
define('_ACA_MAIL_CONFIG', 'Sähköposti');
define('_ACA_LOGGING_CONFIG', 'Lokit ja tilastot');
define('_ACA_SUBSCRIBER_CONFIG', 'Tilaajat');
define('_ACA_MISC_CONFIG', 'Sekalaista');
define('_ACA_MAIL_SETTINGS', 'Sähköpostiasetukset');
define('_ACA_MAILINGS_SETTINGS', 'Postitusasetukset');
define('_ACA_SUBCRIBERS_SETTINGS', 'Tilausasetukset');
define('_ACA_CRON_SETTINGS', 'Cron asetukset');
define('_ACA_SENDING_SETTINGS', 'Lähetysasetukset');
define('_ACA_STATS_SETTINGS', 'Tilastoasetukset');
define('_ACA_LOGS_SETTINGS', 'Lokiasetukset');
define('_ACA_MISC_SETTINGS', 'Sekalaiset asetukset');
// mail settings
define('_ACA_SEND_MAIL_FROM', 'Palautuvat viestit vastaanottava osoite<br/> (käytetään kaikille viesteillesi)');
define('_ACA_SEND_MAIL_NAME', 'Lähettäjän nimi');
define('_ACA_MAILSENDMETHOD', 'Postitusohjelma');
define('_ACA_SENDMAILPATH', 'Sendmail polku');
define('_ACA_SMTPHOST', 'SMTP palvelin');
define('_ACA_SMTPAUTHREQUIRED', 'SMTP vaatii tunnistamisen');
define('_ACA_SMTPAUTHREQUIRED_TIPS', 'Valitse Kyllä jos SMTP-palvelimesi vaatii tunnistamisen');
define('_ACA_SMTPUSERNAME', 'SMTP käyttäjätunnus');
define('_ACA_SMTPUSERNAME_TIPS', 'Jos palvelimesi vaatii tunnistamisen anna SMTP-käyttäjätunnus');
define('_ACA_SMTPPASSWORD', 'SMTP salasana');
define('_ACA_SMTPPASSWORD_TIPS', 'Jos palvelimesi vaatii tunnistamisen anna SMTP-salasana');
define('_ACA_USE_EMBEDDED', 'Käytä upotettuja kuvia');
define('_ACA_USE_EMBEDDED_TIPS', 'Valitse Kyllä jos liitettyyn sisältöön kuuluvat kuvat pitäisi upottaa viestiin HTML muodossa, tai Ei käyttääksesi oletusmerkintää joka linkittää kuvat viestiin sivustolta.');
define('_ACA_UPLOAD_PATH', 'Lataus/Liitehakemisto');
define('_ACA_UPLOAD_PATH_TIPS', 'Voit määritellä lataushankemiston.<br />' .
		'Varmista, että antamasi hakemisto on olemassa, muutoin luo se.');

// subscribers settings
define('_ACA_ALLOW_UNREG', 'Salli rekisteröitymättömät');
define('_ACA_ALLOW_UNREG_TIPS', 'Valitse Kyllä jos haluat sallia rekisteröitymättömien käyttäjien tilata listoja.');
define('_ACA_REQ_CONFIRM', 'Vaadi vahvistus');
define('_ACA_REQ_CONFIRM_TIPS', 'Valitse Kyllä jos vaadit että rekisteröitymättömät käyttäjät varmistavat sähköpostiosoiteensa.');
define('_ACA_SUB_SETTINGS', 'Tilausasetukset');
define('_ACA_SUBMESSAGE', 'Tilausosoite');
define('_ACA_SUBSCRIBE_LIST', 'Tilaa lista');

define('_ACA_USABLE_TAGS', 'Käytettävissä olevat merkinnät');
define('_ACA_NAME_AND_CONFIRM', '<b>[CONFIRM]</b> = Tämä luo napsautettavan linkin jolla tilaaja voi vahvistaa tilauksensa. Tämä on <strong>pakollinen</strong> jotta Acajoom toimii oikein.<br />'
.'<br />[NAME] = Tämä korvataan käyttäjän antamalla nimellä, lähetät kohdistettua sähköpostia käyttäessäsi tätä.<br />'
.'<br />[FIRSTNAME] = Tämä korvataan tilaajan etunimellä, etunimellä tarkoitetaan käyttäjän ensin syöttämään nimä.<br />');
define('_ACA_CONFIRMFROMNAME', 'Vahvistusviestien lähettäjän nimi');
define('_ACA_CONFIRMFROMNAME_TIPS', 'Anna lähettäjän nimi jota käytetään vahvistuksen vaativilla listoilla.');
define('_ACA_CONFIRMFROMEMAIL', 'Vahvistusviestien lähettäjän sähköpostiosoite');
define('_ACA_CONFIRMFROMEMAIL_TIPS', 'Anna lähettäjän sähköpostiosoite jota käytetään vahvistuksen vaativilla listoilla.');
define('_ACA_CONFIRMBOUNCE', 'Bounce osoite');
define('_ACA_CONFIRMBOUNCE_TIPS', 'Anna bounce osoite näytettäväksi vahvistuksen vaativilla listoilla.');
define('_ACA_HTML_CONFIRM', 'HTML vahvistus');
define('_ACA_HTML_CONFIRM_TIPS', 'Valitse Kyllä jos vahvistuksen vaativat listat ovat html-muotoisia käyttäjän sen salliessa.');
define('_ACA_TIME_ZONE_ASK', 'Kysy aikavyöhyke');
define('_ACA_TIME_ZONE_TIPS', 'Valitse Kyllä jos haluat kysyä käyttäjän aikavyöhykettä. Jonoon laitetut postituksen lähetetään aikavyöhykkeen perusteella milloin tarkoituksen mukaista');

 // Cron Set up
 define('_ACA_AUTO_CONFIG', 'Cron');
define('_ACA_TIME_OFFSET_URL', 'napsauta tästä asettaaksesi aikavyöhyke sivuston asetuksissa -> Paikallisasetukset');
define('_ACA_TIME_OFFSET_TIPS', 'Aseta palvelimesi aikavyöhyke niin että päiväys ja kellonaika ovat täsmällisesti oikein');
define('_ACA_TIME_OFFSET', 'Aikavyöhyke');
define('_ACA_CRON_DESC','<br />Käyttäen cron ajastusta voit asettaa automaattisia tehtäviä Joomla sivustollesi!<br />' .
		'Asettaaksesi sen käyttöön sinun täytyy lisätä seuraava komento ohjauspaneelisi crontabiin:<br />' .
		'<b>' . ACA_JPATH_LIVE . '/index2.php?option=com_acajoom&act=cron</b> ' .
		'<br /><br />Jos tarvitset apua asetuksissa tai sinulla on ongelmia, ole hyvä ja tutustu foorumiimme <a href="http://www.acajoom.com" target="_blank">http://www.acajoom.com</a>');
// sending settings
define('_ACA_PAUSEX', 'Pysähdy x sekunniksi aina asetetun määrän viestejä lähetettyäsi');
define('_ACA_PAUSEX_TIPS', 'Anna sekuntimäätä, jonka Acajoom antaa postitusohjelmalle viestien lähettämiseen ennen kuin jatkaa seuraavalla asetetun suuruisella erällä.');
define('_ACA_EMAIL_BET_PAUSE', 'Viestien määrä taukojen välillä');
define('_ACA_EMAIL_BET_PAUSE_TIPS', 'Montako viestiä lähetetään taukojen välillä.');
define('_ACA_WAIT_USER_PAUSE', 'Odota käyttäjän toimia ennen jatkamista');
define('_ACA_WAIT_USER_PAUSE_TIPS', 'Asettaa pitäisikö skriptin odottaa käyttäjältä hyväksyntää ennen kuin se jatkaa tauon jälkeen lähetystä.');
define('_ACA_SCRIPT_TIMEOUT', 'Skriptin timeout');
define('_ACA_SCRIPT_TIMEOUT_TIPS', 'Montako minuuttia skriptin tulee antaa toimia (0 tarkoittaa rajoittamatonta).');
// Stats settings
define('_ACA_ENABLE_READ_STATS', 'Ota käyttöön lukutilastot');
define('_ACA_ENABLE_READ_STATS_TIPS', 'Valitse Kyllä jos haluat tallentaa lokiin katselukertojen määrän. Tätä tekniikkaa voidaan käyttää vain html-muotoiltujen viestien kanssa');
define('_ACA_LOG_VIEWSPERSUB', 'Kirjaa katselut tilaajittain');
define('_ACA_LOG_VIEWSPERSUB_TIPS', 'Valitse Kyllä jos haluat tallentaa katselukerrat tilaajaa kohti. Tätä tekniikkaa voidaan käyttää vain html-muotoiltujen viestien kanssa');
// Logs settings
define('_ACA_DETAILED', 'Yksityiskohtaiset lokit');
define('_ACA_SIMPLE', 'Yksinkertaistetut lokit');
define('_ACA_DIAPLAY_LOG', 'Näytä lokit');
define('_ACA_DISPLAY_LOG_TIPS', 'Valitse Kyllä jos haluat näyttää lokin kun lähetys on käynnissä.');
define('_ACA_SEND_PERF_DATA', 'Lähetyksen suorituskyky');
define('_ACA_SEND_PERF_DATA_TIPS', 'Valitse Kyllä jos haluat Acajoomin lähettävän anonyymejä raportteja asetuksistasi, tilaajien määrästä listoilla ja ajasta joka kului viestien lähettämiseen. Tämä antaa meille käsityksen Acajoomin suorituskyvystä ja auttaa meitä parantamaan Acajoomia tulevassa kehitystyössä.');
define('_ACA_SEND_AUTO_LOG', 'Lähetä loki automaattivastaajista');
define('_ACA_SEND_AUTO_LOG_TIPS', 'Valitse Kyllä jos haluat lähettää sähköpostilokin joka kerta kun jono on käsitelty.  VAROITUS: tämä voi johtaa suureen viestimäärään.');
define('_ACA_SEND_LOG', 'Lähetysloki');
define('_ACA_SEND_LOG_TIPS', 'Pitäisikö lähetyksestä lähettää loki lähetyksen lähettäneen käyttäjän sähköpostiosoitteeseen.');
define('_ACA_SEND_LOGDETAIL', 'Yksityiskohtainen lähetysloki');
define('_ACA_SEND_LOGDETAIL_TIPS', 'Yksityiskohtainen loki sisältää onnistumis-/epäonnistumistiedon jokaisesta tilaajasta ja katsauksen tietoon. Yksinkertainen lähettää vain katsauksen.');
define('_ACA_SEND_LOGCLOSED', 'Lähetä loki jos yhteys katkeaa');
define('_ACA_SEND_LOGCLOSED_TIPS', 'Tällä asetuksella käyttäjä joka teki postituksen saa silti raportin sähköpostitse.');
define('_ACA_SAVE_LOG', 'Tallenna loki');
define('_ACA_SAVE_LOG_TIPS', 'Pitäisikö lähetysloki lisätä lokitiedoston loppuun.');
define('_ACA_SAVE_LOGDETAIL', 'Tallenna yksityiskohtainen loki');
define('_ACA_SAVE_LOGDETAIL_TIPS', 'Yksityiskohtainen loki sisältää onnistumis-/epäonnistumistiedon jokaisesta tilaajasta ja katsauksen tietoon. Yksinkertainen tallentaa vain katsauksen.');
define('_ACA_SAVE_LOGFILE', 'Tallenna lokitiedosto');
define('_ACA_SAVE_LOGFILE_TIPS', 'Tiedosto johon lokitieto liitetään. Tämä tiedosto voi kasvaa aika suureksi.');
define('_ACA_CLEAR_LOG', 'Tyhjennä loki');
define('_ACA_CLEAR_LOG_TIPS', 'Tyhjentää lokitiedoston.');

### control panel
define('_ACA_CP_LAST_QUEUE', 'Viimeinen käsitelty jono');
define('_ACA_CP_TOTAL', 'Kokonaissumma');
define('_ACA_MAILING_COPY', 'Postitus onnistuneesti kopioitu!');

// Miscellaneous settings
define('_ACA_SHOW_GUIDE', 'Näytä opas');
define('_ACA_SHOW_GUIDE_TIPS', 'Näytä opas alussa jotta uusien käyttäjien on helppo luoda uutiskirje, automaattivastaaja ja tehdä Acajoom asetukset oikein.');
define('_ACA_AUTOS_ON', 'Käytä automaattivastaajia');
define('_ACA_AUTOS_ON_TIPS', 'Valitse Ei jos et halua käyttää automaattivastaajia, kaikki automaattivastaaja-asetukset deaktivoidaan.');
define('_ACA_NEWS_ON', 'Käytä uutiskirjeitä');
define('_ACA_NEWS_ON_TIPS', 'Valitse Ei jos et halua käyttää uutiskirjeitä, kaikki uutiskirjeasetukset deaktivoidaan.');
define('_ACA_SHOW_TIPS', 'Näytä vihjeet');
define('_ACA_SHOW_TIPS_TIPS', 'Näytä vihjeet, jotta käyttäjät osaisivat käyttää Acajoomia tehokkaammin.');
define('_ACA_SHOW_FOOTER', 'Näytä alatunniste');
define('_ACA_SHOW_FOOTER_TIPS', 'Pitäisikö tekijänoikeustiedotealatunniste näyttää.');
define('_ACA_SHOW_LISTS', 'Näytä listat julkisessa liittymässä');
define('_ACA_SHOW_LISTS_TIPS', 'Kun käyttäjä ei ole rekisteröitynyt näytä lista listoista jotka he voivat tilata ja nappi uutiskirjeen arkistoon vai pelkästään kirjautumislomake rekisteröitymistä varten.');
define('_ACA_CONFIG_UPDATED', 'Asetukset on päivitetty!');
define('_ACA_UPDATE_URL', 'Päivitys URL');
define('_ACA_UPDATE_URL_WARNING', 'VAROITUS! Älä muuta tätä URL-osoitetta ellei Acajoomin tekninen tiimi ole sinun niin kehottanut tekemään.<br />');
define('_ACA_UPDATE_URL_TIPS', 'Esim.: http://www.ijoobi.com/update/ (sisällytä lopun kauttaviiva)');

// module
define('_ACA_EMAIL_INVALID', 'Antamasi sähköpostiosoite ei ole toimiva.');
define('_ACA_REGISTER_REQUIRED', 'Sinun täytyy rekisteröityä sivustolle ennen kuin voit tilata listoja.');

// Access level box
define('_ACA_OWNER', 'Listan luoja:');
define('_ACA_ACCESS_LEVEL', 'Aseta listan käyttöoikeustaso');
define('_ACA_ACCESS_LEVEL_OPTION', 'Käyttöoikeusasetukset');
define('_ACA_USER_LEVEL_EDIT', 'Valitse mikä käyttäjäryhmä voi muokata postitusta (julkisesta tai ylläpitoliittymästä) ');

//  drop down options
define('_ACA_AUTO_DAY_CH1', 'Päivittäin');
define('_ACA_AUTO_DAY_CH2', 'Päivittäin, ei viikonloppuisin');
define('_ACA_AUTO_DAY_CH3', 'Joka toinen päivä');
define('_ACA_AUTO_DAY_CH4', 'Joka toinen päivä, ei viikonloppuisin');
define('_ACA_AUTO_DAY_CH5', 'Viikoittain');
define('_ACA_AUTO_DAY_CH6', 'Joka toinen viikko');
define('_ACA_AUTO_DAY_CH7', 'Kuukausittain');
define('_ACA_AUTO_DAY_CH9', 'Vuosittain');
define('_ACA_AUTO_OPTION_NONE', 'Ei');
define('_ACA_AUTO_OPTION_NEW', 'Uudet käyttäjät');
define('_ACA_AUTO_OPTION_ALL', 'Kaikki käyttäjät');

//
define('_ACA_UNSUB_MESSAGE', 'Peruuta tilaus');
define('_ACA_UNSUB_SETTINGS', 'Peruutuksen asetukset');
define('_ACA_AUTO_ADD_NEW_USERS', 'Lisää käyttäjät automaattisesti?');

// Update and upgrade messages
define('_ACA_NO_UPDATES', 'Päivityksiä ei ole saatavilla.');
define('_ACA_VERSION', 'Acajoom versio');
define('_ACA_NEED_UPDATED', 'Tiedostot jotka tulee päivittää:');
define('_ACA_NEED_ADDED', 'Tiedostot jotka tulee lisätä:');
define('_ACA_NEED_REMOVED', 'Tiedostot jotka tulee poistaa:');
define('_ACA_FILENAME', 'Tiedostonimi:');
define('_ACA_CURRENT_VERSION', 'Nykyinen versio:');
define('_ACA_NEWEST_VERSION', 'Uusin versio:');
define('_ACA_UPDATING', 'Päivittää');
define('_ACA_UPDATE_UPDATED_SUCCESSFULLY', 'Tiedostot on päivitetty onnistuneesti.');
define('_ACA_UPDATE_FAILED', 'Päivitys epäonnistui!');
define('_ACA_ADDING', 'Lisää');
define('_ACA_ADDED_SUCCESSFULLY', 'Lisätty onnistuneesti.');
define('_ACA_ADDING_FAILED', 'Lisäys epäonnistui!');
define('_ACA_REMOVING', 'Poistaa');
define('_ACA_REMOVED_SUCCESSFULLY', 'Poistettu onnistuneesti.');
define('_ACA_REMOVING_FAILED', 'Poistaminen epäonnistui!');
define('_ACA_INSTALL_DIFFERENT_VERSION', 'Asenna toinen versio');
define('_ACA_CONTENT_ADD', 'Lisää sisältöä');
define('_ACA_UPGRADE_FROM', 'Tuo tietoja (uutiskirjeiden ja tilaajien tietoja) ');
define('_ACA_UPGRADE_MESS', 'Olemassa oleva datasi ei ole vaarassa. <br /> Tämä prosessi vain tuo uuden tiedon Acajoom tietokantaan.');
define('_ACA_CONTINUE_SENDING', 'Jatka lähetystä');

// Acajoom message
define('_ACA_UPGRADE1', 'Voit helposti tuoda käyttäjiä ja uutiskirjeitä ');
define('_ACA_UPGRADE2', ' Acajoomiin päivityspaneelissa.');
define('_ACA_UPDATE_MESSAGE', 'Uusi versio saatavilla! ');
define('_ACA_UPDATE_MESSAGE_LINK', 'Napsauta tästä päivittääksesi!');
define('_ACA_THANKYOU', 'Kiitos kun valitsit Acajoomin, Your communication partner!');
define('_ACA_NO_SERVER', 'Päivityspalvelin saavuttamattomissa, yritä myöhemmin uudelleen.');
define('_ACA_MOD_PUB', 'Acajoom modullia ei ole julkaistu.');
define('_ACA_MOD_PUB_LINK', 'Napsauta tästä julkaistaksesi sen!');
define('_ACA_IMPORT_SUCCESS', 'onnistuneesti tuotu');
define('_ACA_IMPORT_EXIST', 'tilaaja on jo tietokannassa');

// Acajoom\'s Guide
define('_ACA_GUIDE', '\'s Wizard');
define('_ACA_GUIDE_FIRST_ACA_STEP', '<p>Acajoomissa on monia hienoja ominaisuuksia ja tämä velho ohjaa sinut neljän helpon askeleen prosessin läpi jotta pääset alkuun uutiskirjeidesi ja automaattivastaajiesi kanssa!<p />');
define('_ACA_GUIDE_FIRST_ACA_STEP_DESC', 'Ensiksi, sinun täytyy perustaa lista.  Lista voi olla kahta eri tyyppiaä, joko uutiskirje tai automaattivastaaja.' .
		'  Listalla asetat kaikki asetukset jotka mahdollistavat uutiskirjeiden ja automaattivastaajien lähettämisen: lähettäjän nimen, ulkoasun, tilaajat, tervetulotoivotuksen jne...
<br /><br />Voit perustaa ensimmäisen listasi täällä: <a href="index2.php?option=com_acajoom&act=list" >Luo lista</a> ja napsauta Uusi nappulaa.');
define('_ACA_GUIDE_FIRST_ACA_STEP_UPGRADE', 'Acajoom tarjoaa sinulle helpon tavan tuoda kaiken datan vanhasta uutiskirjejärjestelmästäsi.<br />' .
		' Mene Tuonti välilehdelle ja valitsea aiempi uutiskirjejärjestelmäsi tuodaksesi vanhat uutiskirjeesi ja tilaajasi.<br /><br />' .
		'<span style="color:#FF5E00;" >TÄRKEÄÄ: tuonti on RISKITÖN eikä vaikuta mitenkään edellisen uutiskirjejärjestelmäsi dataan</span><br />' .
		'Tuonnin jälkeen voit hallita tilaajia ja postituksia suoraan Acajoomista.<br /><br />');
define('_ACA_GUIDE_SECOND_ACA_STEP', 'Hienoa, ensimmäinen listasi on perustettu!  Voit nyt kirjoittaa ensimmäisen %s.  Luodaksesi sen mene: ');
define('_ACA_GUIDE_SECOND_ACA_STEP_AUTO', 'Automaattivastaajien hallinta');
define('_ACA_GUIDE_SECOND_ACA_STEP_NEWS', 'Uutiskirjeiden hallinta');
define('_ACA_GUIDE_SECOND_ACA_STEP_FINAL', ' ja valitse %s. <br /> Valitse sitten %s alasvetovalikosta.  Luo ensimmäinen postituksesi napsauttamalla Uusi ');

define('_ACA_GUIDE_THRID_ACA_STEP_NEWS', 'Ennen kuin lähetät ensimmäisen uutiskirjeesi haluat ehkä tarkastaa sähköpostiasetukset.  ' .
		'Mene <a href="index2.php?option=com_acajoom&act=configuration" >asetukset sivulle</a> varmistaaksesi sähköpostiasetukset. <br />');
define('_ACA_GUIDE_THRID2_ACA_STEP_NEWS', '<br />Kun olet valmis siirry takaisin Uutiskirjeet kohtaan, valitse postituksesi ja napsauta Lähetä');

define('_ACA_GUIDE_THRID_ACA_STEP_AUTOS', 'Jotta automaattivastaajasi tulevat lähetetyiksi sinun pitää ensin luoda cron tehtävä palvelimellesi. ' .
		' Ole hyvä ja katso Cron välilehteä asetuspaneelissa.' .
		' <a href="index2.php?option=com_acajoom&act=configuration" >napsauta tästä</a> lukeaksesi lisää cron tehtävän luomisesta. <br />');

define('_ACA_GUIDE_MODULE', ' <br />Varmista myös että olet julkaissut Acajoom modullin jotta ihmiset voivat tilata listasi uutiskirjeet.');

define('_ACA_GUIDE_FOUR_ACA_STEP_NEWS', ' Voit nyt myös perustaa automaattivastaajan.');
define('_ACA_GUIDE_FOUR_ACA_STEP_AUTOS', ' Voit nyt myös perustaa uutiskirjeen.');

define('_ACA_GUIDE_FOUR_ACA_STEP', '<p><br />Voila! Olet nyt valmis viestimään tehokkaasti vieraidesi ja käyttäjiesi kanssa. Tämä velho päättyy heti kun olet aloittanut toisen postituksen tai voit kytkeä sen pois päältä <a href="index2.php?option=com_acajoom&act=configuration" >ohjauspaneelista</a>.' .
		'<br /><br />  Jos sinulla on kysymyksiä Acajoomin käytöstä, ole hyvä ja tutustu ' .
		'<a target="_blank" href="http://www.ijoobi.com/index.php?option=com_content&Itemid=72&view=category&layout=blog&id=29&limit=60" >dokumentaatioon</a>. ' .
		' Löydät myös paljon tietoa tehokkaasta viestinnästä tilaajiesi kanssa osoitteesta <a href="http://www.ijoobi.com/" target="_blank" >www.Acajoom.com</a>.' .
		'<p /><br /><b>Kiitos että käytät Acajoomia. Your Communication Partner!</b> ');
define('_ACA_GUIDE_TURNOFF', 'Velho kytketään nyt pois päältä!');
define('_ACA_STEP', 'STEP ');

// Acajoom Install
define('_ACA_INSTALL_CONFIG', 'Acajoom asetukset');
define('_ACA_INSTALL_SUCCESS', 'Asennus onnistui');
define('_ACA_INSTALL_ERROR', 'Asennuksessa tapahtui virhe');
define('_ACA_INSTALL_BOT', 'Acajoom liitännäinen (Bot)');
define('_ACA_INSTALL_MODULE', 'Acajoom modulli');
//Others
define('_ACA_JAVASCRIPT','!Varoitus! Javascriptin täytyy olla käytettävissä jotta komponentti toimisi oikein.');
define('_ACA_EXPORT_TEXT','Tilaajien vienti perustuu valitsemaasi listaan. <br />Vie tilaajat listalta');
define('_ACA_IMPORT_TIPS','Tuo tilaajat. Tiedon tiedostossa pitää olla seuraavaa muotoa: <br />' .
		'Nimi,sähköpostiosoite,vastaanotaHTML(1/0),<span style="color: rgb(255, 0, 0);">vahvistettu(1/0)</span>');
define('_ACA_SUBCRIBER_EXIT', 'on jo tilaaja');
define('_ACA_GET_STARTED', 'Napsauta tästä päästäksesi alkuun!');

//News since 1.0.1
define('_ACA_WARNING_1011','Varoitus: 1011: Päivitys ei toimi palvelimesi rajoituksista johtuen.');
define('_ACA_SEND_MAIL_FROM_TIPS', 'Anna lähettäjän osoitteena näkyvä sähköpostiosoite.');
define('_ACA_SEND_MAIL_NAME_TIPS', 'Anna lähettäjä nimenä näkyvä nimi.');
define('_ACA_MAILSENDMETHOD_TIPS', 'Valitse käytettävä postitusohjelma: PHP mail function, <span>Sendmail</span> or SMTP palvelin.');
define('_ACA_SENDMAILPATH_TIPS', 'Tämä on postipalvelimen polku');
define('_ACA_LIST_T_TEMPLATE', 'Mallipohja');
define('_ACA_NO_MAILING_ENTERED', 'Ei postitusta valittuna');
define('_ACA_NO_LIST_ENTERED', 'Ei listaa valittuna');
define('_ACA_SENT_MAILING' , 'Lähetä postitus');
define('_ACA_SELECT_FILE', 'Valitse tiedosto ');
define('_ACA_LIST_IMPORT', 'Valitse lista(t) joihin haluat tilaajat liittää.');
define('_ACA_PB_QUEUE', 'Tilaaja lisätty, mutta ongelmia hänen liittämisessään listaan/listoihin. Ole hyvä ja tarkasta manuaalisesti.');
define('_ACA_UPDATE_MESS' , '');
define('_ACA_UPDATE_MESS1' , 'Päivitystä suositellaan vakavasti!');
define('_ACA_UPDATE_MESS2' , 'Paikkaus ja pieniä korjauksia.');
define('_ACA_UPDATE_MESS3' , 'Uusi julkaisu.');
define('_ACA_UPDATE_MESS5' , 'Päivitys toimii vain Joomla 1.5\:ssä.');
define('_ACA_UPDATE_IS_AVAIL' , ' on saatavilla!');
define('_ACA_NO_MAILING_SENT', 'Postitus ei lähetetty!');
define('_ACA_SHOW_LOGIN', 'Näytä kirjautumislomake');
define('_ACA_SHOW_LOGIN_TIPS', 'Valitse Kyllä jos haluat näyttää kirjautumislomakkeen Acajoomin julkisen liittymän ohjauspaneelissa jotta käyttäjät voivat rekisteröityä sivustolle.');
define('_ACA_LISTS_EDITOR', 'Listan kuvauksen muokkain');
define('_ACA_LISTS_EDITOR_TIPS', 'Valitse Kyllä käyttääksesi HTML-muokkainta listan kuvaus kentän muokkaamiseen.');
define('_ACA_SUBCRIBERS_VIEW', 'Katso tilaajia');

//News since 1.0.2
define('_ACA_FRONTEND_SETTINGS' , 'Julkisen liittymän asetukset' );
define('_ACA_SHOW_LOGOUT', 'Näytä kirjaudu ulos nappula');
define('_ACA_SHOW_LOGOUT_TIPS', 'Valitse kyllä näyttääksesi kirjaudu ulos nappula Acajoomin julkisen liittymän ohjauspaneelissa.');

//News since 1.0.3 CB integration
define('_ACA_CONFIG_INTEGRATION', 'Integrointi');
define('_ACA_CB_INTEGRATION', 'Community Builder Integrointi');
define('_ACA_INSTALL_PLUGIN', 'Community Builder liitännäinen (Acajoom Integrointi) ');
define('_ACA_CB_PLUGIN_NOT_INSTALLED', 'Acajoom liitännäistä Community Builderille ei ole asennettu!');
define('_ACA_CB_PLUGIN', 'Listat rekisteröityessä');
define('_ACA_CB_PLUGIN_TIPS', 'Valitse Kyllä näyttääksesi listat Community Builderin rekisteröitymislomakkeella');
define('_ACA_CB_LISTS', 'Listojen ID\:t');
define('_ACA_CB_LISTS_TIPS', 'TÄMÄ ON PAKOLLINEN KENTTÄ. Anna niiden listojen ID-numerot pilkulla erotettuna, joiden haluat olevan käyttäjien tilattavissa ,  (0 tarkoittaa näytä kaikki)');
define('_ACA_CB_INTRO', 'Esittelyteksti');
define('_ACA_CB_INTRO_TIPS', 'Teksti joka näytetään ennen listausta. JÄTÄ TYHJÄKSI JÄTTÄÄKSESI NÄYTTÄMÄTTÄ.  Voit käyttää HTML-merkintää muokataksesi ulkonäköä.');
define('_ACA_CB_SHOW_NAME', 'Näytä listan nimi');
define('_ACA_CB_SHOW_NAME_TIPS', 'Valitse näytetäänkö listan nimi esittelytekstin jälkeen.');
define('_ACA_CB_LIST_DEFAULT', 'Lista oletusarvoisesti valittuna');
define('_ACA_CB_LIST_DEFAULT_TIPS', 'Valitse haluatko listojen ruutujen olevan oletusarvoisesti rastittuna.');
define('_ACA_CB_HTML_SHOW', 'Näytä tilaa HTML');
define('_ACA_CB_HTML_SHOW_TIPS', 'Valitse Kyllä antaaksesi käyttäjien valita haluavatko he vastaanottaa HTML-muotoiltuja viestejä. Valitse Ei pakottaakseni vastaanottamaan HTML-viestejä.');
define('_ACA_CB_HTML_DEFAULT', 'Oletuksena HTML-muotoilu');
define('_ACA_CB_HTML_DEFAULT_TIPS', 'Valitse tämä vaihtoehto asettaaksesi HTML-muodon oletukseksi. Jos Näytä tilaa HTML on asetettu arvoon Ei, tämä vaihtoehto on oletusarvo.');

// Since 1.0.4
define('_ACA_BACKUP_FAILED', 'Tiedostoa ei voitu varmistaa! Tiedostoa ei korvattu.');
define('_ACA_BACKUP_YOUR_FILES', 'Tiedostojen vanhat versiot on varmistettu seuraavaan hakemistoon:');
define('_ACA_SERVER_LOCAL_TIME', 'Palvelimen paikallinen aika');
define('_ACA_SHOW_ARCHIVE', 'Näytä Arkisto nappi');
define('_ACA_SHOW_ARCHIVE_TIPS', 'Valitse Kyllä näyttääksesi Arkisto napin julkisen liittymän uutiskirje listauksessa');
define('_ACA_LIST_OPT_TAG', 'Merkinnät');
define('_ACA_LIST_OPT_IMG', 'Kuvat');
define('_ACA_LIST_OPT_CTT', 'Sisältö');
define('_ACA_INPUT_NAME_TIPS', 'Anna kokonimesi (etunimi ensin)');
define('_ACA_INPUT_EMAIL_TIPS', 'Anna sähköpostiosoitteesi (Varmista että osoite on toimiva vastaanottaaksesi viestimme.)');
define('_ACA_RECEIVE_HTML_TIPS', 'Valitse kyllä vastaanottaaksesi HTML-muotoiltuja viestejä - Ei saadaksesi viestit vain tekstimuodossa');
define('_ACA_TIME_ZONE_ASK_TIPS', 'Valitse aikavyöhykkeesi.');

// Since 1.0.5
define('_ACA_FILES' , 'Tiedostot');
define('_ACA_FILES_UPLOAD' , 'Lataa palvelimelle');
define('_ACA_MENU_UPLOAD_IMG' , 'Lataa kuvat palvelimelle');
define('_ACA_TOO_LARGE' , 'Tiedosto on liian suuri. Suurin sallittu koko on');
define('_ACA_MISSING_DIR' , 'Kohdehakemistoa ei ole olemassa');
define('_ACA_IS_NOT_DIR' , 'Kohdehakemistoa ei ole olemassa tai se on tiedosto.');
define('_ACA_NO_WRITE_PERMS' , 'Kohdehakemistoon ei ole annettu kirjoitusoikeuksia.');
define('_ACA_NO_USER_FILE' , 'Et valinnut yhtään tiedostoa ladattavaksi.');
define('_ACA_E_FAIL_MOVE' , 'Tiedostoa on mahdoton siirtää.');
define('_ACA_FILE_EXISTS' , 'Kohdetiedosto on jo olemassa.');
define('_ACA_CANNOT_OVERWRITE' , 'Kohdetiedosto on jo olemassa tai sitä ei voitu korvata.');
define('_ACA_NOT_ALLOWED_EXTENSION' , 'Tiedostopääte ei ole sallittu.');
define('_ACA_PARTIAL' , 'Tiedosto ladattiin vain osittain.');
define('_ACA_UPLOAD_ERROR' , 'Latausvirhe:');
define('DEV_NO_DEF_FILE' , 'Tiedosto ladattiin vain osittain.');

// already exist but modified  added a <br/ on first line and added [SUBSCRIPTIONS] line>
define('_ACA_CONTENTREP', '[SUBSCRIPTIONS] = Tämä korvataan tilauslinkeillä.' .
		' Tämä on <strong>pakollinen</strong> jotta Acajoom toimisi oikein.<br />' .
		'Jos sisällytät tähän kenttään mitään muuta sisältöä se näytetään kaikissa tämän listan postituksissa.' .
		' <br />Lisää tilausviestisi loppuun.  Acajoom lisää automaattisesti linkin tilaajalle tietojensa muuttamiseen ja tilauksen peruuttamiseen.');

// since 1.0.6
define('_ACA_NOTIFICATION', 'Huomautus');  // shortcut for Email notification
define('_ACA_NOTIFICATIONS', 'Huomautukset');
define('_ACA_USE_SEF', 'SEF sähköpostiviesteissä');
define('_ACA_USE_SEF_TIPS', 'Asetusta Ei suositellaan.  Jos kuitenkin haluat että viesteihin sisällytetyt URL:t ovat SEF muotoiltuja valitse Kyllä.' .
		' <br /><b>Linkit toimivat samalla tavalla molemmissa tapauksissa.  Valinta Ei turvaa sen, että linkit toimivat aina vaikka muuttaisitkin SEFiä.</b> ');
define('_ACA_ERR_NB' , 'Virhe #: ERR');
define('_ACA_ERR_SETTINGS', 'Virheiden käsittelyn asetukset');
define('_ACA_ERR_SEND' ,'Lähetä virheraportti');
define('_ACA_ERR_SEND_TIPS' ,'Jos haluat Acajoomin parantuvan tuotteena valitse KYLLÄ.  Tämä lähettää meille virheraportin.  Joten sinun ei tarvitse erikseen raportoida bugejakaan ;-) <br /> <b>YKSITYISIÄ TIETOJA EI LÄHETETÄ</b>.  Emme edes tiedä miltä sivustolta virhe tulee. Lähetämme tiedot vain Acajoomin, PHP:n ja SQL:n asetuksista. ');
define('_ACA_ERR_SHOW_TIPS' ,'Valitse Kyllä näyttääkseni virhekoodin näytöllä.  Käytetään virheenkorjaamiseen. ');
define('_ACA_ERR_SHOW' ,'Näytä virheet');
define('_ACA_LIST_SHOW_UNSUBCRIBE', 'Näytä peruuta tilaus linkit');
define('_ACA_LIST_SHOW_UNSUBCRIBE_TIPS', 'Valitse Kyllä jos haluat näyttää tilauksen peruuttamis linkit postitusten pohjalla jotta käyttäjät voivat helposti muuttaa tilaustaan. <br /> Ei poistaa linkit käytöstä.');
define('_ACA_UPDATE_INSTALL', '<span style="color: rgb(255, 0, 0);">TÄRKEÄ HUOMAUTUS!</span> <br />Jos olet päivittämässä aiemmasta Acajoom versiosta sinun täytyy päivittää tietokantataulujesi rakenne napsauttamalal seuraavaa nappia (tietojesi eheyden säilyminen on turvattu)');
define('_ACA_UPDATE_INSTALL_BTN' , 'Päivitä taulut ja asetukset');
define('_ACA_MAILING_MAX_TIME', 'Jonon enimmäisaika' );
define('_ACA_MAILING_MAX_TIME_TIPS', 'Määrittele enimmäisaika sähköpostitusjonon käsittelylle. Suositellaan pidettäväksi 30 sekunnin ja 2 minuutin välillä.');

// virtuemart integration beta
define('_ACA_VM_INTEGRATION', 'VirtueMart Integraatio');
define('_ACA_VM_COUPON_NOTIF', 'Kuponki-ilmoituksen ID');
define('_ACA_VM_COUPON_NOTIF_TIPS', 'Määrittele sen postituksen ID numero, jonka mukana haluat lähettää kuponkeja asiakkaillesi.');
define('_ACA_VM_NEW_PRODUCT', 'Uutuustuoteilmoitusten ID');
define('_ACA_VM_NEW_PRODUCT_TIPS', 'Valitse sen postituksen ID numero, jonka mukana haluat ilmoittaa uutuustuotteista.');

// since 1.0.8
// create forms for subscriptions
define('_ACA_FORM_BUTTON', 'Luo lomake');
define('_ACA_FORM_COPY', 'HTML koodi');
define('_ACA_FORM_COPY_TIPS', 'Kopioi luotu HTML koodi HTML sivullesi.');
define('_ACA_FORM_LIST_TIPS', 'Valitse lista jonka haluat sisällyttää lomakkeeseen');
// update messages
define('_ACA_UPDATE_MESS4' , 'Ei voida päivittää automaattisesti.');
define('_ACA_WARNG_REMOTE_FILE' , 'Ei keinoa hakea etätiedostoa.');
define('_ACA_ERROR_FETCH' , 'Virhe tiedostoa noudettaessa.');

define('_ACA_CHECK' , 'Tarkasta');
define('_ACA_MORE_INFO' , 'Lisätietoja');
define('_ACA_UPDATE_NEW' , 'Päivitä uudempaan versioon');
define('_ACA_UPGRADE' , 'Päivitä korkeampaan tuotteeseen');
define('_ACA_DOWNDATE' , 'Palaa aiempaan versioon');
define('_ACA_DOWNGRADE' , 'Palaa perustuotteeseen');
define('_ACA_REQUIRE_JOOM' , 'Edellytä Joomlaa');
define('_ACA_TRY_IT' , 'Kokeile!');
define('_ACA_NEWER', 'Uudempi');
define('_ACA_OLDER', 'Vanhempi');
define('_ACA_CURRENT', 'Nykyinen');

// since 1.0.9
define('_ACA_CHECK_COMP', 'Kokeile yhtä muista komponenteista');
define('_ACA_MENU_VIDEO' , 'Video-oppaat');
define('_ACA_SCHEDULE_TITLE', 'Automaattinen aikatauludunktion asetus');
define('_ACA_ISSUE_NB_TIPS' , 'Numero luotu automaattisesti järjestelmässä' );
define('_ACA_SEL_ALL' , 'Kaikki postitukset');
define('_ACA_SEL_ALL_SUB' , 'Kaikki listat');
define('_ACA_INTRO_ONLY_TIPS' , 'Jos valitset tämän kohdan vain artikkelin ingressi sisällytetään positukseen sivustollesi johtavan Lue lisää -linkin kera.' );
define('_ACA_TAGS_TITLE' , 'Sisällön paikan merkki');
define('_ACA_TAGS_TITLE_TIPS' , 'Kopioi ja liitä tämä merkintä postitukseen siihen kohtaan johon haluat sisällön sijoitettavan.');
define('_ACA_PREVIEW_EMAIL_TEST', 'Anna sähköpostiosoite johon koeviesti lähetetään');
define('_ACA_PREVIEW_TITLE' , 'Esikatselu');
define('_ACA_AUTO_UPDATE' , 'Päivitysten ilmoitin');
define('_ACA_AUTO_UPDATE_TIPS' , 'Valitse kyllä jos haluat ilmoituksen uusista päivityksistä komponenttiisi. <br />TÄRKEÄÄ!! Vihjeiden näyttämisen tulee olla päällä jotta tämä toimisi.');

// since 1.1.0
define('_ACA_LICENSE' , 'Lisenssin tiedot');

// since 1.1.1
define('_ACA_NEW' , 'Uusi');
define('_ACA_SCHEDULE_SETUP', 'Jotta automaattivastaajat lähetettäisiin sinun pitää luoda aikataulu asetuksissa.');
define('_ACA_SCHEDULER', 'Ajastin');
define('_ACA_ACAJOOM_CRON_DESC' , 'jos sinulla ei ole pääsyä cron tehtävien hallintaan palvelimellasi, voit rekisteröityä ilmaisen Acajoom cron tilin käyttäjäksi osoitteessa:' );
define('_ACA_CRON_DOCUMENTATION' , 'Löydät lisätietoja Acajoom Ajastimen käytöstä seuraavasta osoitteesta:');
define('_ACA_CRON_DOC_URL' , '<a href="http://www.ijoobi.com/index.php?option=com_content&view=article&id=4249&catid=29&Itemid=72"
 target="_blank">http://www.ijoobi.com/index.php?option=com_content&Itemid=72&view=category&layout=blog&id=29&limit=60</a>' );
define( '_ACA_QUEUE_PROCESSED' , 'Jono käsitelty onnistuneesti...' );
define( '_ACA_ERROR_MOVING_UPLOAD' , 'Virhe tuodun tiedoston siirrossa' );

//since 1.1.4
define( '_ACA_SCHEDULE_FREQUENCY' , 'Ajastimen taajuus' );
define( '_ACA_CRON_MAX_FREQ' , 'Ajastimen enimmäistaajuus' );
define( '_ACA_CRON_MAX_FREQ_TIPS' , 'Aseta enimmäistaajuus jolla ajastin voi käydä ( minuuteissa ).  Tämä rajoittaa ajastimen toimintaa vaikka cron tehtävä olisikin ajastettu taajemmalle.' );
define( '_ACA_CRON_MAX_EMAIL' , 'Tehtävän enimmäisviestimäärä' );
define( '_ACA_CRON_MAX_EMAIL_TIPS' , 'Aseta enimmäismäärä yhden tehtävän sähköpostiviesteille (0 rajoittamaton).' );
define( '_ACA_CRON_MINUTES' , ' minuuttia' );
define( '_ACA_SHOW_SIGNATURE' , 'Näytä viestin alatunniste' );
define( '_ACA_SHOW_SIGNATURE_TIPS' , 'Haluatko mainostaa Acajoomia viestien alatunnisteessa.' );
define( '_ACA_QUEUE_AUTO_PROCESSED' , 'Automaattivastaajat käsitelty onnistuneesti...' );
define( '_ACA_QUEUE_NEWS_PROCESSED' , 'Ajastetut uutiskirjeet käsitelty onnistuneesti...' );
define( '_ACA_MENU_SYNC_USERS' , 'Synkronoi käyttäjät' );
define( '_ACA_SYNC_USERS_SUCCESS' , 'Käyttäjien synkronointi onnistui!' );

// compatibility with Joomla 15
if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', 'Kirjaudu ulos' );
if (!defined('_CMN_YES')) define( '_CMN_YES', 'Kyllä' );
if (!defined('_CMN_NO')) define( '_CMN_NO', 'Ei' );
if (!defined('_HI')) define( '_HI', 'Hei' );
if (!defined('_CMN_TOP')) define( '_CMN_TOP', 'Ylös' );
if (!defined('_CMN_BOTTOM')) define( '_CMN_BOTTOM', 'Alas' );
//if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', 'Logout' );

// For include title only or full article in content item tab in newsletter edit - p0stman911
define('_ACA_TITLE_ONLY_TIPS' , 'Jos valitset tämän kohdan vain artikkelin otsikko liitetään positukseen linkkinä artikkeliin sivustollasi.');
define('_ACA_TITLE_ONLY' , 'Vain otsikko');
define('_ACA_FULL_ARTICLE_TIPS' , 'Jos valitset tämän kohdan koko artikkeli sisällytetään postitukseen');
define('_ACA_FULL_ARTICLE' , 'Koko artikkeli');
define('_ACA_CONTENT_ITEM_SELECT_T', 'Valitse nimike lisättäväksi viestiin. <br />Kopioi ja liitä <b>sisällön paikanmerkki</b> postitukseen.  Voit valita koko artikkelin, vain ingressin tai vain otsikon numerolla (0, 1, tai 2 järjestyksessä). ');
define('_ACA_SUBSCRIBE_LIST2', 'Postituslista(t)');

// smart-newsletter function
define('_ACA_AUTONEWS', 'Äly-uutiskirje');
define('_ACA_MENU_AUTONEWS', 'Äly-uutiskirjeet');
define('_ACA_AUTO_NEWS_OPTION', 'Äly-uutiskirjeiden asetukset');
define('_ACA_AUTONEWS_FREQ', 'Uutiskirjeen taajuus');
define('_ACA_AUTONEWS_FREQ_TIPS', 'Aseta taajuus jolla haluat lähettää äly-uutiskirjeen.');
define('_ACA_AUTONEWS_SECTION', 'Artikkelien pääryhmä');
define('_ACA_AUTONEWS_SECTION_TIPS', 'Aseta pääryhmä josta haluat artikkelit valita.');
define('_ACA_AUTONEWS_CAT', 'Artikkelien ryhmä');
define('_ACA_AUTONEWS_CAT_TIPS', 'Aseta ryhmä josta haluat artikkelit valita (Kaikki tarkoittaa kaikkia pääryhmän artikkeleita).');
define('_ACA_SELECT_SECTION', 'Valitse pääryhmä');
define('_ACA_SELECT_CAT', 'Kaikki ryhmät');
define('_ACA_AUTO_DAY_CH8', 'Neljännesvuosittain');
define('_ACA_AUTONEWS_STARTDATE', 'Aloituspäivämäärä');
define('_ACA_AUTONEWS_STARTDATE_TIPS', 'Valitse päivämäärä jolloin haluat aloittaa äly-uutiskirjeen lähetykset.');
define('_ACA_AUTONEWS_TYPE', 'Sisällön käsittely');// how we see the content which is included in the newsletter
define('_ACA_AUTONEWS_TYPE_TIPS', 'Koko artikkeli: sisällyttää koko artikkelin uutiskirjeeseen.<br />' .
		'Vain ingressi: sisällyttää vain artikkelin ingressin uutiskirjeeseen.<br/>' .
		'Vain otsikko: sisällyttää vain artikkelin otsikon uutiskirjeeseen.');
define('_ACA_TAGS_AUTONEWS', '[SMARTNEWSLETTER] = Tämä korvataan äly-uutiskirjeellä.' );

//since 1.1.3
define('_ACA_MALING_EDIT_VIEW', 'Luo / Katso postituksia');
define('_ACA_LICENSE_CONFIG' , 'Lisenssi' );
define('_ACA_ENTER_LICENSE' , 'Anna lisenssinumero');
define('_ACA_ENTER_LICENSE_TIPS' , 'Anna lisenssinumerosi ja tallenna se.');
define('_ACA_LICENSE_SETTING' , 'Lisenssiasetukset' );
define('_ACA_GOOD_LIC' , 'Lisenssisi on voimassa.' );
define('_ACA_NOTSO_GOOD_LIC' , 'Lisenssisi ei ole voimassa: ' );
define('_ACA_PLEASE_LIC' , 'Ole hyvä ja ota yhteyttä Acajoom tukeen päivittääksesi lisenssisi ( license@ijoobi.com ).' );
define('_ACA_DESC_PLUS', 'Acajoom Plus on ensimmäinen jatkuva automaattivastaaja Joomla julkaisujärjestelmälle.  ' . _ACA_FEATURES );
define('_ACA_DESC_PRO', 'Acajoom PRO on paras postitusjärjestelmä Joomla julkaisujärjestelmälle.  ' . _ACA_FEATURES );

//since 1.1.4
define('_ACA_ENTER_TOKEN' , 'Anna poletti');

define('_ACA_ENTER_TOKEN_TIPS' , 'Anna polettinumerosi (token) jonka sait Acajoomin hankkiessasi. ');

define('_ACA_ACAJOOM_SITE', 'Acajoom sivusto:');
define('_ACA_MY_SITE', 'Minun sivustoni:');

define( '_ACA_LICENSE_FORM' , ' ' .
 		'Napsauta tästä mennäksesi lisenssilomakkeelle.</a>' );
define('_ACA_PLEASE_CLEAR_LICENSE' , 'Tyhjennä lisenssikenttä ja yritä uudelleen.<br />  Jos ongelma jatkuu, ' );

define( '_ACA_LICENSE_SUPPORT' , 'Jos sinulla on vielä kysyttävää, ' . _ACA_PLEASE_LIC );

define( '_ACA_LICENSE_TWO' , 'voit hankkia lisenssin manuaalisesti antamalla polettinumerosi ja sivuston URL-osoitteen (joka on merkitty vihreällä sivun ylälaidassa) lisenssilomakkeeseen. '
			. _ACA_LICENSE_FORM . '<br /><br/>' . _ACA_LICENSE_SUPPORT );

define('_ACA_ENTER_TOKEN_PATIENCE', 'Poletin tallentamisen jälkeen lisenssi luodaan automaattisesti. ' .
		' Tavallisesi poletti varmistetaan parissa minuutissa.  Joissain tapauksissa se voi kuitenkin kestää jopa 15 minuuttia.<br />' .
		'<br />Tarkasta tämä ohjauspaneeli uudelleen muutaman minuutin kuluttua.  <br /><br />' .
		'Jos et saa kelvollista lisenssiavainta 15 minuutissa, '. _ACA_LICENSE_TWO);


define( '_ACA_ENTER_NOT_YET' , 'Polettiasi ei ole vielä varmistettu.');
define( '_ACA_UPDATE_CLICK_HERE' , 'Ole hyvä ja käy <a href="http://www.ijoobi.com" target="_blank">www.ijoobi.com</a> ladataksesi uusimman version.');
define( '_ACA_NOTIF_UPDATE' , 'Saadaksesi ilmoituksen uusista päivityksistä, anna sähköpostiosoitteesi ja napsauta tilaa ');

define('_ACA_THINK_PLUS', 'Jos haluat enemmän postitusjärjestelmältäsi ajattele Plus!');
define('_ACA_THINK_PLUS_1', 'Jatkuvat automaatilähetykset');
define('_ACA_THINK_PLUS_2', 'Ajasta uutiskirjeesi toimitus ennalta määrätylle päivälle');
define('_ACA_THINK_PLUS_3', 'Ei enää palvelin rajoituksia');
define('_ACA_THINK_PLUS_4', 'ja paljon muuta...');

//since 1.2.2
define( '_ACA_LIST_ACCESS', 'Listan käyttöoikeudet' );
define( '_ACA_INFO_LIST_ACCESS', 'Aseta käyttäjäryhmä jolla on oikeus nähdä ja tilata lista' );
define( 'ACA_NO_LIST_PERM', 'Sinulla ei ole riittäviä oikeuksia tämän listan tilaamiseen' );

//Archive Configuration
 define('_ACA_MENU_TAB_ARCHIVE', 'Arkisto');
 define('_ACA_MENU_ARCHIVE_ALL', 'Arkistoi kaikki');

//Archive Lists
 define('_FREQ_OPT_0', 'Ei ollenkaan');
 define('_FREQ_OPT_1', 'Joka viikko');
 define('_FREQ_OPT_2', 'Joka toinen viikko');
 define('_FREQ_OPT_3', 'Joka kuukausi');
 define('_FREQ_OPT_4', 'Neljännesvuosittain');
 define('_FREQ_OPT_5', 'Vuosittain');
 define('_FREQ_OPT_6', 'Muu');

define('_DATE_OPT_1', 'Luontipäivä');
define('_DATE_OPT_2', 'Muokkauspäivä');

define('_ACA_ARCHIVE_TITLE', 'Automaattisen arkistoinnin taajuusasetukset');
define('_ACA_FREQ_TITLE', 'Arkistointitaajuus');
define('_ACA_FREQ_TOOL', 'Määrittele miten usein haluat Arkistoinnin hallinan arkistoivan sisältösi.');
define('_ACA_NB_DAYS', 'Päivien määrä');
define('_ACA_NB_DAYS_TOOL', 'Tämä on vain Muu vaihtoehtoa varten! Ole hyvä ja anna päivien määrä arkistointien välissä.');
define('_ACA_DATE_TITLE', 'Päiväyksen valinta');
define('_ACA_DATE_TOOL', 'Valitse arkistoidaanko luonti- vai muokkauspäivämäärän mukaan.');

define('_ACA_MAINTENANCE_TAB', 'Ylläpidon asetukset');
define('_ACA_MAINTENANCE_FREQ', 'Ylläpidon taajuus');
define( '_ACA_MAINTENANCE_FREQ_TIPS', 'Määrittelen miten usein haluat ylläpitorutiinin tapahtuvan.' );
define( '_ACA_CRON_DAYS' , 'tunti(a)' );

define( '_ACA_LIST_NOT_AVAIL', 'Ei listaa käytettävissä.');
define( '_ACA_LIST_ADD_TAB', 'Luo/Muokkaa' );

define( '_ACA_LIST_ACCESS_EDIT', 'Postituksen luonti/muokkausoikeudet' );
define( '_ACA_INFO_LIST_ACCESS_EDIT', 'Aseta käyttäjäryhmä jolla on oikeus luoda ja muokata postituksia' );
define( '_ACA_MAILING_NEW_FRONT', 'Luo uusi postitus' );

define('_ACA_AUTO_ARCHIVE', 'Automaattinen arkistointi');
define('_ACA_MENU_ARCHIVE', 'Automaattinen arkistointi');

//Extra tags:
define('_ACA_TAGS_ISSUE_NB', '[ISSUENB] = Tämä korvataan uutiskirjeen numerolla.');
define('_ACA_TAGS_DATE', '[DATE] = Tämä korvataan lähetyspäivällä.');
define('_ACA_TAGS_CB', '[CBTAG:{field_name}] = Tämä korvataan arvolla joka otetaan Community Builderin kentästä esim. [CBTAG:firstname] ');
define( '_ACA_MAINTENANCE', 'Ylläpito' );

define('_ACA_THINK_PRO', 'Kun sinulla on ammattimaisia tarpeita, käytä ammattimaisia komponentteja!');
define('_ACA_THINK_PRO_1', 'Äly-uutiskirjeet');
define('_ACA_THINK_PRO_2', 'Aseta käyttöoikeustaso listallesi');
define('_ACA_THINK_PRO_3', 'Määrittele kuka voi luoda ja muokata postituksia');
define('_ACA_THINK_PRO_4', 'Lisää merkintöjä: lisää CB kenttiä');
define('_ACA_THINK_PRO_5', 'Joomla sisältöjen automaattinen arkistointi');
define('_ACA_THINK_PRO_6', 'Tietokannan optimointi');

define('_ACA_LIC_NOT_YET', 'Your license is not yet valid.  Please check the license Tab in the configuration panel.');
define('_ACA_PLEASE_LIC_GREEN' , 'Make sure to provide the green information at the top of the tab to our support team.' );

define('_ACA_FOLLOW_LINK' , 'Hanki lisenssi');
define( '_ACA_FOLLOW_LINK_TWO' , 'Voit noutaa lisenssisi antamalla polettinumerosi ja sivustosi URL-osoitteen (joka on merkitty vihreällä sivun yläosassa) lisenssilomakkeeseen. ');
define( '_ACA_ENTER_TOKEN_TIPS2', ' Napsauta sitten Käytä nappia sivun oikeassa yläkulmassa.' );
define( '_ACA_ENTER_LIC_NB', 'Anna lisenssinumero' );
define( '_ACA_UPGRADE_LICENSE', 'Päivitä lisenssisi');
define( '_ACA_UPGRADE_LICENSE_TIPS' , 'Jos sait poletin lisenssin päivittämistä varten täytä se tähän ja napsauta sitten Käytä ja siirry numeroon <b>2</b> saadaksesi uuden lisenssinumeron.' );

define( '_ACA_MAIL_FORMAT', 'Merkistökoodaus' );
define( '_ACA_MAIL_FORMAT_TIPS', 'Mitä merkistökoodausta haluat käyttää postituksissasi, pelkkää tekstiä vai MIME:a' );
define( '_ACA_ACAJOOM_CRON_DESC_ALT', 'Jos sinulla ei ole pääsyä cron tehtävien hallintaan palvelimellasi voit käyttää ilmaista jCron komponenttia luodaksesi cron tehtävän sivustollesi.' );

//since 1.3.1
define('_ACA_SHOW_AUTHOR', 'Näytä kirjoittajan nimi');
define('_ACA_SHOW_AUTHOR_TIPS', 'Valitse Kyllä jos haluat listä kirjoittajan nimen kun lisäät artikkelin postitukseesi');

//since 1.3.5
define('_ACA_REGWARN_NAME','Ole hyvä ja anna nimesi.');
define('_ACA_REGWARN_MAIL','Ole hyvä ja anna kelvollinen sähköpostiosoite.');

//since 1.5.6
define('_ACA_ADDEMAILREDLINK_TIPS','Jos valitset Kyllä, käyttäjän sähköpostisoite lisätään parametriksi uudelleenohjaus-URL:n (uudelleenohjaus linkki modulliisi tai ulkoiseen Acajoom lomakkeeseen) loppuun.<br/>Se voi olla hyödyllistä jos haluat suorittaa erityisen skriptin uudelleenohjaussivulla.');
define('_ACA_ADDEMAILREDLINK','Lisää sähköposti uudelleenohjaukseen');

//since 1.6.3
define('_ACA_ITEMID','ItemId');
define('_ACA_ITEMID_TIPS','Tämä ItemId lisätään Acajoom linkkeihisi.');

//since 1.6.5
define('_ACA_SHOW_JCALPRO','jCalPRO');
define('_ACA_SHOW_JCALPRO_TIPS','Näytä integraatio välilehti jCalPRO:lle <br/>(vain jos jCalPRO asennettuna sivustollesi!)');
define('_ACA_JCALTAGS_TITLE','jCalPRO merkintä:');
define('_ACA_JCALTAGS_TITLE_TIPS','Kopioi ja liitä tämä merkintä postitukseesi siihen kohtaan johon haluat tapahtumen lisättävän.');
define('_ACA_JCALTAGS_DESC','Kuvaus:');
define('_ACA_JCALTAGS_DESC_TIPS','Valitse Kyllä jos haluat lisätä tapahtuman kuvauksen');
define('_ACA_JCALTAGS_START','Alkupäivä:');
define('_ACA_JCALTAGS_START_TIPS','Valitse Kyllä jos haluat lisätä tapahtuman alkupäivämäärän');
define('_ACA_JCALTAGS_READMORE','Lue lisää:');
define('_ACA_JCALTAGS_READMORE_TIPS','Valitse Kyllä jos haluat lisätä <b>Lue lisää -linkin</b> tälle tapahtumalle');
define('_ACA_REDIRECTCONFIRMATION','Uudelleenohjaus URL');
define('_ACA_REDIRECTCONFIRMATION_TIPS','Jos vaadit vahvistuksen sähköpostiosoitteelle, sähköpostiosoite vahvistetaan ja käyttäjä ohjataan uudelleen tähän URL-osoitteeseen jos hän napsauttaa vahvistuslinkkiä.');

//since 2.0.0 compatibility with Joomla 1.5
if(!defined('_CMN_SAVE') and defined('CMN_SAVE')) define('_CMN_SAVE',CMN_SAVE);
if(!defined('_CMN_SAVE')) define('_CMN_SAVE','Tallenna');
if(!defined('_NO_ACCOUNT')) define('_NO_ACCOUNT','Ei vielä tunnusta?');
if(!defined('_CREATE_ACCOUNT')) define('_CREATE_ACCOUNT','Rekisteröidy');
if(!defined('_NOT_AUTH')) define('_NOT_AUTH','Sinulla ei ole käyttöoikeutta tähän sivuun.');

//since 3.0.0
define('_ACA_DISABLETOOLTIP','Poista vihjeet käytöstä');
define('_ACA_DISABLETOOLTIP_TIPS', 'Poista vihjeet käytöstä julkisessa liittymässä');
define('_ACA_MINISENDMAIL', 'Käytä Mini SendMailia');
define('_ACA_MINISENDMAIL_TIPS', 'Jos palvelimesi käyttää Mini SendMailia, valitse tämä vaihtoehto jotta käyttäjän nimeä ei lisätä sähköpostin otsikkotietoihin');

//Since 3.1.5
define('_ACA_READMORE','Lue lisää...');
define('_ACA_VIEWARCHIVE','Napsauta tätä');

//since 4.0.0
define('_ACA_SHOW_JLINKS','Link Tracking');
define('_ACA_SHOW_JLINKS_TIPS','Enables the integration with jLinks to be able to do link tracking for each links in the newsletter.');

//since 4.1.0
define( '_ACA_MAIL_ENCODING', 'Mail encoding' );
define( '_ACA_MAIL_ENCODING_TIPS', 'What encoding format do you want to use UTF-8 (highly recommended) or ISO-8859-2' );
define( '_ACA_COPY_SUBJECT', 'Copy Subject' );s
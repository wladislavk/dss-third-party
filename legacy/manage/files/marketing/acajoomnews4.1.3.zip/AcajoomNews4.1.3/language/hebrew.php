﻿<?php
if ( !defined('_JEXEC') && defined('_VALID_MOS') ) define( '_JEXEC', true );
 defined('_JEXEC') or die('...Direct Access to this location is not allowed...');
/**
* <p>Hebrew language file</p>
* @authors Eszter Somos and Adam Segev
* @version Heb v0.1b
* @link http://www.joobisoft.com
*/

# This is an RTL language translation. You will need to edit the rest of the files to work with RTL.
# To display Acajoom correctly in your Joomla! admin ponel, you will need to install the hebrew Admin Panel.
# It can be found at www.joomla.co.il

### General ###
 //acajoom Description
define('_ACA_DESC_NEWS', 'Acajoom is a mailing lists, newsletters, auto-responders, and follow up tool to communication effectively with your users and customers.  ' .
		'Acajoom, Your Communication Partner!');
define('_ACA_FEATURES', 'Acajoom, your communication partner!');

// Type of lists
define('_ACA_NEWSLETTER', 'רשימת תפוצה');
define('_ACA_AUTORESP', 'מענה אוטומטי');
define('_ACA_AUTORSS', 'אוטומטי RSS');
define('_ACA_ECARD', 'כרטיס אלקטרוני');
define('_ACA_POSTCARD', 'גלויה');
define('_ACA_PERF', 'ביצועים');
define('_ACA_COUPON', 'קופון');
define('_ACA_CRON', 'תהליך קרון');
define('_ACA_MAILING', 'שולח');
define('_ACA_LIST', 'רשימה');

 //acajoom Menu
define('_ACA_MENU_LIST', 'רשימות');
define('_ACA_MENU_SUBSCRIBERS', 'מנויים');
define('_ACA_MENU_NEWSLETTERS', 'רשימת תפוצה');
define('_ACA_MENU_AUTOS', 'מענה אוטומטי');
define('_ACA_MENU_COUPONS', 'קופונים');
define('_ACA_MENU_CRONS', 'תהליכי קרון');
define('_ACA_MENU_AUTORSS', 'אוטומטי RSS');
define('_ACA_MENU_ECARD', 'כרטיס אלקטרוני');
define('_ACA_MENU_POSTCARDS', 'גלויות');
define('_ACA_MENU_PERFS', 'ביצועים');
define('_ACA_MENU_TAB_LIST', 'רשימות');
define('_ACA_MENU_MAILING_TITLE', 'דברי דואר');
define('_ACA_MENU_MAILING' , 'דברי דואר ל ');
define('_ACA_MENU_STATS', 'סטטיסטיקות ');
define('_ACA_MENU_STATS_FOR', 'סטטיסטיקות ל ');
define('_ACA_MENU_CONF', 'קונפיגורציה');
define('_ACA_MENU_UPDATE', 'ייבוא');
define('_ACA_MENU_ABOUT', 'אודות');
define('_ACA_MENU_LEARN', 'מרכז לימוד');
define('_ACA_MENU_MEDIA', 'מנהל מדיה');
define('_ACA_MENU_HELP', 'עזרה');
define('_ACA_MENU_CPANEL', 'לוח בקרה');
define('_ACA_MENU_IMPORT', 'ייבוא');
define('_ACA_MENU_EXPORT', 'ייצוא');
define('_ACA_MENU_SUB_ALL', 'עשה מנוי לכולם');
define('_ACA_MENU_UNSUB_ALL', 'בטל מנוי לכולם');
define('_ACA_MENU_VIEW_ARCHIVE', 'ארכיון');
define('_ACA_MENU_PREVIEW', 'תצוגה מקדימה');
define('_ACA_MENU_SEND', 'שלח');
define('_ACA_MENU_SEND_TEST', 'שלח מייל נסיון');
define('_ACA_MENU_SEND_QUEUE', 'תור תהליכים');
define('_ACA_MENU_VIEW', 'צפה');
define('_ACA_MENU_COPY', 'העתק');
define('_ACA_MENU_VIEW_STATS' , 'צפה בסטטיסטיקות');
define('_ACA_MENU_CRTL_PANEL' , ' לוח בקרה');
define('_ACA_MENU_LIST_NEW' , ' צור רשימה');
define('_ACA_MENU_LIST_EDIT' , ' ערוך רשימה');
define('_ACA_MENU_BACK', 'אחורה');
define('_ACA_MENU_INSTALL', 'התקנה');
define('_ACA_MENU_TAB_SUM', 'סיכום');
define('_ACA_STATUS' , 'מצב');

// messages
define('_ACA_ERROR' , ' התרחשה שגיאה ');
define('_ACA_SUB_ACCESS' , 'זכויות גישה');
define('_ACA_DESC_CREDITS', 'זכויות');
define('_ACA_DESC_INFO', 'מידע');
define('_ACA_DESC_HOME', 'דף בית');
define('_ACA_DESC_MAILING', 'רשימת תפוצה');
define('_ACA_DESC_SUBSCRIBERS', 'אנשים רשומים');
define('_ACA_PUBLISHED','מפורסם');
define('_ACA_UNPUBLISHED','לא מפורסם');
define('_ACA_DELETE','מחק');
define('_ACA_FILTER','סנן');
define('_ACA_UPDATE','עדכן');
define('_ACA_SAVE','שמור');
define('_ACA_CANCEL','בטל');
define('_ACA_NAME','שם');
define('_ACA_EMAIL','דואר אלקטרוני');
define('_ACA_SELECT','בחר');
define('_ACA_ALL','הכל');
define('_ACA_SEND_A', 'שלח ');
define('_ACA_SUCCESS_DELETED', ' נמחק בהצלחה');
define('_ACA_LIST_ADDED', 'רשימה נוצרה בהצלחה');
define('_ACA_LIST_COPY', 'רשימה הועתקה בהצלחה');
define('_ACA_LIST_UPDATED', 'רשימה עודכנה בהצלחה');
define('_ACA_MAILING_SAVED', 'דואר נשמר בהצלחה.');
define('_ACA_UPDATED_SUCCESSFULLY', 'עודכן בהצלחה');

### Subscribers information ###
//subscribe and unsubscribe info
define('_ACA_SUB_INFO', 'פרטי המנוי');
define('_ACA_VERIFY_INFO', 'נא ודא את הקישור ששלחת. הקישור או חלקו אינו תקין');
define('_ACA_INPUT_NAME', 'שם');
define('_ACA_INPUT_EMAIL', 'דואר אלקטרוני');
define('_ACA_RECEIVE_HTML', 'HTML האם ברצונך לקבל');
define('_ACA_TIME_ZONE', 'איזור זמן');
define('_ACA_BLACK_LIST', 'רשימה שחורה');
define('_ACA_REGISTRATION_DATE', 'תאריך רישום המנוי');
define('_ACA_USER_ID', 'מזהה משתמש');
define('_ACA_DESCRIPTION', 'תיאור');
define('_ACA_ACCOUNT_CONFIRMED', 'החשבון שלך אושר לשימוש');
define('_ACA_SUB_SUBSCRIBER', 'מנוי');
define('_ACA_SUB_PUBLISHER', 'מפרסם');
define('_ACA_SUB_ADMIN', 'מנהל');
define('_ACA_REGISTERED', 'רשום');
define('_ACA_SUBSCRIPTIONS', 'המנוי שלך');
define('_ACA_SEND_UNSUBCRIBE', 'שלח הודעה על ביטול מנוי');
define('_ACA_SEND_UNSUBCRIBE_TIPS', 'לחץ על כן על מנת לשלוח אישור ביטול מינוי');
define('_ACA_SUBSCRIBE_SUBJECT_MESS', 'נא ודא את הרשמתך');
define('_ACA_UNSUBSCRIBE_SUBJECT_MESS', 'וידוי ביטול מנוי');
define('_ACA_DEFAULT_SUBSCRIBE_MESS', '[NAME] שלום,<br />' .
		'רק עוד שלב אחד ותצורף לרישמת התפוצה נא לחץ על הקישור הבא בשביל לודא את הרישום' .
		'<br /><br />[CONFIRM]<br /><br />בכל שאלה יש לפנות למנהל האתר');
define('_ACA_DEFAULT_UNSUBSCRIBE_MESS', 'זהו מכתב אישור שהוסרת בהצלחה מרשימת התפוצה שלנו. צר לנו שהחלטת לבטל את המנוי. אם תחליט להרשם מחדש בעתיד, תוכל לעשות זאת באתר שלנו.');

// Acajoom subscribers
define('_ACA_SIGNUP_DATE', 'תהליך רישום');
define('_ACA_CONFIRMED', 'מאושר');
define('_ACA_SUBSCRIB', 'הרשם');
define('_ACA_HTML', 'HTML דואר');
define('_ACA_RESULTS', 'תוצאות');
define('_ACA_SEL_LIST', 'בחר רשימה');
define('_ACA_SEL_LIST_TYPE', '- בחר סוג רשימה -');
define('_ACA_SUSCRIB_LIST', 'רשימה של כל המנויים');
define('_ACA_SUSCRIB_LIST_UNIQUE', 'רשומים ל ');
define('_ACA_NO_SUSCRIBERS', 'לא נמצאו מנויים לרשימת תפוצה זו');
define('_ACA_COMFIRM_SUBSCRIPTION', 'נשלח אליך דואר אלקטרוני לאישור. נא לבדוק דואר אלקטרוני וללחוץ על הקישור המצורף.<br />' .
		'הינך צריך לאשר את כתובת הדואר אלקטרוני שלך לפני שהחשבון שלך יופעל.');
define('_ACA_SUCCESS_ADD_LIST', 'צורפת לרשימה בהצלחה.');


 // Subcription info
define('_ACA_CONFIRM_LINK', 'לחץ כאן בכדי לאשר את המנוי שלך');
define('_ACA_UNSUBSCRIBE_LINK', 'לחץ כאן בכדי לבטל את המנוי שלך');
define('_ACA_UNSUBSCRIBE_MESS', 'כתובת הדואר אלקטרוני שלך הוצאה מרשימת התפוצה שלנו');

define('_ACA_QUEUE_SENT_SUCCESS' , 'כל דברי הדואר המתוזמנים נשלחו בהצלחה');
define('_ACA_MALING_VIEW', 'צפה בכל דברי הדואר');
define('_ACA_UNSUBSCRIBE_MESSAGE', 'האם אתה בטוח שהינך רוצה לבטל את המנוי שלך?');
define('_ACA_MOD_SUBSCRIBE', 'הרשם');
define('_ACA_SUBSCRIBE', 'הרשם');
define('_ACA_UNSUBSCRIBE', 'בטל הרשמה');
define('_ACA_VIEW_ARCHIVE', 'צפה בארכיון');
define('_ACA_SUBSCRIPTION_OR', ' או לחץ כאן על מנת לעדכן את פרטיך');
define('_ACA_EMAIL_ALREADY_REGISTERED', 'כתובת דואר אלקטרוני זו כבר רשומה במאגר');
define('_ACA_SUBSCRIBER_DELETED', 'מנוי נמחק בהצלחה');


### UserPanel ###
 //User Menu
define('_UCP_USER_PANEL', 'לוח בקרת משתמש');
define('_UCP_USER_MENU', 'תפריט משתמש');
define('_UCP_USER_CONTACT', 'המנויים שלי');
 //Acajoom Cron Menu
define('_UCP_CRON_MENU', 'ניהול משימות קרון');
define('_UCP_CRON_NEW_MENU', 'קרון חדש');
define('_UCP_CRON_LIST_MENU', 'הצג את הקרון שלי');
 //Acajoom Coupon Menu
define('_UCP_COUPON_MENU', 'ניהול קופונים');
define('_UCP_COUPON_LIST_MENU', 'רשימת קופונים');
define('_UCP_COUPON_ADD_MENU', 'הוסף קופון');

### lists ###
// Tabs
define('_ACA_LIST_T_GENERAL', 'תיאור');
define('_ACA_LIST_T_LAYOUT', 'מערך');
define('_ACA_LIST_T_SUBSCRIPTION', 'מנוי');
define('_ACA_LIST_T_SENDER', 'מידע על השלוח');

define('_ACA_LIST_TYPE', 'סוג רשימה');
define('_ACA_LIST_NAME', 'שם הרשימה');
define('_ACA_LIST_ISSUE', 'מספר מהדורה');
define('_ACA_LIST_DATE', 'תהליך שליחה');
define('_ACA_LIST_SUB', 'נושא דואר');
define('_ACA_ATTACHED_FILES', 'קבצים מצורפים');
define('_ACA_SELECT_LIST', 'נא לבחור רשימה לערוך');

// Auto Responder box
define('_ACA_AUTORESP_ON', 'סוג רשימה');
define('_ACA_AUTO_RESP_OPTION', 'אפשרויות מענה אוטומטי');
define('_ACA_AUTO_RESP_FREQ', 'מנויים יכולים לבחור דחיפות');
define('_ACA_AUTO_DELAY', 'דחיה בימים');
define('_ACA_AUTO_DAY_MIN', 'תדירות מינימלית');
define('_ACA_AUTO_DAY_MAX', 'תדירות מקסימלית');
define('_ACA_FOLLOW_UP', 'פרט מעקב מענה אוטומטי');
define('_ACA_AUTO_RESP_TIME', 'מנויים יכולים לבחור שעה');
define('_ACA_LIST_SENDER', 'שולח הרשימה');

define('_ACA_LIST_DESC', 'תיאור הרשימה');
define('_ACA_LAYOUT', 'מערך');
define('_ACA_SENDER_NAME', 'שם השולח');
define('_ACA_SENDER_EMAIL', 'דואר אלקטרוני השולח');
define('_ACA_SENDER_BOUNCE', 'כתובת באונץ של השולח');
define('_ACA_LIST_DELAY', 'עיכוב');
define('_ACA_HTML_MAILING', 'HTMLב שליחה?');
define('_ACA_HTML_MAILING_DESC', 'אם תשנה את זה, תצטרך לשמור ולחזור למסך זה על מנת לראות את השינויים');
define('_ACA_HIDE_FROM_FRONTEND', 'להחביא מהדף הראשי?');
define('_ACA_SELECT_IMPORT_FILE', 'בחר את הקובץ שהנך רוצה לייבא');;
define('_ACA_IMPORT_FINISHED', 'תהליך ייבוא סיים');
define('_ACA_DELETION_OFFILE', 'מחיקת הקובץ');
define('_ACA_MANUALLY_DELETE', 'נכשל, הינך צריך למחוק את הקובץ בצורה ידנים');
define('_ACA_CANNOT_WRITE_DIR', 'לא יכול לכתוב תיקיה');
define('_ACA_NOT_PUBLISHED', 'לא יכול לשלוח את דברי הדואר, הרשימה אינה מפורסמת');

//  List info box
define('_ACA_INFO_LIST_PUB', 'לחץ על כן על מנת לפרסם את הרשימה');
define('_ACA_INFO_LIST_NAME', 'הכנס את שם הרשימה כאן. תוכל לזהות את הרשימה לפי השם שתכניס');
define('_ACA_INFO_LIST_DESC', 'הכנס הסבר קצר אודות הרשימה. ההסבר יהיה גלוי למבקרי האתר ומקבלי הדואר אלקטרוני');
define('_ACA_INFO_LIST_SENDER_NAME', 'הכנס את שם שולח הדואר אלקטרוני. השם שתכניס יהיה גלוי כאשר תשלח דואר אלקטרוני');
define('_ACA_INFO_LIST_SENDER_EMAIL', 'הכנס את כתובת הדואר אלקטרוני שממנה תשלח ההודעות');
define('_ACA_INFO_LIST_SENDER_BOUNCED', 'הכנס את כתובת הדואר אלקטרוני שאליה משתמשים יכולים להגיב. מומלץ בחום להשתמש באותה הכתובת שהזנת כדואר אלקטרוני שולח בכדי למנוע בעיות עם מסנני דואר אלקטרוני זבל');
define('_ACA_INFO_LIST_AUTORESP', 'בחר סוג דברי דואר מהרשימה <br />' .
		'רשימת תפוצה: רשימה רגילה<br />' .
		'מענה אוטומטי: מענה אוטומטי הוא רשימה שנשלחת בצורה אוטומטית דרך האתר בזמנים קבועים');
define('_ACA_INFO_LIST_FREQUENCY', 'אפשר למשתמש לבחור בכל כמה זמן הוא מקבל את רשימת התפוצה');
define('_ACA_INFO_LIST_TIME', 'אפשר למשתמש לבחור באיזה זמן הוא מעדיף לקבל את רשימת התפוצה');
define('_ACA_INFO_LIST_MIN_DAY', 'הגדר את התדירות המינימלית בה משתמש יכול לבחור לקבל את הרשימה');
define('_ACA_INFO_LIST_DELAY', 'פרט את העכוב בין מענה אוטומטי זה לבין הקודם');
define('_ACA_INFO_LIST_DATE', 'ציין את התאריך בו תרצה לפרסם את רשימת התפוצה אם הינך רוצה לעכב את הפרסום. <br /> FORMAT : YYYY-MM-DD HH:MM:SS');
define('_ACA_INFO_LIST_MAX_DAY', 'הגדר מהי התדירות המקסימלית בו משתמש יכול לבחור לקבל את רשימת התפוצה');
define('_ACA_INFO_LIST_LAYOUT', 'הזן את המערך של רשימת התפוצה כאן. הינך יכול להזין כל מערך לרשימת התפוצה שלך כאן');
define('_ACA_INFO_LIST_SUB_MESS', 'הודעה זו תשלח למנוי כאשר המנוי נרשם. הינך יכול להגדיר את הטקסט כאן');
define('_ACA_INFO_LIST_UNSUB_MESS', 'הודעה זו תשלח למנוי כאשר המנוי מבטל את הרישום שלו. הינך יכול להכניס כל הודעה שתרצה כאן');
define('_ACA_INFO_LIST_HTML', 'סמן וי בתיבת הסימון אם ברצונך לשלוח דואר ב HTML.');
define('_ACA_INFO_LIST_HIDDEN', 'לחץ על כן בשביל להחביא את הרשימה מפני מבקרים באתר. למשתמשים לא תהיה אפשרות להרשם אך לך תהיה האפשרות לשלוח דואר.');
define('_ACA_INFO_LIST_ACA_AUTO_SUB', 'האם ברצונך לרשום משתמשים לרשימה זו בצורה אוטומטית? משתמש חדש: ירשום כל משתמש חדש שנרשם לאתר. כל המשתמשים: ירשום כל משתמש רשום במאגר מידע');
define('_ACA_INFO_LIST_ACC_LEVEL', 'האם ברצונך לרשום משתמשים לרשימה זו בצורה אוטומטית? משתמש חדש: ירשום כל משתמש חדש שנרשם לאתר. כל המשתמשים: ירשום כל משתמש רשום במאגר מידע');
define('_ACA_INFO_LIST_ACC_USER_ID', 'בחר את רמת הגישה של קבוצת המשתמשים שהינך רוצה לאפשר עריכה. קבוצת מהשתמשים הזו ומעלה תוכל לערוך את רשימת התפוצה ולשלוח אותה מהפאנל ניהול ומהאתר עצמו.');
define('_ACA_INFO_LIST_FOLLOW_UP', 'אם הינך רוצה שהמענה האוטומטי יעביר לאחד אחר ברגע שהוא מגיע להודעה האחרונה, הינך יכול לציין כאן את המענה האוטומטי הבא');
define('_ACA_INFO_LIST_ACA_OWNER', 'זהו המזהה של יוצר הרשימה');
define('_ACA_INFO_LIST_WARNING', '   אופציה אחרונה זו זמינה רק פעם אחת בזמן יצירת הרשימה');
define('_ACA_INFO_LIST_SUBJET', ' נושא הדואר. זהו הנושא של הדואר שהמנוי יקבל');
define('_ACA_INFO_MAILING_CONTENT', 'זהו גוף הדואר שתרצה לשלוח');
define('_ACA_INFO_MAILING_NOHTML', 'הכנס את גוף הדואר שתרצה לשלוח למנויים שבחרו לקבל רק הודעות טקסט. אם תשאיר שדה זה ריק,   טקסט לטקסט בלבדhtml  גומלה תהפוך את ה');
define('_ACA_INFO_MAILING_VISIBLE', 'לחץ על כן בשביל להראות את הדואר באתר הראשי');
define('_ACA_INSERT_CONTENT', 'הכנס תוכן קיים');

// Coupons
define('_ACA_SEND_COUPON_SUCCESS', 'קופון נשלח בהצלחה');
define('_ACA_CHOOSE_COUPON', 'בחר קופון');
define('_ACA_TO_USER', ' למשתמש זה');

### Cron options
//drop down frequency(CRON)
define('_ACA_FREQ_CH1', 'כל שעות');
define('_ACA_FREQ_CH2', 'כל 6 שעות');
define('_ACA_FREQ_CH3', 'כל 12 שעות');
define('_ACA_FREQ_CH4', 'יומית');
define('_ACA_FREQ_CH5', 'שבועית');
define('_ACA_FREQ_CH6', 'חודשית');
define('_ACA_FREQ_NONE', 'לא');
define('_ACA_FREQ_NEW', 'משתמשים חדשים');
define('_ACA_FREQ_ALL', 'כל המשתמשים');

//Label CRON form
define('_ACA_LABEL_FREQ', 'אקאגום קרון?');
define('_ACA_LABEL_FREQ_TIPS', 'לחץ כן אם ברצונך להשתמש בזה לקרון אקאגום. לחץ על לא בשביל כל פעולת קרון אחרת<br />' .
		'אם תלחץ על כן, אינך צריך לציין את כתובת הקרון. היא תוסף באופן אוטומטי');
define('_ACA_SITE_URL' , 'כתובת האתר שלך');
define('_ACA_CRON_FREQUENCY' , 'תדירות קרון');
define('_ACA_STARTDATE_FREQ' , 'תאריך התחלה');
define('_ACA_LABELDATE_FREQ' , 'ציין תאריך');
define('_ACA_LABELTIME_FREQ' , 'ציין שעה');
define('_ACA_CRON_URL', 'כתובת קרון');
define('_ACA_CRON_FREQ', 'תדירות');
define('_ACA_TITLE_CRONLIST', 'רשימת קרון');
define('_NEW_LIST', 'צור רשימה חדשה');

//title CRON form
define('_ACA_TITLE_FREQ', 'ערוך קרון');
define('_ACA_CRON_SITE_URL', 'אנא הזן כתובת אתר חוקית שמתחילה ב HTTP://');

### Mailings ###
define('_ACA_MAILING_ALL', 'כל הדואר');
define('_ACA_EDIT_A', 'ערוך ');
define('_ACA_SELCT_MAILING', 'נא בחר רשימה מתוך הרשימה הבאה על מנת להוסיף דבר דואר חדש');
define('_ACA_VISIBLE_FRONT', 'נראה באתר?');

// mailer
define('_ACA_SUBJECT', 'נושא');
define('_ACA_CONTENT', 'תוכן');
define('_ACA_NAMEREP', '[NAME] = תג זה יוחלף בשם בו השתמש המנוי בזמן הרישום<br />');
define('_ACA_FIRST_NAME_REP', '[FIRSTNAME] = תג זה יוחלף בשמו הראשון של המנוי<br />');
define('_ACA_NONHTML', 'גרסאת טקסט');
define('_ACA_ATTACHMENTS', 'קבצים מצורפים');
define('_ACA_SELECT_MULTIPLE', 'החזק את קונטרול או קומאנד על מנת לבחור בצירופים מרובים<br />' .
		'הקבצים המוצגים ברשימת צירופים זו נמצאים בתיקית הצירופים. הינך יכול לשנות את מיקום שמירת הקבצים ב לוח הקונפיגורציה.');
define('_ACA_CONTENT_ITEM', 'פריט תוכן');
define('_ACA_SENDING_EMAIL', 'שולח דואר');
define('_ACA_MESSAGE_NOT', 'שליחת ההודעה נכשלה');
define('_ACA_MAILER_ERROR', 'שגיאה בתוכנת השליחה');
define('_ACA_MESSAGE_SENT_SUCCESSFULLY', 'ההודעה נשלחה בהצלחה');
define('_ACA_SENDING_TOOK', 'לשליחת דבר דואר זה, נדרשו');
define('_ACA_SECONDS', 'שניות');
define('_ACA_NO_ADDRESS_ENTERED', 'לא הוכנס כתובת דואר או מנוי');
define('_ACA_CHANGE_SUBSCRIPTIONS', 'שינוי');
define('_ACA_CHANGE_EMAIL_SUBSCRIPTION', 'שנה את המנוי שלך');
define('_ACA_WHICH_EMAIL_TEST', 'ציין את כתובת הדואר אליה תשלח הודעת בדיקה או בחר תצוגה מקדימה');
define('_ACA_SEND_IN_HTML', 'שלח בפורמט HTML');
define('_ACA_VISIBLE', 'נראה');
define('_ACA_INTRO_ONLY', 'הקדמה בלבד');

// stats
define('_ACA_GLOBALSTATS', 'סטטיסטיקות גלובליות');
define('_ACA_DETAILED_STATS', 'סטטיסטקות בפרטי פרטים');
define('_ACA_MAILING_LIST_DETAILS', 'פרטי רשימה');
define('_ACA_SEND_IN_HTML_FORMAT', 'שלח בפורמט HTML');
define('_ACA_VIEWS_FROM_HTML', 'צפיות מדואר HTML');
define('_ACA_SEND_IN_TEXT_FORMAT', 'שלח בפורמט טקסט');
define('_ACA_HTML_READ', 'HTML נקרא');
define('_ACA_HTML_UNREAD', 'HTML לא נקרא ');
define('_ACA_TEXT_ONLY_SENT', 'טקסט בלבד');

// Configuration panel
// main tabs
define('_ACA_MAIL_CONFIG', 'דואר');
define('_ACA_LOGGING_CONFIG', 'תיעוד וסטטיסטיקות');
define('_ACA_SUBSCRIBER_CONFIG', 'מנויים');
define('_ACA_MISC_CONFIG', 'שונות');
define('_ACA_MAIL_SETTINGS', 'הגדרות דואר');
define('_ACA_MAILINGS_SETTINGS', 'הגדרות דיוור');
define('_ACA_SUBCRIBERS_SETTINGS', 'הגדרות מנוי');
define('_ACA_CRON_SETTINGS', 'הגדרות קרון');
define('_ACA_SENDING_SETTINGS', 'הגדרות שליחה');
define('_ACA_STATS_SETTINGS', 'הגדרות סטטיסטיקה');
define('_ACA_LOGS_SETTINGS', 'הגדרות תיעוד');
define('_ACA_MISC_SETTINGS', 'הגדרות שונות');
// mail settings
define('_ACA_SEND_MAIL_FROM', 'מכתובת דואר');
define('_ACA_SEND_MAIL_NAME', 'משם:');
define('_ACA_MAILSENDMETHOD', 'שיטת שליחה');
define('_ACA_SENDMAILPATH', 'Sendmail path');
define('_ACA_SMTPHOST', 'SMTP host');
define('_ACA_SMTPAUTHREQUIRED', 'SMTP Authentication required');
define('_ACA_SMTPAUTHREQUIRED_TIPS', 'Select yes if your SMTP server requires authentication');
define('_ACA_SMTPUSERNAME', 'SMTP username');
define('_ACA_SMTPUSERNAME_TIPS', 'Enter the SMTP username when your SMTP server requires authentication');
define('_ACA_SMTPPASSWORD', 'SMTP password');
define('_ACA_SMTPPASSWORD_TIPS', 'Enter the SMTP password when your SMTP server requires authentication');
define('_ACA_USE_EMBEDDED', 'השתמש בתמונות מוטמעות');
define('_ACA_USE_EMBEDDED_TIPS', 'בחר כן אם התמונות בתוכן המצורף צריכות להיות מוטמעות בהודעת הדואר להודעות אייץ טי אם אל, או לא על מנת להשתמש בטגיות ברירת מחדל שמקשרות לתמונות באתר.');
define('_ACA_UPLOAD_PATH', 'העלה/צירופים path');
define('_ACA_UPLOAD_PATH_TIPS', 'הינך יכול לציין תיקית העלאה<br />' .
		'וודא שהתיקיה שציינת קיימת. אם היא לא קיימת, צור אותה');

// subscribers settings
define('_ACA_ALLOW_UNREG', 'הרשה לא רשומים');
define('_ACA_ALLOW_UNREG_TIPS', 'לחץ כן אם ברצונך להרשות למשתמשים להרשם לרשימות ללא הרשמה לאתר');
define('_ACA_REQ_CONFIRM', 'דרוש אישור?');
define('_ACA_REQ_CONFIRM_TIPS', 'לחץ כן אם אתה רוצה לדרוש שמנויים לא רשומים יאשרו את כתובת הדואר שלהם');
define('_ACA_SUB_SETTINGS', 'הגדרות מינוי');
define('_ACA_SUBMESSAGE', 'דואר אלקטרוני מינוי');
define('_ACA_SUBSCRIBE_LIST', 'עשה מינוי לרשימת התפוצה');

define('_ACA_USABLE_TAGS', 'טגיות ניתנות לשימוש');
define('_ACA_NAME_AND_CONFIRM', '<b>[CONFIRM]</b> = זה יוצר קישור שאפשר ללחוץ עליו, שבו המנויים יכולים לאשר את המנוי שלהם. זה דרוש על מנת לגרום לאקאגום לעבוד בצורה נכונה.<br />'
.'<br />[NAME] = זה יוחלף בשם של המנוי שהכנסת. אתה תשלח דואר אישי כאשר תשתמש בזה<br />'
.'<br />[FIRSTNAME] = זה יוחלף בשמו הפרטי של המנוי. השם הראשון מוגדר על ידי המנוי כאשר הוא נרשם<br />');
define('_ACA_CONFIRMFROMNAME', 'וודא משם');
define('_ACA_CONFIRMFROMNAME_TIPS', 'הזן את שם השולח שיופיע ברשימות האישור');
define('_ACA_CONFIRMFROMEMAIL', 'אשר מכתובת דואר');
define('_ACA_CONFIRMFROMEMAIL_TIPS', 'הזן את כתובת הדואר שתוצג על רשימות האישורים.');
define('_ACA_CONFIRMBOUNCE', 'כתובת Bounce');
define('_ACA_CONFIRMBOUNCE_TIPS', 'הזן את כתובת הBounce שתופיע על רשימות האישורים');
define('_ACA_HTML_CONFIRM', 'וודא HTML');
define('_ACA_HTML_CONFIRM_TIPS', 'לחץ כן אם רשימות האישורים צריכות להיות בHTML, אם המשתמש מאשר HTML');
define('_ACA_TIME_ZONE_ASK', 'שאל איזור זמן');
define('_ACA_TIME_ZONE_TIPS', 'לחץ על כן אם ברצונך לשאול את המשתמש מהו איזור הזמן בו הוא נמצא. דברי דואר בתור, יישלחו על פי פרטים אלו כאשר אופציה זו פועלת');

 // Cron Set up
 define('_ACA_AUTO_CONFIG', 'Cron');
define('_ACA_TIME_OFFSET_URL', 'לחץ כאן לעריכת קיזוז בלוח הקונפיגורציה הגלובלית -> לשונית איזור');
define('_ACA_TIME_OFFSET_TIPS', 'ערוך את קיזוז הזמן של השרת על מנת שהתאריך והזמן הרשומים מדוייקים.');
define('_ACA_TIME_OFFSET', 'קיזוז זמן');
define('_ACA_CRON_DESC','<br />שימוש בפעולת הקרון תאפשר משימות אוטומטיות באתר הגומלה שלכם.<br />' .
		'בשביל לערוך את זה, הינך צרים להוסיף בלוח הבקרה contrab את הפקודה הבאה:<br />' .
		'<b>' . $GLOBALS['mosConfig_live_site'] . '/index.php?option=com_acajoom&act=cron</b> ' .
		'<br /><br />אם הינך צריך עזרה בהתקנה של זה או אם יש לך בעיות עם זה, אנא בקר בפורום <a href="http://www.acajoom.com" target="_blank">http://www.acajoom.com</a>');
// sending settings
define('_ACA_PAUSEX', 'עצור כל X שניות של כמות אימיילים מקונפגים');
define('_ACA_PAUSEX_TIPS', 'הזן את כמות השניות אקאגום תתן לשרת הSMTP לשלוח את ההודעות לפני שתמשיך עם כמות ההודעות המקונפגות הבאות');
define('_ACA_EMAIL_BET_PAUSE', 'אימיילים בין הפסקות');
define('_ACA_EMAIL_BET_PAUSE_TIPS', 'כמות האימיילים לפני הפסקה');
define('_ACA_WAIT_USER_PAUSE', 'חכה להתערבות משתמש בזמן הפסקה');
define('_ACA_WAIT_USER_PAUSE_TIPS', 'האם הסקריפט צריך לחכות להתערבות משתמש כאשר המערכת בהפסקה בין סדרות של שליחת דואר');
define('_ACA_SCRIPT_TIMEOUT', 'סקריפט timeout');
define('_ACA_SCRIPT_TIMEOUT_TIPS', 'מספר הדקות שהסקריפט ירוץ. (הכנס 0 לבלתי מוגבל).');
// Stats settings
define('_ACA_ENABLE_READ_STATS', 'אפשר קריאת סטטיסטיקות');
define('_ACA_ENABLE_READ_STATS_TIPS', 'לחץ כן אם ברצונך לתעד את מספר הצפיות. טכניקה זו יכולה להיות מיושמת רק עם דואר HTML');
define('_ACA_LOG_VIEWSPERSUB', 'מספר צפיות למנוי');
define('_ACA_LOG_VIEWSPERSUB_TIPS', 'לחץ כן אם ברצונך לתעד את מספר הצפיות לכל מנוי. טכניקה זו יכולה להיות מיושמת רק עם דואר HTML');
// Logs settings
define('_ACA_DETAILED', 'תיעוד בהרחבה');
define('_ACA_SIMPLE', 'תיעוד פשוט');
define('_ACA_DIAPLAY_LOG', 'הצג תיעודים');
define('_ACA_DISPLAY_LOG_TIPS', 'לחץ כן אם ברצונך לצפות בתיעודים בזמן שליחת דברי דואר.');
define('_ACA_SEND_PERF_DATA', 'שלח החוצה ביצועים');
define('_ACA_SEND_PERF_DATA_TIPS', 'לחץ כן אם ברצונך לאפשר לאקאגום לשלוח דוחות אנונימיים אודות הקונפוגורציה שלך, מספר הרשומים בכל רשימה והזמן שלקח לשלוח את דברי הדואר. זה ייתן לנו מידע אודות הפעילות של אקאגום ויעזור לנו לשפר את האופן בה התוכנה פועלת');
define('_ACA_SEND_AUTO_LOG', 'שלח תיעוד בשביל מענה אוטומטי');
define('_ACA_SEND_AUTO_LOG_TIPS', 'לחץ כן אם ברצונך לשלוח אימייל עם תיעוד בכל פעם שהתור מעובד. אזהרה!!! פעולה זו יכולה לגרום לכמות גדולה של אימיילים להווצר');
define('_ACA_SEND_LOG', 'שלח דוח תיעוד');
define('_ACA_SEND_LOG_TIPS', 'אם דוח תיעוד של שליחת דברי דואר צריך להשלח לכתובת האימייל של המשתמש ששלח את דבר הדואר');
define('_ACA_SEND_LOGDETAIL', 'שלח פירוט תיעוד');
define('_ACA_SEND_LOGDETAIL_TIPS', 'מפורט כולל את הצלחתו או כשלונו של מידע לכל מנוי וסקירה של המידע. פשוט רק שולח את הסקירה.');
define('_ACA_SEND_LOGCLOSED', 'שלח דוח אם החיבור נסגר');
define('_ACA_SEND_LOGCLOSED_TIPS', 'אם אופציה זו על המשתמש ששלח את דבר הדואר עדיין יקבל דוח באימייל.');
define('_ACA_SAVE_LOG', 'שמור דוח');
define('_ACA_SAVE_LOG_TIPS', 'אם תיעוד של דבר הדואר יהיה מצורף לקובץ התיעוד');
define('_ACA_SAVE_LOGDETAIL', 'שמור תיעוד בפרטים');
define('_ACA_SAVE_LOGDETAIL_TIPS', 'מפורט כולל את הצלחתו או כשלונו של מידע עבור כל מנוי וסקירה של המידע. פשוט רק שומר את הסקירה.');
define('_ACA_SAVE_LOGFILE', 'שמור תיעוד לקובץ');
define('_ACA_SAVE_LOGFILE_TIPS', 'קובץ אליו מידע מהתיעוד יהיה מצורף. קובץ זה יכול להגיע לגודל די גדול.');
define('_ACA_CLEAR_LOG', 'נקה תיעוד');
define('_ACA_CLEAR_LOG_TIPS', 'מנקה לגמרי את קובץ התיעוד');

### control panel
define('_ACA_CP_LAST_QUEUE', 'התור האחרון שבוצע בהצלחה');
define('_ACA_CP_TOTAL', 'סך הכל');
define('_ACA_MAILING_COPY', 'דברי דואר הועתקו בהצלחה!');

// Miscellaneous settings
define('_ACA_SHOW_GUIDE', 'הראה מדריך');
define('_ACA_SHOW_GUIDE_TIPS', 'הראה את המדריך בהתחלה על מנת לעזור למשתמשים חדשים ליצור רשימת תפוצה, מענה אוטומטי ואיך לערוך את אקאגום בצורה נכונה.');
define('_ACA_AUTOS_ON', 'השתמש במענה אוטומטי');
define('_ACA_AUTOS_ON_TIPS', 'בחר בלא אם אינך רוצה להשתמש במענה אוטומטי. כל המענים האוטומטיים ינוטרלו.');
define('_ACA_NEWS_ON', 'השתמש ברשימות תפוצה');
define('_ACA_NEWS_ON_TIPS', 'בחר בלא אם אינך רוצה להשתמש ברשימות תפוצה. כל רשימות התפוצה ינוטרלו.');
define('_ACA_SHOW_TIPS', 'הצג טיפים');
define('_ACA_SHOW_TIPS_TIPS', 'הצג את הטיפים על מנת לעזור למשתמשים להשתמש באקאגום בצורה יותר יעילה');
define('_ACA_SHOW_FOOTER', 'הצג סיומת עמוד');
define('_ACA_SHOW_FOOTER_TIPS', 'אם זכיויות יוצרים יוצג בסיומת העמוד.');
define('_ACA_SHOW_LISTS', 'מראה רשימות באתר');
define('_ACA_SHOW_LISTS_TIPS', 'כאשר משתמש אינו רשום, הראה רשימה של הרשימות שהם יכולים להרשם אליהם עם כפתור לארכיון, לרשימות תפוצה, או פשוט טופס כניסה בכדי שיוכלו להרשם.');
define('_ACA_CONFIG_UPDATED', 'פרטי הקונפיגורציה עודכנו בהצלחה!');
define('_ACA_UPDATE_URL', 'עדכן כתובת URL');
define('_ACA_UPDATE_URL_WARNING', 'אזהרה!!! אל תשנה את כתובת URL זו אלא אם כן התבקשת לעשות כך על ידי הצוות הטכני של אקאגום<br />');
define('_ACA_UPDATE_URL_TIPS', 'לדוגמא: http://www.acajoom.com/update/ (כולל את הלוכסן הסוגר!)');

// module
define('_ACA_EMAIL_INVALID', 'כתובת הדואר האלקטרוני שהוכנסה אינה חוקית');
define('_ACA_REGISTER_REQUIRED', 'יש להרשם לאתר לפני שתוכל להרשם לרשימה זו.');

// Access level box
define('_ACA_OWNER', 'יוצר הרשימה:');
define('_ACA_ACCESS_LEVEL', 'קבע רמת גישה לרישמה זו.');
define('_ACA_ACCESS_LEVEL_OPTION', 'אפשרויות רמת גישה');
define('_ACA_USER_LEVEL_EDIT', 'בחר איזה רמת משתמש מורשה לערוך דבר דואר. (מהאתר, או פאנל הניהול) ');

//  drop down options
define('_ACA_AUTO_DAY_CH1', 'יומי');
define('_ACA_AUTO_DAY_CH2', 'יומי ללא סופי שבוע');
define('_ACA_AUTO_DAY_CH3', 'כל יומיים');
define('_ACA_AUTO_DAY_CH4', 'כל יומיים ללא סופי שבוע');
define('_ACA_AUTO_DAY_CH5', 'שבועי');
define('_ACA_AUTO_DAY_CH6', 'דו שבועי');
define('_ACA_AUTO_DAY_CH7', 'חודשי');
define('_ACA_AUTO_DAY_CH9', 'שנתי');
define('_ACA_AUTO_OPTION_NONE', 'לא');
define('_ACA_AUTO_OPTION_NEW', 'משתמשים חדשים');
define('_ACA_AUTO_OPTION_ALL', 'כל המשתמשים');

//

define('_ACA_UNSUB_MESSAGE', 'אימייל ביטול הרשמה');
define('_ACA_UNSUB_SETTINGS', 'הגדרות ביטול הרשמה');
define('_ACA_AUTO_ADD_NEW_USERS', 'הוסף משתמשים כמנויים בצורה אוטומטית?');

// Update and upgrade messages
define('_ACA_NO_UPDATES', 'כרגע לא קיימים עדכונים');
define('_ACA_VERSION', 'אקאגות גרסא');
define('_ACA_NEED_UPDATED', 'קבצים שצריכים עדכון:');
define('_ACA_NEED_ADDED', 'קבצים שצריכים להוסיף');
define('_ACA_NEED_REMOVED', 'קבצים שצריכים הסרה');
define('_ACA_FILENAME', 'שם קובץ:');
define('_ACA_CURRENT_VERSION', 'גרסא עכשיוית:');
define('_ACA_NEWEST_VERSION', 'הגרסא הכי חדישה כרגע:');
define('_ACA_UPDATING', 'מעדכן');
define('_ACA_UPDATE_UPDATED_SUCCESSFULLY', 'הקבצים עודכנו בהצלחה');
define('_ACA_UPDATE_FAILED', 'העדכון כשל!');
define('_ACA_ADDING', 'מוסיף');
define('_ACA_ADDED_SUCCESSFULLY', 'הוסף בהצלחה');
define('_ACA_ADDING_FAILED', 'ההוספה נכשלה!');
define('_ACA_REMOVING', 'מסיר');
define('_ACA_REMOVED_SUCCESSFULLY', 'הוסר בהצלחה.');
define('_ACA_REMOVING_FAILED', 'ההסרה נכשלה');
define('_ACA_INSTALL_DIFFERENT_VERSION', 'התקן גרסא אחרת');
define('_ACA_CONTENT_ADD', 'הוסף תוכן');
define('_ACA_UPGRADE_FROM', 'ייבא תוכן (רשומות תפוצה מידע על מנויים) מ ');
define('_ACA_UPGRADE_MESS', 'אין סכנה למידע הקיים. <br /> פעולה זו פשוט תייבא את המידע אל מסד הנתונים של אקאגום.');
define('_ACA_CONTINUE_SENDING', 'המשך שליחה');
// Acajoom message

define('_ACA_UPGRADE1', 'הינך יכול לייבא את המשתמשים ורשימות התפוצה שלך מ ');
define('_ACA_UPGRADE2', ' לאקאגום בלוח העידכונים.');
define('_ACA_UPDATE_MESSAGE', 'גרסא חדשה לאקאגום זמינה! ');
define('_ACA_UPDATE_MESSAGE_LINK', 'לחץ כאן לעידכון!');
define('_ACA_THANKYOU', 'תודה על בחירתך באקאגום! אתה שותך לתקשורת!');
define('_ACA_NO_SERVER', 'עידכון שרת לא זמין, אנא חזור לבדוק מאוחר יותר');
define('_ACA_MOD_PUB', 'מודול אקאגום לא פורסם');
define('_ACA_MOD_PUB_LINK', 'לחץ כאן כדי לפרסם זאת!');
define('_ACA_IMPORT_SUCCESS', 'יובא בהצלחה');
define('_ACA_IMPORT_EXIST', 'מנוי נמצא בבסיס הנתונים');

// Acajoom\'s Guide
define('_ACA_GUIDE', '\'s Wizard');
define('_ACA_GUIDE_FIRST_ACA_STEP', '<p>לאקאגופ יש מאפיינים רבים נהדרים ואשף זה ידריך אותך בתהליך של ארבעה צעדים פשוטים כדי שתתחיל להחזיק רשימת תפוצה ומענה אוטומטי משלך!<p />');
define('_ACA_GUIDE_FIRST_ACA_STEP_DESC', 'קודם כל תצטרך להוסיף רשימה. יש שני סוגי רשימות - רשימת תפוצה או מענה אוטומטי' .
		'  ברשימה בחר את כל הפרמטרים השונים שיאפשרו שליחה לרשימת התפוצה או מענה אוטומטי: שם שולח, מערך, מנויים, הודעת ברוך הבא וכולי
<br /><br />תוכל להגדיר את הרשימה הראשונה שלך כאן: <a href="index2.php?option=com_acajoom&act=list" >צור רשימה</a> ולחץ על כפתור חדש.');
define('_ACA_GUIDE_FIRST_ACA_STEP_UPGRADE', 'אקאגופ מספק לך דרך קלה לייבא כל נתון ממערכת רשימת תפוצה קודמת<br />' .
		' לך ללוח הייבוא ובחר במערכת רשימת תפוצה קודמת כדי לייבא את כל רשימות התפוצה והמנויים  <br /><br />' .
		'<span style="color:#FF5E00;" >חשוב: הייבוא נטול סיכונים ולא משפיע בשום דרך על הנתונית של מערכת רשימה התפוצה הקודמת שלך</span><br />' .
		'אחרי הייבוא, תוכל לנהל את המנוייל והדיוור ישירות מאקאגום<br /><br />');
define('_ACA_GUIDE_SECOND_ACA_STEP', 'נהדר! הרשימה הראשונה שלך נוצרה!  אתה עכשיו יכול לכתוב %s.  בשביל ליצור אחד, גש ל: ');
define('_ACA_GUIDE_SECOND_ACA_STEP_AUTO', 'ניהול מענה אוטומטי');
define('_ACA_GUIDE_SECOND_ACA_STEP_NEWS', 'ניהול רשימות התפוצה');
define('_ACA_GUIDE_SECOND_ACA_STEP_FINAL', ' ותבחר את ה %s. <br /> אז תבחר את ה %s שלך מתוך הרשימה.  צור את הדיוור הראשון שלך על ידי לחיצה על חדש.');

define('_ACA_GUIDE_THRID_ACA_STEP_NEWS', 'לפני שתשלח דואר לרשימת התפוצה שלך בפעם הראשונה, ייתכן ותרצה לבדוק את הגדרות הדואר.  ' .
		'גש אל <a href="index2.php?option=com_acajoom&act=configuration" >דף קונפיגורציה</a> על מנת לוודא את הגדרות הדואר <br />');
define('_ACA_GUIDE_THRID2_ACA_STEP_NEWS', '<br />כאשר אתה מוכן לחזור את תפריט רשימות התפוצה, בחר את דבר הדואר שלך ולחץ על שלח');

define('_ACA_GUIDE_THRID_ACA_STEP_AUTOS', 'בשביל שהמענה האוטומטי ייפעל כשורה, הינך חיייב ליצור משימת cron על השרת שלך. ' .
		' Please refer to the Cron tab in the configuration panel.' .
		' <a href="index2.php?option=com_acajoom&act=configuration" >לחץ כאן</a> בשביל ללמוד איך ליצור משימת cron <br />');

define('_ACA_GUIDE_MODULE', ' <br />וודא כי אכן הפעלת את מודול אקאגום, בכדי שאנשים יוכלו להרשם לרשימה.');

define('_ACA_GUIDE_FOUR_ACA_STEP_NEWS', ' הינך יכול עכשיו ליצור מענה אוטומטי');
define('_ACA_GUIDE_FOUR_ACA_STEP_AUTOS', ' הינך יכול עכשיו ליצור רשימת תפוצה');

define('_ACA_GUIDE_FOUR_ACA_STEP', '<p><br />זהו! אתה מוכן ליצור קשר עם מבקרים ומשתמשים. אשף זה יסיים ברגע שתכניס רשימת תפוצה שניה, או שאתה יכול לכבות את האשף ב <a href="index2.php?option=com_acajoom&act=configuration" >לוח הקונפיגורציה</a>.' .
		'<br /><br /> אם יש לך שאלות לגבי אקאגום, נא פנה ל ' .
		'<a target="_blank" href="http://www.acajoom.com/index.php?option=com_joomlaboard&Itemid=26&task=listcat&catid=22" >פורום</a>. ' .
		' בנוסף, אתה תמצא כמות גדולה של מידע על איך ליצור קשר עם המנויים שלך בצורה נכונה ב <a href="http://www.acajoom.com/" target="_blank" >www.Acajoom.com</a>.' .
		'<p /><br /><b>תודה שהשתמשת באקאגום, הדרך הטובה ביותר ליצור קשר עם הלקוחות שלך!</b> ');
define('_ACA_GUIDE_TURNOFF', 'האשף עכשיו מכבה את עצמו');
define('_ACA_STEP', 'שלב ');


// Acajoom Install
define('_ACA_INSTALL_CONFIG', 'קונפיגורציית אקאגום');
define('_ACA_INSTALL_SUCCESS', 'ההתקנה הסתיימה בהצלחה');
define('_ACA_INSTALL_ERROR', 'תקלת התקנה');
define('_ACA_INSTALL_BOT', 'הרחב אקאגום (בוט)  ');
define('_ACA_INSTALL_MODULE', 'מודול אקאגום');
//Others
define('_ACA_JAVASCRIPT','אזהרה! גאווה סקריפט חייב להיות מאושר לפעולה ראוייה!');
define('_ACA_EXPORT_TEXT','המנויים שמיוצאים מבוססים על הרשימה שבחרת. <br /> ייצא מנויים בשביל הרשימה.');
define('_ACA_IMPORT_TIPS','ייבא מנויים. המידע בקובץ צריך להיות בפורמט הבא:  <br />' .
		'שם, כתובת דואר אלקטרונית, מקבלHTML (0/1),<span style="color: rgb(255, 0, 0);"> אושר(1/0)</span>');
define('_ACA_SUBCRIBER_EXIT', 'כבר מנוי');
define('_ACA_GET_STARTED', 'הקלק כאן כדי להתחיל!');

//News since 1.0.1
define('_ACA_WARNING_1011','אזהרה 1011: עדכון לא יעבוד בגלל הגבלה של השרת שלך');
define('_ACA_SEND_MAIL_FROM_TIPS', 'בחר את כתובת הדואר האלקטרונית שתופיע כשולח');
define('_ACA_SEND_MAIL_NAME_TIPS', 'בחר את השם שיופיע בשורת השולח');
define('_ACA_MAILSENDMETHOD_TIPS', 'בחר באיזה דואר ברצונך להשתמש: פונקציית דואר PHP <span> סנדמייל</span> או שרת SMTP');
define('_ACA_SENDMAILPATH_TIPS', 'זוהי הספרייה של שרת הדואר האלקטרוני');
define('_ACA_LIST_T_TEMPLATE', 'תבנית');
define('_ACA_NO_MAILING_ENTERED', 'לא סופק דואר');
define('_ACA_NO_LIST_ENTERED', 'לא סופקה רשימה');
define('_ACA_SENT_MAILING' , 'דואר שנשלח');
define('_ACA_SELECT_FILE', 'אנא בחר קובץ ל ');
define('_ACA_LIST_IMPORT', 'סמן את הרשימות שתרצה שהרשומים ישתייכו אליהם');
define('_ACA_PB_QUEUE', 'רשומים נכנסו אבל יש בעיה לקשר אותם לרשימותץ אנא בדוק ידנית');
define('_ACA_UPDATE_MESS' , '');
define('_ACA_UPDATE_MESS1' , 'עדכון מומלץ ביותר!');
define('_ACA_UPDATE_MESS2' , 'החל טלאי ותיקונים קטנים');
define('_ACA_UPDATE_MESS3' , 'שחרור גרסא חדשה');
define('_ACA_UPDATE_MESS5' , 'גומלה 1.5 דורש עידכון');
define('_ACA_UPDATE_IS_AVAIL' , 'זמין!');
define('_ACA_NO_MAILING_SENT', 'אין דואר נשלח!');
define('_ACA_SHOW_LOGIN', 'הראה טופס הרשמה');
define('_ACA_SHOW_LOGIN_TIPS', 'בחר כן כדי להראות טופס כניסה בלוח בקרה באתר אקאגום כך שהמשתמש יוכל להרשם לאתר');
define('_ACA_LISTS_EDITOR', 'עורך תיאור רשימה');
define('_ACA_LISTS_EDITOR_TIPS', 'בחר כן כדי להשתמש בעורך HTML בשביל לערוך את שדה תיאור רשימה');
define('_ACA_SUBCRIBERS_VIEW', 'הראה מינויים');

//News since 1.0.2
define('_ACA_FRONTEND_SETTINGS' , 'הגדרות אתר' );
define('_ACA_SHOW_LOGOUT', 'הראה כפתור יציאה מהמערכת');
define('_ACA_SHOW_LOGOUT_TIPS', 'בחר כן כדי להראות את כפתור היציאה מהמערכת בלוח הבקרה באתר אקאגום');

//News since 1.0.3 CB integration
define('_ACA_CONFIG_INTEGRATION', 'שילוב');
define('_ACA_CB_INTEGRATION', 'שילוב קומיוניטי בילדר');
define('_ACA_INSTALL_PLUGIN', 'הרחבות קומיוניטי בילדר  (שילוב אקאגום) ');
define('_ACA_CB_PLUGIN_NOT_INSTALLED', 'הרחבות אקאגום לקומיוניטי בילדר טרם הותקנו');
define('_ACA_CB_PLUGIN', 'הראה רשימה בהרשמות');
define('_ACA_CB_PLUGIN_TIPS', 'בחר כן על מנת להראות את רשימות התפוצה בטפסי הרשמות של קומיוניטי בילדר');
define('_ACA_CB_LISTS', 'זיהוי רשימה מספר');
define('_ACA_CB_LISTS_TIPS', 'זהו שדה חובה. הכנס את מספר זיהוי הרשימה שהנך רוצה לתת אפשרות לרשומים לעשות מנוי אל מופרד בפסיק , (0 מראה את כל הרשימות)');
define('_ACA_CB_INTRO', 'טקסט הקדמה');
define('_ACA_CB_INTRO_TIPS', 'טקסט שמופיע יופיע לפני הרשומות. השאר ריק בשביל לא להראות דבר. תוכל להשתמש בתגיות HTML בשביל להתאים אישית את המראה וההרגשה');
define('_ACA_CB_SHOW_NAME', 'הראה שם רשימה');
define('_ACA_CB_SHOW_NAME_TIPS', 'בחר אם אתה רוצה להראות את שם הרשימה אחרי ההקדמה');
define('_ACA_CB_LIST_DEFAULT', 'סמן רשימה כברירת מחדל');
define('_ACA_CB_LIST_DEFAULT_TIPS', 'Sבחר אם אתה רוצה שתיבת הסימון תהיה מסומנת לכל רשימה כברירת מחדל.');
define('_ACA_CB_HTML_SHOW', 'הראה קבלת HTML');
define('_ACA_CB_HTML_SHOW_TIPS', 'בחר כן בשביל להרשות למשתמשים להחליט אם הם רוצים דואר אלקטרוני בHTML או לא. בחר לא בשביל להשתמתש בברירת מחדל HTML');
define('_ACA_CB_HTML_DEFAULT', 'ברירת מחדל קבלת HTML');
define('_ACA_CB_HTML_DEFAULT_TIPS', 'בחר באופציה זו כדי להראות את ברירת המחדל של קונפיגורציית שליחת דואר HTML. אם הצג קבלת HTML מכוון ללא אז אופציה זו תהיה ברירת המחדל');

// Since 1.0.4
define('_ACA_BACKUP_FAILED', 'לא הייתה אפשרות לגבות קובץ! קובץ לא הוחלף');
define('_ACA_BACKUP_YOUR_FILES', 'הגרסא הישנה של הקבצים גובו לספרייה הבאה:');
define('_ACA_SERVER_LOCAL_TIME', 'שעת שרת בזמן מקומי');
define('_ACA_SHOW_ARCHIVE', 'הראה כפתור ארכיון');
define('_ACA_SHOW_ARCHIVE_TIPS', 'בחר כן בשביל להראות כפתור ארכיון בסוף כל רשימת תפוצה');
define('_ACA_LIST_OPT_TAG', 'תגיות');
define('_ACA_LIST_OPT_IMG', 'תמונות');
define('_ACA_LIST_OPT_CTT', 'תוכן');
define('_ACA_INPUT_NAME_TIPS', 'הכנס שם מלא ( שם פרטי קודם) ');
define('_ACA_INPUT_EMAIL_TIPS', 'הכנס את כתובת הדואר האלקטרוני שלך. וודא כי זו כתובת בתוקף אם אתה רוצה להיות ברשימת התפוצה שלנו');
define('_ACA_RECEIVE_HTML_TIPS', 'בחר כן אם ברצונך לקבל מכתבים בHTML  - בחר לא בשביל לקבל מכתבים בטקסט בלבד');
define('_ACA_TIME_ZONE_ASK_TIPS', 'ציין את איזור הזמן שלך');

// Since 1.0.5
define('_ACA_FILES' , 'קבצים');
define('_ACA_FILES_UPLOAD' , 'העלאה');
define('_ACA_MENU_UPLOAD_IMG' , 'העלה תמונה');
define('_ACA_TOO_LARGE' , 'הקובץ גדול מידי. גודל המקסימום הוא');
define('_ACA_MISSING_DIR' , 'תיקיית היעד איננה קיימת');
define('_ACA_IS_NOT_DIR' , 'תיקיית היעד איננה קיימת או שהיא קובץ רגיל');
define('_ACA_NO_WRITE_PERMS' , 'לתיקיית היעד אין הרשאות כתיבה');
define('_ACA_NO_USER_FILE' , 'לא נבחר קובץ להעלאה');
define('_ACA_E_FAIL_MOVE' , 'לא ניתן להזיז את הקובץ');
define('_ACA_FILE_EXISTS' , 'יעד הקובץ כבר קיים');
define('_ACA_CANNOT_OVERWRITE' , 'יעד הקובץ כבר קיים ולא ניתן לשכתבו');
define('_ACA_NOT_ALLOWED_EXTENSION' , 'סיומת הקובץ לא חוקית');
define('_ACA_PARTIAL' , 'הקובץ הועלה באופן חלקי בלבד');
define('_ACA_UPLOAD_ERROR' , 'תקלה בהעלאה:');
define('DEV_NO_DEF_FILE' , 'הקובץ הועלה חלקית בלבד');

// already exist but modified  added a <br/ on first line and added [SUBSCRIPTIONS] line>
define('_ACA_CONTENTREP', '[SUBSCRIPTIONS] = זה יוחלף עם קישורי ההרשמה' .
		' זה <strong> נדרש </strong> בשביל שאקאגום יעבוד כראוי<br />' .
		'אם תמקם כל תוכן אחר בתיבה זו הוא יוצג בכל רשימות התפוצה בהתאם לרשומה זו' .
		' <br /> הוסף הודעת הרשמה בסוף. אקאגום יוסיף קישור בצורה אוטומטית לרשומים לשנות את המידע שלהם וקישור להסרה מרשימת התפוצה');

// since 1.0.6
define('_ACA_NOTIFICATION', 'הודעה');  // shortcut for Email notification
define('_ACA_NOTIFICATIONS', 'הודעות');
define('_ACA_USE_SEF', 'SEF ברשימות תפוצה');
define('_ACA_USE_SEF_TIPS', 'מומלץ שתבחר לא. בכל מקרה אם תרצה שהURL יכלל ברשימת התפוצה שלך לשימוש SEF אז בחר כן' .
		' <br /> <b> הקישורים יעבדו אותו הדבר בשתי האופציות. אין הבטחה כי הקישורים ברשימת התפוצה יעבדו תמיד, גם אם שינית את הSEF שלך.</b> ');
define('_ACA_ERR_NB' , 'Error #: ERR');
define('_ACA_ERR_SETTINGS', 'הגדרות התמודדות עם תקלות');
define('_ACA_ERR_SEND' ,'שלח דוח שגיאות');
define('_ACA_ERR_SEND_TIPS' ,'אם תרצה את אקאגום כמוצר טוב יותר אנא בחר כן. יישלחו דוחות שגיאה כך שלא תצטרך לדווח על באגים יותר  <br /> <b>מידע פרטי לא נשלח!</b>. אנחנו אפילו לא נדע מאיזה אתר מגיע דוח השגיאה. אנו נשלח אך ורק מידע על אקאגום, הגדרות הPHP וחקירות SQL ');
define('_ACA_ERR_SHOW_TIPS' ,'בחר כן אם ברצונך להראות מספר תקלה על המסך שלך. שמיש בעיקר להצעה לדיבאגינג ');
define('_ACA_ERR_SHOW' ,'הראה תקלות');
define('_ACA_LIST_SHOW_UNSUBCRIBE', 'הראה לינקים לא רשומים');
define('_ACA_LIST_SHOW_UNSUBCRIBE_TIPS', 'בחר כן בשביל להראות לינק לביטול הרשמה בתחתית רשימת התפוצה למשתמשים שרוצים לשנות הסכמתם <br /> לא למנוע את תוך המיילים והלינקים');
define('_ACA_UPDATE_INSTALL', '<span style="color: rgb(255, 0, 0);">הודעה חשובה!</span> <br />אם אתה מעדכן גרסא קודמת של אקאגום תצטרך לעדכן את מבנה בסיס הנתונים על ידי לחיצה על הכפתור הבא (הנתונים שלך ישארו אחידים)');
define('_ACA_UPDATE_INSTALL_BTN' , 'שדרג טבלאות וקונפיגורציה');
define('_ACA_MAILING_MAX_TIME', 'מקסימום זמן תור' );
define('_ACA_MAILING_MAX_TIME_TIPS', 'ציין את זמן המקסימום לכל סט של מכתבים נשלחים בתור. מומלץ בין 30 שניות לשתי דקות');

// virtuemart integration beta
define('_ACA_VM_INTEGRATION', 'VirtueMart שילוב');
define('_ACA_VM_COUPON_NOTIF', 'מזהה הודעות קופונים');
define('_ACA_VM_COUPON_NOTIF_TIPS', 'ציין את המספר המזהה של רשימת התפוצה בה תרצה להשתמש לשליחת קופונים לקונים שלך');
define('_ACA_VM_NEW_PRODUCT', 'New products notification ID');
define('_ACA_VM_NEW_PRODUCT_TIPS', 'ציין את המספר המזהה של רשימת התפוצה בה תרצה להשתמש לשליחת הודעות על מוצרים חדשים');

// since 1.0.8
// create forms for subscriptions
define('_ACA_FORM_BUTTON', 'צור טופס');
define('_ACA_FORM_COPY', 'קוד HTML');
define('_ACA_FORM_COPY_TIPS', 'העתק את קוד הHTML שנוצר לתוך דף הHTML שלך');
define('_ACA_FORM_LIST_TIPS', 'בחר את הרשימה שתרצה לכלו בטופס');
// update messages
define('_ACA_UPDATE_MESS4' , 'זה לא יכול להשתדרג באופן אוטומטי');
define('_ACA_WARNG_REMOTE_FILE' , 'אין דרך לקבל קובץ מרוחק');
define('_ACA_ERROR_FETCH' , 'תקלה בקליטת קובץ.');

define('_ACA_CHECK' , 'בדוק');
define('_ACA_MORE_INFO' , 'מידע נוסף');
define('_ACA_UPDATE_NEW' , 'שדרג לגרסא חדשה יותר');
define('_ACA_UPGRADE' , 'שדרג למוצר חדש יותר');
define('_ACA_DOWNDATE' , 'חזור לגרסא הקודמת');
define('_ACA_DOWNGRADE' , 'חזור למוצר הבסיסי');
define('_ACA_REQUIRE_JOOM' , 'דרוש גומלה');
define('_ACA_TRY_IT' , 'נסה זאת!');
define('_ACA_NEWER', 'חדש יותר');
define('_ACA_OLDER', 'ישן יותר');
define('_ACA_CURRENT', 'נוכחי');

// since 1.0.9
define('_ACA_CHECK_COMP', 'נסה אחד מרכיבינו הנוספים');
define('_ACA_MENU_VIDEO' , 'מדריכי ווידאו');
define('_ACA_SCHEDULE_TITLE', 'תיזמון אוטומטי של הגדרות פונקציות');
define('_ACA_ISSUE_NB_TIPS' , 'מספר הגיליון יווצר אוטומטית על ידי המערכת' );
define('_ACA_SEL_ALL' , 'כל רשימות התפוצה');
define('_ACA_SEL_ALL_SUB' , 'כל הרשימות');
define('_ACA_INTRO_ONLY_TIPS' , 'אם תסמן תיבה זו, רק ההקדמה של המאמר תוכנה לרשימת התפוצה עם קישור להמשך הקריאה למאמר המלא באתר שלך' );
define('_ACA_TAGS_TITLE' , 'תגית תוכן');
define('_ACA_TAGS_TITLE_TIPS' , 'העתק והדבק תגית זו לתוך רשימת התפוצה היכן שתרצה למקם את התוכן');
define('_ACA_PREVIEW_EMAIL_TEST', 'ציין כתובת דואר אלקטרוני אליה יישלח מבחן');
define('_ACA_PREVIEW_TITLE' , 'תצוגה מקדימה');
define('_ACA_AUTO_UPDATE' , 'הודעות על עידכונים חדשים');
define('_ACA_AUTO_UPDATE_TIPS' , 'בחר כן אם ברצונך לקבל הודעות על עידכונים לרכיבים שלך <br />חשוב!! אופציית הראה טיפים צריכה לפעול בשביל שפונקציה זו תעבוד');

// since 1.1.0
define('_ACA_LICENSE' , 'מידע על הרישיון');

// since 1.1.1
define('_ACA_NEW' , 'חדש');
define('_ACA_SCHEDULE_SETUP', 'בשביל שמענה אוטומטי יישלח, תצטרך להגדיר מתזמן בקונפיגורציה');
define('_ACA_SCHEDULER', 'מתזמן');
define('_ACA_ACAJOOM_CRON_DESC' , 'אם אין לך גישה למנהל משימות קרון באתר שלך תוכל להרשם לחשבון אקאגום קרון חינם ב:' );
define('_ACA_CRON_DOCUMENTATION' , 'תוכל למצוא מידע נוסף על הגדרות מתזמן האקאגום בכתובת היו.אר.אל הבאה:');
define('_ACA_CRON_DOC_URL' , '<a href="http://www.acajoom.com/index.php?option=com_content&task=blogcategory&id=29"
 target="_blank">http://www.acajoom.com/index.php?option=com_content&task=blogcategory&id=29</a>' );
define( '_ACA_QUEUE_PROCESSED' , 'תור עובד בהצלחה' );
define( '_ACA_ERROR_MOVING_UPLOAD' , 'תקלה בהעברת קובץ מיובא' );

//since 1.1.4
define( '_ACA_SCHEDULE_FREQUENCY' , 'תדירות המתזמן' );
define( '_ACA_CRON_MAX_FREQ' , 'תדירות מקסימלית למתזמן' );
define( '_ACA_CRON_MAX_FREQ_TIPS' , 'ציין את התדירות המקסימלית שבה המתזמן ירוץ (בדקות). זה יגביל את המתזמן גם כשמשימת הקרון מכוונת לתדירות גבוהה יותר' );
define( '_ACA_CRON_MAX_EMAIL' , 'מקסימום מכתבי דואר אלקטרוני למשמיה' );
define( '_ACA_CRON_MAX_EMAIL_TIPS' , 'ציין את מספר המכתבים המקסימלי שיישלח לכל משימה (0 ללא הגבלה)' );
define( '_ACA_CRON_MINUTES' , ' דקות' );
define( '_ACA_SHOW_SIGNATURE' , 'הראה סיומת עמוד של הדואר' );
define( '_ACA_SHOW_SIGNATURE_TIPS' , 'תרצה או לא לקדם את אקאגום בסוף מכתבי הדואר האלקטרוניים שלך' );
define( '_ACA_QUEUE_AUTO_PROCESSED' , 'מענה אוטומטי עובד בהצלחה' );
define( '_ACA_QUEUE_NEWS_PROCESSED' , 'לוח הזמנים של רשימות התפוצה עובד בהצלחה' );
define( '_ACA_MENU_SYNC_USERS' , 'סנכרן משתמשים' );
define( '_ACA_SYNC_USERS_SUCCESS' , 'סנכרון המשתמשים הצליח!' );

// compatibility with Joomla 15
if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', 'יציאה מהמערכת' );
if (!defined('_CMN_YES')) define( '_CMN_YES', 'כן' );
if (!defined('_CMN_NO')) define( '_CMN_NO', 'לא' );
if (!defined('_HI')) define( '_HI', 'שלום' );
if (!defined('_CMN_TOP')) define( '_CMN_TOP', 'למעלה' );
if (!defined('_CMN_BOTTOM')) define( '_CMN_BOTTOM', 'כפתור' );
//if (!defined('_BUTTON_LOGOUT')) define( '_BUTTON_LOGOUT', 'Logout' );

// For include title only or full article in content item tab in newsletter edit - p0stman911
define('_ACA_TITLE_ONLY_TIPS' , 'אם תבחר בזה, כותרת המאמר בלבד תוכנס לרשימת התפוצה בצורת לינק למאמר המלא באתר שלך');
define('_ACA_TITLE_ONLY' , 'כותרת בלבד');
define('_ACA_FULL_ARTICLE_TIPS' , 'אם תבחר בזה, המאמר השלם יופיע ברשימת התפוצה');
define('_ACA_FULL_ARTICLE' , 'מאמר שלם');
define('_ACA_CONTENT_ITEM_SELECT_T', 'בחר אייטם תוכן להוסיף להודעה.  <br />העתק והדבק <b>את תגית התוכן</b>לרשימת התפוצה.  תוכל לבחור בטקסט מלא, הקדמה בלבד או כותרת בלבד עם (1,0 או 2 בהתאמה) ');
define('_ACA_SUBSCRIBE_LIST2', 'רשימת תפוצה');

// smart-newsletter function
define('_ACA_AUTONEWS', 'רשימת תפוצה חכמה');
define('_ACA_MENU_AUTONEWS', 'רשימות תפוצה חכמות');
define('_ACA_AUTO_NEWS_OPTION', 'אפשרויות רשימת תפוצה חכמה');
define('_ACA_AUTONEWS_FREQ', 'תדירות רשימת תפוצה');
define('_ACA_AUTONEWS_FREQ_TIPS', 'ציין את התדירות בה תרצה לשלוח רשימת תפוצה חכמה');
define('_ACA_AUTONEWS_SECTION', 'איזור מאמרים');
define('_ACA_AUTONEWS_SECTION_TIPS', 'ציין את האיזור בו תרצה לבחור את טופס המאמר');
define('_ACA_AUTONEWS_CAT', 'קטגוריית מאמרים');
define('_ACA_AUTONEWS_CAT_TIPS', 'Specify the category you want to choose the articles from (All for all article in that section).');
define('_ACA_SELECT_SECTION', 'בחר איזור');
define('_ACA_SELECT_CAT', 'כל הקטגוריות');
define('_ACA_AUTO_DAY_CH8', 'Quaterly');
define('_ACA_AUTONEWS_STARTDATE', 'תאריך התחלה');
define('_ACA_AUTONEWS_STARTDATE_TIPS', 'ציין את התאריך בו תרצה להתחיל לשלוח רשימת תפוצה חכמה');
define('_ACA_AUTONEWS_TYPE', 'ביצוע תוכן');// how we see the content which is included in the newsletter
define('_ACA_AUTONEWS_TYPE_TIPS', 'מאמר שלם: יכלול את כל המאמר ברשימת התפוצה<br />' .
		'פתיחה בלבד: יכלול את רק את ההקדמה של המאמר ברשימת התפוצה<br/>' .
		'כותרת בלבד: יכלול רק את כותרת המאמר ברשימת התפוצה');
define('_ACA_TAGS_AUTONEWS', '[SMARTNEWSLETTER] = זה יוחלף על ידי רשימת התפוצה החכמה' );

//since 1.1.3
define('_ACA_MALING_EDIT_VIEW', 'צור / צפה ברשימות תפוצה');
define('_ACA_LICENSE_CONFIG' , 'רישיון' );
define('_ACA_ENTER_LICENSE' , 'הכנס רישיון');
define('_ACA_ENTER_LICENSE_TIPS' , 'הכנס את מספר הרישיון שלך ושמור אותו');
define('_ACA_LICENSE_SETTING' , 'הגדרות רישיון' );
define('_ACA_GOOD_LIC' , 'רשיונך בתוקף' );
define('_ACA_NOTSO_GOOD_LIC' , 'רשיונך לא בתוקף: ' );
define('_ACA_PLEASE_LIC' , 'אנא צור קשר עם שירות התמיכה של Acajoom לשדרוג הרישיון שלך (license@acajoom.com)' );
define('_ACA_DESC_PLUS', 'אקאגום פלוס הוא המענה האוטומטמי הרציף הראשון לגומלה מערכת ניהול תוכן' . _ACA_FEATURES );
define('_ACA_DESC_PRO', 'אקאגום פרו היא מערכת רשימת התפוצה האולטימטיבית לגומלה מערכות ניהול תוכן' . _ACA_FEATURES );

//since 1.1.4
define('_ACA_ENTER_TOKEN' , 'הכנס מפתח');

define('_ACA_ENTER_TOKEN_TIPS' , 'אנא הכנס את מספר המפתח שלך שקיבלת בדואר האלקטרוני כשרכשת Acajoom ');

define('_ACA_ACAJOOM_SITE', 'אתר Acajoom:');
define('_ACA_MY_SITE', 'האתר שלי:');

define( '_ACA_LICENSE_FORM' , ' ' .
 		'לחץ כאן בכדי לגשת לטופס הרשיון</a>' );
define('_ACA_PLEASE_CLEAR_LICENSE' , 'אנא מחק את שמופיע בשדה הרישיון עד שיהיה ריק ונסה למלאו שוב<br />  אם הבעיה ממשיכה' );

define( '_ACA_LICENSE_SUPPORT' , 'אם יש לך עדיין שאלות' . _ACA_PLEASE_LIC );

define( '_ACA_LICENSE_TWO' , 'תוכל לקבל מדריך הרשיון שלך על ידי הכנסת מספר המפתח שלך וURL האתר שלך (יסומן בירוק בראש העמוד) בטופס הרישיון'
			. _ACA_LICENSE_FORM . '<br /><br/>' . _ACA_LICENSE_SUPPORT );

define('_ACA_ENTER_TOKEN_PATIENCE', 'אחרי שמירת מפתח הרשיון שלח, רשיון יווצר באופן אוטומטי ' .
		' בדרך כלל המפתח יאושר בשתי דקות. בכל מקרה, במקרים מסויימים התהליך יכול לקחת עד 15 דקות<br />' .
		'<br />חזור לבדוק את לוח הבקרה עוד מספר דקות  <br /><br />' .
		'אם לא קיבלת אישור לרישיון בתוך 15  דקות '. _ACA_LICENSE_TWO);


define( '_ACA_ENTER_NOT_YET' , 'מפתח הרישום שלך טרם נכנס לתוקף');
define( '_ACA_UPDATE_CLICK_HERE' , 'אנא בקר <a href="http://www.acajoom.com" target="_blank">www.acajoom.com</a>להורדת הגרסא החדשה ביותר');
define( '_ACA_NOTIF_UPDATE' , 'כדי לקבל עידכונים חדשים הכנס את כתובת הדואר האלקטרוני שלך ולחץ על הרשם');

define('_ACA_THINK_PLUS', 'אם אתה רוצה יותר ממערכת רשימת התפוצה שלך תחשוב PLUS!');
define('_ACA_THINK_PLUS_1', 'מענה אוטומטי רציף');
define('_ACA_THINK_PLUS_2', 'לוח זמנים קבוע מראש לשליחת רשימת תפוצה');
define('_ACA_THINK_PLUS_3', 'לא עוד הגבלת שרת');
define('_ACA_THINK_PLUS_4', 'וכיוצא בזה');

//since 1.2.2
define( '_ACA_LIST_ACCESS', 'גישה לרשימה' );
define( '_ACA_INFO_LIST_ACCESS', 'ציין איזו קבוצת משתמשים יכולה לצפות ולהרשם לקבוצה זו' );
define( 'ACA_NO_LIST_PERM', 'אין לך הרשאות להרשם לרשימה זו' );

//Archive Configuration
 define('_ACA_MENU_TAB_ARCHIVE', 'ארכיון');
 define('_ACA_MENU_ARCHIVE_ALL', 'הכנס הכל לארכיון');

//Archive Lists
 define('_FREQ_OPT_0', 'אף פעם');
 define('_FREQ_OPT_1', 'כל שבוע');
 define('_FREQ_OPT_2', 'כל שבועיים');
 define('_FREQ_OPT_3', 'כל חודש');
 define('_FREQ_OPT_4', 'כל רבעון');
 define('_FREQ_OPT_5', 'כל שנה');
 define('_FREQ_OPT_6', 'אחר');

define('_DATE_OPT_1', 'צור תאריך');
define('_DATE_OPT_2', 'תאריך שונה');

define('_ACA_ARCHIVE_TITLE', 'הגדרות לארכיון אוטומטי');
define('_ACA_FREQ_TITLE', 'תדירות ארכיון');
define('_ACA_FREQ_TOOL', 'הגדר באיזו תכיפות תרצה שמנהל הארכיון יכניס לארכיון את תוכן האתר');
define('_ACA_NB_DAYS', 'מספר ימים');
define('_ACA_NB_DAYS_TOOL', 'זה לאופציה השניה בלבד! אנא ציין את מספר הימים בין כל ארכיון');
define('_ACA_DATE_TITLE', 'סוג תאריך');
define('_ACA_DATE_TOOL', 'הגדר אם הארכיון צריך להעשות בתאריך בו הוקם או בתאריך שהשתנה');

define('_ACA_MAINTENANCE_TAB', 'הגדרות אחזקה');
define('_ACA_MAINTENANCE_FREQ', 'תדירות האחזקה');
define( '_ACA_MAINTENANCE_FREQ_TIPS', 'ציין את התדירות בה תרצה שרוטינת האחזקה תבוצע.' );
define( '_ACA_CRON_DAYS' , 'שעה/ות' );

define( '_ACA_LIST_NOT_AVAIL', 'אין רשימה זמינה');
define( '_ACA_LIST_ADD_TAB', 'הוסף/ערוך' );

define( '_ACA_LIST_ACCESS_EDIT', 'גישה להוספת/עריכת דואר' );
define( '_ACA_INFO_LIST_ACCESS_EDIT', 'ציין איזו קבוצת משתמשים תוכל להוסיף או לערוך דואר חדש לרשימה זו' );
define( '_ACA_MAILING_NEW_FRONT', 'צור דואר חדש' );

define('_ACA_AUTO_ARCHIVE', 'ארכיון אוטומטי');
define('_ACA_MENU_ARCHIVE', 'ארכיון אוטומטי');

//Extra tags:
define('_ACA_TAGS_ISSUE_NB', '[ISSUENB] = זה יוחלף במספר הגיליון של רשימת התפוצה');
define('_ACA_TAGS_ISSUE_NB', '[ISSUENB] = זה יוחלף במספר הגיליון של רשימת התפוצה');
define('_ACA_TAGS_DATE', '[DATE] = זה יוחלף בתאריך המשלוח');
define('_ACA_TAGS_CB', '[CBTAG:{field_name}] = זה יוחלף עם ערך שיילקח משדה קמיוניטי בילדר:  eg. [CBTAG:firstname] ');
define( '_ACA_MAINTENANCE', 'תחזוקה' );

define('_ACA_THINK_PRO', 'כשיש לך צרכים מקצועיים, אתה משתמש ברכיבים מקצועיים!');
define('_ACA_THINK_PRO_1', 'רשימות תפוצה חכמות');
define('_ACA_THINK_PRO_2', 'הגדר רמת גישה לרשימה שלך');
define('_ACA_THINK_PRO_3', 'הגדר מי יכול לערוך/להוסיף דואר');
define('_ACA_THINK_PRO_4', 'עוד תגיות: הוסף את שדות CB שלך');
define('_ACA_THINK_PRO_5', 'ארכיון אוטומטי של תוכן Joomla');
define('_ACA_THINK_PRO_6', 'אופטימיזצית מאגר המידע');

define('_ACA_LIC_NOT_YET', 'רשיונך טרם אושר. אנא בדוק לשונית רשיון בפאנל הקונפיגורציה');
define('_ACA_PLEASE_LIC_GREEN' , 'דאג לספק את המידע הירוק בראש הלשונית לקבוצת התמיכה שלנו' );

define('_ACA_FOLLOW_LINK' , 'קבל רשיונך');
define( '_ACA_FOLLOW_LINK_TWO' , 'תוכל לקבל רשיונך על ידי הכנסת מספר תזכורת וURL האתר (מודגש בירוק בראש עמוד זה) בטופס הרשיון ');
define( '_ACA_ENTER_TOKEN_TIPS2', ' אז לחץ על כפתור החל בתפריט הימני העליון' );
define( '_ACA_ENTER_LIC_NB', 'הכנס רשיונך' );
define( '_ACA_UPGRADE_LICENSE', 'שדרוג רשיונך');
define( '_ACA_UPGRADE_LICENSE_TIPS' , 'אם קיבלת מפתח לשדרוג הרשיון, אנא הכנס זאת כאן, לחץ על החל והמשך למספר <b>2</b> לקבלת מספר רשיון חדש' );

define( '_ACA_MAIL_FORMAT', 'פורמט קידוד' );
define( '_ACA_MAIL_FORMAT_TIPS', 'באיזה פורמט תרצה להשתמש לקידוד הדואר שלך, טקסט בלבד או MIME' );
define( '_ACA_ACAJOOM_CRON_DESC_ALT', 'אם אין לך גישה למנהל משימות קרון באתר שלך, תוכל להשתמש במרכיב Free jCron בכדי ליצור משימות קרון מהאתר שלך.' );

//since 1.3.1
define('_ACA_SHOW_AUTHOR', 'הראה שם מחבר/ים');
define('_ACA_SHOW_AUTHOR_TIPS', 'בחר כן אם ברצונך להוסיף שם מחבר למאמר שנשלח לדיוור');

//since 1.3.5
define('_ACA_REGWARN_NAME','אנא הכנס את שמך');
define('_ACA_REGWARN_MAIL','אנא הכנס אימייל בר-תוקף');

//since 1.5.6
define('_ACA_ADDEMAILREDLINK_TIPS','אם תבחר כן, האימייל של המשתמש יוסף כפרמטר בסוף הURL המכוון מחדש (הקישור המכוון מחדש למודול שלך או לטופס Acajoom חיצוני)<br/>דבר זה יכול להיות יעיל אם תרצה להשלים סקריפט מיוחד בעמוד המכוון מחדש');
define('_ACA_ADDEMAILREDLINK','הוסף אימייל ללינק המכוון מחדש');

//since 1.6.3
define('_ACA_ITEMID','מזהה פריט');
define('_ACA_ITEMID_TIPS','מזהה פריט יוסף לקישורי Acajoom שלך.');

//since 1.6.5
define('_ACA_SHOW_JCALPRO','jCalPRO');
define('_ACA_SHOW_JCALPRO_TIPS','הראה את לשונית השילוב ל jCalPRO <br/>(רק אם jCalPRO מותקן באתר שלך!)');
define('_ACA_JCALTAGS_TITLE','תגית jCalPRO:');
define('_ACA_JCALTAGS_TITLE_TIPS','העתק והדבק תגית זו לתוך הדיוור איפה שתרצה שהאירוע ימוקם');
define('_ACA_JCALTAGS_DESC','תיאור:');
define('_ACA_JCALTAGS_DESC_TIPS','בחר כן אם ברצונך להכניס תיאור האירוע');
define('_ACA_JCALTAGS_START','תאריך התחלה:');
define('_ACA_JCALTAGS_START_TIPS','בחר כן אם ברצונך להכניס את תאריך תחילת האירוע');
define('_ACA_JCALTAGS_READMORE','קרא עוד:');
define('_ACA_JCALTAGS_READMORE_TIPS','בחר כן אם תרצה לבחור <b>קרא עוד קישורים</b> לאירוע זה');
define('_ACA_REDIRECTCONFIRMATION','לכוון מחדש כתובת');
define('_ACA_REDIRECTCONFIRMATION_TIPS','אם תבקש מייל אישור, המשתמש יכוון לכתובת  זו אם ילחץ על לינק האישור');

//since 2.0.0 compatibility with Joomla 1.5
if(!defined('_CMN_SAVE') and defined('CMN_SAVE')) define('_CMN_SAVE',CMN_SAVE);
if(!defined('_CMN_SAVE')) define('_CMN_SAVE','שמור');
if(!defined('_NO_ACCOUNT')) define('_NO_ACCOUNT','אין לך חשבון עדיין?');
if(!defined('_CREATE_ACCOUNT')) define('_CREATE_ACCOUNT','הרשמה');
if(!defined('_NOT_AUTH')) define('_NOT_AUTH','You are not authorised to view this resource.');

//since 3.0.0
define('_ACA_DISABLETOOLTIP','Disable Tooltip');
define('_ACA_DISABLETOOLTIP_TIPS', 'Disable the tooltip on the frontend');
define('_ACA_MINISENDMAIL', 'Use Mini SendMail');
define('_ACA_MINISENDMAIL_TIPS', 'If your server uses Mini SendMail, select this option to do not add the name of the user in the header of the e-mail');

//Since 3.1.5
define('_ACA_READMORE','Read more...');
define('_ACA_VIEWARCHIVE','Click here');

//since 4.0.0
define('_ACA_SHOW_JLINKS','Link Tracking');
define('_ACA_SHOW_JLINKS_TIPS','Enables the integration with jLinks to be able to do link tracking for each links in the newsletter.');

//since 4.1.0
define( '_ACA_MAIL_ENCODING', 'Mail encoding' );
define( '_ACA_MAIL_ENCODING_TIPS', 'What encoding format do you want to use UTF-8 (highly recommended) or ISO-8859-2' );
define( '_ACA_COPY_SUBJECT', 'Copy Subject' );
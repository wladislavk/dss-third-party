There are a lot of files here, but you need only part of them

Desctop scheduler, default skin
	dhtmlxscheduler.js
	dhtmlxscheduler.css
	imgs\
	
Desctop scheduler, glossy skin
	dhtmlxscheduler.js
	dhtmlxscheduler_glossy.css
	imgs_glossy\

Mobile scheduler
	dhtmlxscheduler_mobile.js
	dhtmlxscheduler_mobile.css
	imgs_mobile\
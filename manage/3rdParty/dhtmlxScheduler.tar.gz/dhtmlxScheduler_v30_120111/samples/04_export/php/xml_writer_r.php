<?php
file_put_contents("./data_r.xml",$_POST["data"]);
header("Location:./php/dummy.html");
?>
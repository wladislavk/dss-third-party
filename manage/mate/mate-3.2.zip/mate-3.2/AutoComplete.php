<?php
/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
require_once('Common.php');
require_once('php/lang/LangVars-en.php');
require_once('php/AjaxTableEditor.php');
class Example1 extends Common
{
	var $Editor;
	
	function displayHtml()
	{
		$html = '
			<style type="text/css">
			div.autocomplete {
				position:absolute;
				width:250px;
				background-color:white;
				border:1px solid #888;
				margin:0px;
				padding:2px;
				max-height: 150px;
				overflow: auto;	
			}
			div.autocomplete ul {
				list-style-type:none;
				margin:0px;
				padding:0px;
			}
			div.autocomplete ul li.selected { 
				background-color: #ffb;
			}
			div.autocomplete ul li {
				list-style-type:none;
				display:block;
				margin:0;
				padding:2px;
				height:45px;
				cursor:pointer;
				text-align: left;
				font-weight: normal;
			}
			
			.informal{
				font-style:italic;
				font-size: 13px;
			}
			
			.autoCompleteText{
				font-size: 13px;
				font-weight: bold;
			}
			</style>
		
			<br />
	
			<div align="left" style="position: relative;"><div id="ajaxLoader1"><img src="images/ajax_loader.gif" alt="Loading..." /></div></div>
			
			<br /><br />
			
			<div id="information">
			</div>
	
			<div id="titleLayer" style="padding: 2px; font-weight: bold; font-size: 18px; text-align: center;">
			</div>
	
			<div id="tableLayer" align="center">
			</div>
			
			<div id="recordLayer" align="center">
			</div>		
			
			<div id="searchButtonsLayer" align="center">
			</div>
			
			<br /><br /><br />
			<div align="center"><a href="index.php">Back To Examples</a></div>

			<div style="display: none;" id="auto_complete_choices" class="autocomplete"></div>';
			
		echo $html;
		
		// Set default session configuration variables here
		$defaultSessionData['orderByColumn'] = 'first_name';

		$defaultSessionData = base64_encode($this->Editor->jsonEncode($defaultSessionData));
		
		$javascript = '	
			<script type="text/javascript">
				function startAutoComplete()
				{
					new Ajax.Autocompleter("department", "auto_complete_choices", "'.$_SERVER["PHP_SELF"].'", {paramName: "dept", method:"post", onFailure: function(){alert("Ajax failed...")}, indicator: "ajaxLoader1"});
				}
				
				setAjaxInfo({url: "'.$_SERVER["PHP_SELF"].'", history: true});
				if(ajaxInfo.history == false)
				{
					toAjaxTableEditor("update_html","");
				}
				else if(window.location.hash.length == 0)
				{
					var defaultInfo = {info: "", action: "update_html", sessionData: "'.$defaultSessionData.'"};
					window.location.href = window.location.href+"#"+Base64.encode(Object.toJSON(defaultInfo));
				}
			</script>';
		echo $javascript;
	}

	function autoComplete()
	{
		$this->Editor->retArr[] = array('where' => 'javascript', 'value' => 'startAutoComplete();');
	}
	
	function initiateEditor()
	{
		$tableColumns['id'] = array('display_text' => 'ID', 'perms' => 'TVQSXO');
		$tableColumns['first_name'] = array('display_text' => 'First Name', 'perms' => 'EVCTAXQSHO');
		$tableColumns['last_name'] = array('display_text' => 'Last Name', 'perms' => 'EVCTAXQSHO');
		$tableColumns['email'] = array('display_text' => 'Email', 'perms' => 'EVCTAXQSHO');
		$tableColumns['department'] = array('display_text' => 'Department', 'perms' => 'EVCTAXQSHO'); 
		$tableColumns['hire_date'] = array('display_text' => 'Hire Date', 'perms' => 'EVCTAXQSHO', 'display_mask' => 'date_format(hire_date,"%d %M %Y")', 'calendar' => array('format' => '%d %B %Y', 'reset' => true),'col_header_info' => 'style="width: 250px;"'); 
		
		$tableName = 'employees';
		$primaryCol = 'id';
		$errorFun = array(&$this,'logError');
		$permissions = 'EAVIDQCSXHO';
		
		$this->Editor = new AjaxTableEditor($tableName,$primaryCol,$errorFun,$permissions,$tableColumns);
		$this->Editor->setConfig('tableInfo','cellpadding="1" width="1000" class="mateTable"');
		$this->Editor->setConfig('orderByColumn','first_name');
		$this->Editor->setConfig('tableTitle','Auto Complete <div style="font-size: 12px; font-weight: normal;">on the department field</div>');
		$this->Editor->setConfig('addRowTitle','Add Employee');
		$this->Editor->setConfig('editRowTitle','Edit Employee');
		$this->Editor->setConfig('addScreenFun',array(&$this,'autoComplete'));
		$this->Editor->setConfig('editScreenFun',array(&$this,'autoComplete'));
		//$this->Editor->setConfig('iconTitle','Edit Employee');
	}
	
	function getDeptSuggestions()
	{
		$html = '<ul>';
		$query = "select distinct department from employees where department like '".mysql_real_escape_string($_POST['dept'])."%' limit 20";
		$result = mysql_query($query);
		while($row = mysql_fetch_assoc($result))
		{
			$html .= '<li><span class="autoCompleteText">'.$row['department'].'</span></li>';
		}
		$html .= '</ul>';
		echo $html;
	}
	
	function Example1()
	{
		session_start();
		ob_start();
		$this->mysqlConnect();
		$this->initiateEditor();
		if(isset($_POST['json']))
		{
			if(ini_get('magic_quotes_gpc'))
			{
				$_POST['json'] = stripslashes($_POST['json']);
			}
			$this->Editor->data = $this->Editor->jsonDecode($_POST['json']);
			$this->Editor->setDefaults();
			$this->Editor->main();
			echo $this->Editor->jsonEncode($this->Editor->retArr);
		}
		else if(isset($_GET['export']))
		{
			$this->Editor->data->sessionData = $_GET['session_data'];
			$this->Editor->setDefaults();
			ob_end_clean();
			header('Cache-Control: no-cache, must-revalidate');
			header('Pragma: no-cache');
			header('Content-type: application/x-msexcel');
			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="'.$this->Editor->tableName.'.csv"');
			// Add utf-8 signature for windows/excel
			echo chr(0xEF).chr(0xBB).chr(0xBF);
			echo $this->Editor->exportInfo();
			exit();
		}
        else if(isset($_POST['dept']))
        {
        	$this->mysqlConnect();
        	$this->getDeptSuggestions();
        }
		else if(isset($_POST) && count($_POST) > 0)
		{
			$this->Editor->setDefaults();
			$this->Editor->handleFileUpload();
        }
		else
		{
			$this->displayHeaderHtml();
			$this->displayHtml();
			$this->displayFooterHtml();
		}
	}
}
$lte = new Example1();
?>

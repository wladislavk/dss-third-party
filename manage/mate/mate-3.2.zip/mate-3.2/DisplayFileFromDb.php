<?php
require_once('Common.php');
class DisplayFileFromDb extends Common
{
	protected $empId;

	function setVars()
	{
		if(isset($_GET['emp_id']))
		{
			$this->empId = $_GET['emp_id'];
		}
	}

	function displayFile()
	{
		$query = "select file_name, file_type, file_data, octet_length(file_data) as file_size from emp_upload_db where id = '".$this->escapeData($this->empId)."'";
		$result = mysql_query($query);
		if($row = mysql_fetch_assoc($result))
		{
			header('Cache-Control: no-cache, must-revalidate');
			header('Pragma: no-cache');
			header('Content-type: '.$row['file_type']);
			header('Content-length: '.$row['file_size']);
			header('Content-Disposition: filename="'.$row['file_name'].'"');
			echo $row['file_data'];
			
		}
		else
		{
			echo 'There was an error finding the specified file.';
		}
	}

	function __construct()
	{
		$this->mysqlConnect();
		$this->setVars();
		$this->displayFile();
	}
}

$page = new DisplayFileFromDb();

?>

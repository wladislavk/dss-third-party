<?php
/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
require_once('Common.php');
require_once('php/lang/LangVars-en.php');
require_once('php/AjaxTableEditor.php');
class JoinExample extends Common
{
	function displayHtml()
	{
		$html = '
			<br />
			
			<div align="left" style="position: relative;"><div id="ajaxLoader1"><img src="images/ajax_loader.gif" alt="Loading..." /></div></div>
			
			<br />
			
			<div id="information">
			</div>
			
			<div id="titleLayer" style="padding: 2px; font-weight: bold; font-size: 18px; text-align: center;">
			</div>
			
			<div id="tableLayer" align="center">
			</div>
			
			<div id="recordLayer" align="center">
			</div>
			
			<div id="searchButtonsLayer" align="center">
			</div>
			
			<br /><br /><br />
			<div align="center"><a href="index.php">Back To Examples</a></div>';
		echo $html;
		// Set default session configuration variables here
		$defaultSessionData['orderByColumn'] = 'employee_id';
		
		$defaultSessionData = base64_encode($this->Editor->jsonEncode($defaultSessionData));
		
		
		$javascript = '	
			<script type="text/javascript">
				setAjaxInfo({url: "'.$_SERVER["PHP_SELF"].'", history: true});
				if(ajaxInfo.history == false)
				{
					toAjaxTableEditor("update_html","");
				}
				else if(window.location.hash.length == 0)
				{
					var defaultInfo = {info: "", action: "update_html", sessionData: "'.$defaultSessionData.'"};
					window.location.href = window.location.href+"#"+Base64.encode(Object.toJSON(defaultInfo));
				}
			</script>';
		echo $javascript;
	}

	function updateLogin($empId)
	{
		$query = "select first_name, last_name from employees where id = '$empId'";
		$result = mysql_query($query);
		if($row = mysql_fetch_array($result,MYSQL_ASSOC))
		{
			$suggestedLogin = strtolower(substr($row['first_name'],0,1).$row['last_name']).rand(100,999);
			$this->Editor->retArr[] = array('where' => 'javascript', 'value' => '$("login").value = "'.$suggestedLogin.'";');
		}
	}
	
	function initiateEditor()
	{
		$tableColumns['id'] = array('display_text' => 'ID', 'perms' => '');
		$tableColumns['employee_id'] = array(
			'display_text' => 'Name', 'perms' => 'EVCTAXQ', 
			'join' => array('table' => 'employees', 'column' => 'id', 
				'display_mask' => "concat(employees.first_name,' ',employees.last_name)", 
				'type' => 'left'),
			'input_info' => 'onchange="toAjaxTableEditor(\'update_login\',this.value);"'
		);
		$tableColumns['login'] = array('display_text' => 'Login', 'perms' => 'EVCTAXQ');
		$tableColumns['password'] = array('display_text' => 'Password', 'perms' => 'EVCAXQT',
			'mysql_add_fun' => 'PASSWORD','mysql_edit_fun' => 'PASSWORD'); 
		$tableColumns['account_type'] = array('display_text' => 'Account Type', 'perms' => 'EVCTAXQ', 
			'select_array' => array('Admin' => 'Admin', 'User' => 'User'), 'default' => 'User'); 
		
		$tableName = 'login_info';
		$primaryCol = 'id';
		$errorFun = array(&$this,'logError');
		$permissions = 'EAVDQCSM';
		
		require_once('php/AjaxTableEditor.php');
		$this->Editor = new AjaxTableEditor($tableName,$primaryCol,$errorFun,$permissions,$tableColumns);
		$this->Editor->setConfig('tableInfo','cellpadding="1" width="900" class="mateTable"');
		$this->Editor->setConfig('tableTitle','Multiple Edit / User Action / Join Example');
		$this->Editor->setConfig('addRowTitle','Add Login Info');
		$this->Editor->setConfig('editRowTitle','Edit Login Info');
		$this->Editor->setConfig('viewRowTitle','View Login Info');
		$userActions = array('update_login' => array(&$this,'updateLogin'));
		$this->Editor->setConfig('userActions',$userActions);
		//$this->Editor->setConfig('orderByColumn','employee_id');
	}
	
	
	function JoinExample()
	{
		session_start();
		ob_start();
		$this->mysqlConnect();
		$this->initiateEditor();
		if(isset($_POST['json']))
		{
			if(ini_get('magic_quotes_gpc'))
			{
				$_POST['json'] = stripslashes($_POST['json']);
			}
			$this->Editor->data = $this->Editor->jsonDecode($_POST['json']);
			$this->Editor->setDefaults();
			$this->Editor->main();
			echo $this->Editor->jsonEncode($this->Editor->retArr);
		}
		else if(isset($_GET['export']))
		{
			$this->Editor->data->sessionData = $_GET['session_data'];
			$this->Editor->setDefaults();
			ob_end_clean();
			header('Cache-Control: no-cache, must-revalidate');
			header('Pragma: no-cache');
			header('Content-type: application/x-msexcel');
			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="'.$this->Editor->tableName.'.csv"');
			// Add utf-8 signature for windows/excel
			echo chr(0xEF).chr(0xBB).chr(0xBF);
			echo $this->Editor->exportInfo();
			exit();
		}
		else if(isset($_POST) && count($_POST) > 0)
		{
			$this->Editor->setDefaults();
			$this->Editor->handleFileUpload();
        }
		else
		{
			$this->displayHeaderHtml();
			$this->displayHtml();
			$this->displayFooterHtml();
		}
	}
}
$lte = new JoinExample();
?>
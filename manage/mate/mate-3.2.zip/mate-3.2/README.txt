/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
 
Installation Instructions

1. Set the mysql variables in Common.php with the correct information to connect to your mysql database.

2. Create the example tables in your database by running the sql in the mate.sql file.

3. In order for the upload to directory script to work you will need to set the permissions on the uploads directory to 777.

4. After you create the tables and have successfully connected to your database, the examples should be working. Point your browser to www.yoursite.com/path/to/mate-3.2/ and click on one of the example links. If you have any troubles installing please post a question on the forums.

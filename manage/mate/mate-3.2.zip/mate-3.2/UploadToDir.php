<?php
/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
require_once('Common.php');
require_once('php/lang/LangVars-en.php');
require_once('php/AjaxTableEditor.php');
class UploadToDir extends Common
{
	var $Editor;
	var $dataDir = 'uploads/';
	
	function displayHtml()
	{
		$html = '
			<br />
	
			<div align="left" style="position: relative;"><div id="ajaxLoader1"><img src="images/ajax_loader.gif" alt="Loading..." /></div></div>
			
			<br />
			
			<div id="information">
			</div>
			
			<div id="titleLayer" style="padding: 2px; font-weight: bold; font-size: 18px; text-align: center;">
			</div>
			
			<div id="tableLayer" align="center">
			</div>
			
			<div id="filterLayer" align="center">
			</div>
			
			<div id="recordLayer" align="center">
			</div>
			
			<div id="searchButtonsLayer" align="center">
			</div>
			
			<br /><br /><br />
			<div align="center"><a href="index.php">Back To Examples</a></div>';
		
		echo $html;
			
		// Set default session configuration variables here
		$defaultSessionData['orderByColumn'] = 'first_name';

		$defaultSessionData = base64_encode($this->Editor->jsonEncode($defaultSessionData));
		
		$javascript = '	
			<script type="text/javascript">
				setAjaxInfo({url: "'.$_SERVER["PHP_SELF"].'", history: true});
				if(ajaxInfo.history == false)
				{
					toAjaxTableEditor("update_html","");
				}
				else if(window.location.hash.length == 0)
				{
					var defaultInfo = {info: "", action: "update_html", sessionData: "'.$defaultSessionData.'"};
					window.location.href = window.location.href+"#"+Base64.encode(Object.toJSON(defaultInfo));
				}
			</script>';
		echo $javascript;
	}
	
	function formatFileSize($col,$size,$row)
	{
		$sizes = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
		$retstring = '%01.2f %s';
		$lastsizestring = end($sizes);
		foreach ($sizes as $sizestring) 
		{
				if ($size < 1024) { break; }
				if ($sizestring != $lastsizestring) { $size /= 1024; }
		}
		if ($sizestring == $sizes[0]) { $retstring = '%01d %s'; }
		return sprintf($retstring, $size, $sizestring);
	}
	
	function formatImage($col,$val,$row)
	{
		$html = '';
		if(strlen($val) > 0)
		{
			$html .= '<a target="_blank" href="uploads/'.$val.'"><img style="border: none;" src="uploads/'.$val.'" alt="'.$val.'" width="100" /></a>';
		}
		return $html;
	}
	
	function handleUpload($id,$col,$filesArr,$valErrors)
	{
		if(count($valErrors) == 0)
		{
			// Delete image file if the employee already had one
			$query = "select file_name from emp_upload_dir where id = '".$this->Editor->escapeData($id)."'";
			$result = $this->Editor->doQuery($query);
			if($row = mysql_fetch_assoc($result))
			{
				unlink($this->dataDir.$row['file_name']);
			}
			// Copy file to data directory and update database with the file name.
			if(move_uploaded_file($filesArr['tmp_name'],$this->dataDir.$filesArr['name']))
			{
				$query = "update emp_upload_dir set file_name = '".$this->Editor->escapeData($filesArr['name'])."' where id = '".$this->Editor->escapeData($id)."'";
				$result = $this->Editor->doQuery($query);
				if(!$result)
				{
					$valErrors[] = 'There was an error updating the database.';
					unlink($this->dataDir.$filesArr['name']);
				}
			}
			else
			{
				$valErrros[] = 'The file could not be moved';
			}
		}
		return $valErrors;
	}
	
	function initiateEditor()
	{
		$tableColumns['id'] = array('display_text' => 'ID', 'perms' => 'ETVQSFXO');
		$tableColumns['first_name'] = array('display_text' => 'First Name', 'perms' => 'EVCTAXQSFHO', 'req' => true);
		$tableColumns['last_name'] = array('display_text' => 'Last Name', 'perms' => 'EVCTAXQSFHO', 'val_fun' => array(&$this,'validateFun'));
		$tableColumns['email'] = array('display_text' => 'Email', 'perms' => 'EVCTAXQSFHO');
		$tableColumns['department'] = array('display_text' => 'Department', 'perms' => 'EVCTAXQSFHO', 
			'select_array' => array('Accounting' => 'Accounting', 'Marketing' => 'Marketing', 'Sales' => 'Sales', 'Production' => 'Production')
		); 
		$tableColumns['file_name'] = array('display_text' => 'Image', 'perms' => 'EVCAXTQSFHO', 
			'file_upload' => array('upload_fun' => array(&$this,'handleUpload')), 
			'table_fun' => array(&$this,'formatImage'), 'view_fun' => array(&$this,'formatImage')
		);
		
		$tableName = 'emp_upload_dir';
		$primaryCol = 'id';
		$errorFun = array(&$this,'logError');
		$permissions = 'EAVDCXHOUFI';
		
		$this->Editor = new AjaxTableEditor($tableName,$primaryCol,$errorFun,$permissions,$tableColumns);
		$this->Editor->setConfig('tableInfo','cellpadding="1" width="1100" class="mateTable"');
		$this->Editor->setConfig('tableTitle','Upload To Directory');
		$this->Editor->setConfig('addRowTitle','Add Employee');
		$this->Editor->setConfig('editRowTitle','Edit Employee');
		$this->Editor->setConfig('paginationLinks',true);
		//$this->Editor->setConfig('viewQuery',true);
	}
	
	function UploadToDir()
	{
		session_start();
		ob_start();
		$this->mysqlConnect();
		$this->initiateEditor();
		if(isset($_POST['json']))
		{
			if(ini_get('magic_quotes_gpc'))
			{
				$_POST['json'] = stripslashes($_POST['json']);
			}
			$this->Editor->data = $this->Editor->jsonDecode($_POST['json']);
			$this->Editor->setDefaults();
			$this->Editor->main();
			echo $this->Editor->jsonEncode($this->Editor->retArr);
		}
		else if(isset($_GET['export']))
		{
			$this->Editor->data->sessionData = $_GET['session_data'];
			$this->Editor->setDefaults();
			ob_end_clean();
			header('Cache-Control: no-cache, must-revalidate');
			header('Pragma: no-cache');
			header('Content-type: application/x-msexcel');
			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="'.$this->Editor->tableName.'.csv"');
			// Add utf-8 signature for windows/excel
			echo chr(0xEF).chr(0xBB).chr(0xBF);
			echo $this->Editor->exportInfo();
			exit();
		}
		else if(isset($_POST) && count($_POST) > 0)
		{
			$this->Editor->setDefaults();
			$this->Editor->handleFileUpload();
        }
		else
		{
			$this->displayHeaderHtml();
			$this->displayHtml();
			$this->displayFooterHtml();
		}
	}
}
$lte = new UploadToDir();
?>
<?php
/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
require_once('Common.php');
class HomePage extends Common
{
	
	function displayHtml()
	{
		echo '<h2>Example Scripts</h2>';
		echo '<p><a href="AutoComplete.php">Auto Complete</a></p>';
		echo '<p><a href="JoinExample.php">Multiple Edit / User Action / Join Example</a></p>';
		echo '<p><a href="UploadToDir.php">Upload To Directory</a></p>';
		echo '<p><a href="UploadToDb.php">Upload To Database</a></p>';
	}
	
	function HomePage()
	{
		$this->displayHeaderHtml();
		$this->displayHtml();
		$this->displayFooterHtml();
	}
}
$lte = new HomePage();
?>
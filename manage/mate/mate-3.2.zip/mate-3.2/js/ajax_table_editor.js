﻿/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2008 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */

// Set jsPath var and include the language file if it hasn't been included
var scripts = document.getElementsByTagName('script');
var script = scripts[scripts.length - 1];
var pathWithFile = script.getAttribute("src");
var jsPath = pathWithFile.indexOf('/') >= 0 ? pathWithFile.match(/^(.+)\//)[0] : '';

if(typeof(mateDeleteMsg) == 'undefined' || mateDeleteMsg == null)
{
	document.write('<script type="text/javascript" src="'+jsPath+'lang/lang_vars-en.js"></scr' + 'ipt>');
}

var mateSubmitEmptyUpload = false;
var ajaxInfo = {hash: '', history: false, intervalId: '', interval: 100, url: '', ajaxLoaderImage: 'ajaxLoader1'};	

function setAjaxInfo(info)
{
	if(info.interval == null && typeof document.all !== "undefined") 
	{
		// Set interval slower for IE
		info.interval = 250;
	}
	Object.extend(ajaxInfo,info);
	if(ajaxInfo.history && ajaxInfo.intervalId.length == 0) 
	{
		ajaxInfo.intervalId = setInterval('checkForHashChange()',ajaxInfo.interval);
	}
	else if(!ajaxInfo.history && ajaxInfo.intervalId > 0) 
	{
		clearInterval(ajaxInfo.intervalId);
	}
}

function displayInfo(info)
{
	var i = 0;
	while(info[i] != null)
	{
		if(info[i].layer_id != null && info[i].layer_id.length > 0 && $(info[i].layer_id) == null)
		{
			// Un-comment for debugging
			// alert(info[i].layer_id + ' does not exist');
		}
		else
		{
			if(info[i].where == 'innerHTML')
			{
				$(info[i].layer_id).innerHTML = info[i].value;
			}
			else if(info[i].where == 'remove')
			{
				$(info[i].layer_id).remove();
			}
			else if(info[i].where == 'append')
			{
				$(info[i].layer_id).insert(info[i].value);
			}
			else if(info[i].where == 'value')
			{
				$(info[i].layer_id).value = info[i].value;
			}
			else if(info[i].where == 'javascript')
			{
				try
				{
					eval(info[i].value);
				}
				catch(e)
				{
					// Un-comment for debugging
					// alert(info[i].value+' did not execute correctly');
				}
			}
		}
		i = i + 1;
	}
	if($('ajaxLoader1') != null)
	{
		$('ajaxLoader1').setStyle('display: none;');
	}
}

function toAjaxTableEditor(action,info,options)
{
	if($('ajaxLoader1') != null)
	{
		$('ajaxLoader1').setStyle('display: inline;');
	}
	
	options = options == null ? new Object() : options;
	options.url = options.url == null ? ajaxInfo.url : options.url;
	options.updateHistory = options.updateHistory == null ? false : options.updateHistory;
	
	var sessionData = options.sessionData == null ? getSessionData() : options.sessionData;
	var data = new Object();
	data.action = action;
	data.info = info;
	data.sessionData = sessionData;
	var json = encodeURIComponent(Object.toJSON(data));
	if(ajaxInfo.history && options.updateHistory) 
	{
		ajaxInfo.hash = Object.toJSON({info: info, action: action, sessionData: sessionData, url: options.url});
		window.location.hash = Base64.encode(ajaxInfo.hash);
	}
	new Ajax.Request(options.url,
	{
		method:'post',
		parameters: 'json='+json,
		onSuccess: 
		function(transport)
		{
			if(transport.responseText.isJSON())
			{
				displayInfo(transport.responseText.evalJSON(true));
			}
			else 
			{
				var respText = transport.responseText.replace(/<br \/>/g, '\n');
				alert(mateErrRespText+'\n\n' + respText.replace(/<br>/g, '\n'));
			}
			if(options.onCompleteFun)
			{
				options.onCompleteFun();
			}
			// Un-comment to view json returned from server
			//alert(transport.responseText);
		},
		onFailure: function(){ alert(mateErrAjaxUrl) }
	});
}

function checkForHashChange() 
{
	var newHash = window.location.hash;
	newHash = newHash.replace("#","");
	if(newHash.length == 0) 
	{
		//alert('i am here');
	}
	if(newHash != ajaxInfo.hash && newHash.length > 0) 
	{
		ajaxInfo.hash = newHash;
		var newHashDecoded = Base64.decode(newHash);
		var data = newHashDecoded.evalJSON(true);
		toAjaxTableEditor(data.action,data.info,{url: data.url, sessionData: data.sessionData});
	}
}

function storeSessionData(sessionData)
{
	if($('session_data'))
	{
		$('session_data').value = sessionData;
	}
	else
	{
		$('searchButtonsLayer').insert({after: '<input type="hidden" id="session_data" value="'+sessionData+'" />'});
	}
}

function getSessionData()
{
	if($('session_data'))
	{
		return $('session_data').value;
	}
	return '';
}

function handleSearch()
{
	var info = $('searchString').value;
	toAjaxTableEditor('handle_search',info,{updateHistory: true});
}

function clearSearch()
{
	$('searchString').value = '';	
	toAjaxTableEditor('handle_search','',{updateHistory: true});
}

function confirmDeleteRow(id)
{
	if(confirm(mateDeleteMsg))
	{
		toAjaxTableEditor('delete_row',id);
	}
}

function showUploadMessage(message)
{
	if($('fileUploadInfo') == null)
	{
		$('titleLayer').insert('<div id="fileUploadInfo">'+message+'</div>');
	}
	else
	{
		$('fileUploadInfo').innerHTML = message;
	}
}

function disableButtons()
{
	$$('#addRowButtons button','#editRowButtons button').each(function(btn)
	{
		btn.disabled = true;
	});
}

function enableButtons()
{
	$$('#addRowButtons button','#editRowButtons button').each(function(btn)
	{
		btn.disabled = false;
	});
}

function gatherInputInfo(varPrefix)
{
	var info = new Object();
	var formElem = document.getElementById(varPrefix + '_add_edit_form');
	for(i=0; i < formElem.elements.length; i++)
	{
		var inputId = formElem.elements[i].id;
		if(inputId.length > 0 && formElem.elements[i].disabled == false)
		{
			if(formElem.elements[i].type.toLowerCase() == 'file')
			{
				if(formElem.elements[i].value.length > 0 || mateSubmitEmptyUpload)
				{
					info['submit_mate_file_upload'] = true;
				}
			}
			else if(formElem.elements[i].type.toLowerCase() == 'radio')
			{
				if(formElem.elements[i].checked)
				{
					info[inputId] = formElem.elements[i].value;
				}
			}
			else
			{
				info[inputId] = $(inputId).value;
			}
		}
	}
	return info;
}

function updateRow(id,varPrefix)
{
	disableButtons();
	var info = gatherInputInfo(varPrefix);
	info['old_primary_key_value'] = id;
	toAjaxTableEditor('update_row',info);
}

function updateMultRows(idArr,varPrefix)
{
	if(confirm(mateUpdateMultMsg.replace(/#num_rows#/,idArr.length)))
	{
		//disableButtons();
		var info = new Object();
		info.idArr = idArr;
		info.inputInfo = gatherInputInfo(varPrefix);
		toAjaxTableEditor('update_mult_rows',info);
	}
}

function addRow(varPrefix)
{
	disableButtons();
	var info = gatherInputInfo(varPrefix);
	toAjaxTableEditor('insert_row',info);
}

function submitFileUploadForm(varPrefix)
{
	$(varPrefix + '_add_edit_form').submit();
	showUploadMessage(mateUploading);
}

function uploadFinished(valErrorHtml,id,displayEdit)
{
	if(valErrorHtml.length > 0)
	{
		if(displayEdit)
		{
			var displayValError = function(){showUploadMessage(valErrorHtml);};
			toAjaxTableEditor('edit_row',id,{onCompleteFun: displayValError});
		}
		else
		{
			showUploadMessage(valErrorHtml);
			enableButtons();
		}
	}
	else
	{
		toAjaxTableEditor('update_html','',{updateHistory: true});
	}
}

function enterPressed(e)
{
	var characterCode;
	if(e && e.which)
	{           // NN4 specific code
		e = e;
		characterCode = e.which;
	}
	else 
	{
		e = event;
		characterCode = e.keyCode; // IE specific code
	}
	if (characterCode == 13)
	{
		return true;   // Enter key is 13
	}
	else
	{
		return false;
	}
}

function handleAdvancedSearch(numSearches)
{
	var i;
	var info = new Object();
	for(i = 0; i < numSearches; i++)
	{
		info[i] = new Object();
		info[i]['cols'] = $('as_cols_' + i).value;
		info[i]['opts'] = $('as_opts_' + i).value;
		info[i]['strs'] = $('as_strs_' + i).value;
	}
	toAjaxTableEditor('advanced_search',info,{updateHistory: true});
}

function selectCbs(cb,varPrefix)
{
	var tableForm = $(varPrefix + '_table_form');
	if(cb.checked)
	{
		for(i=0; i < tableForm.elements.length; i++)
		{
			var checkbox = tableForm.elements[i];
			if(checkbox.disabled == false)
			{
				checkbox.checked = true;
				changeRowStyle(checkbox);
			}
		}
	}
	else
	{
		for(i=0; i < tableForm.elements.length; i++)
		{
			var checkbox = tableForm.elements[i];
			if(checkbox.disabled == false)
			{
				checkbox.checked = false;
				changeRowStyle(checkbox);
			}
		}
	}
}

function changeRowStyle(cb)
{
	var idParts = cb.id.split('_');
	var id = idParts[1];
	if(cb.checked)
	{
		var row = $('row_' + id);
		if(row != null)
		{
			row.setStyle('background-color: #fcffd0;');
		}
	}
	else
	{
		var row = $('row_' + id);
		if(row != null)
		{
			var oldColor = '#ffffff;';
			if(row.hasAttribute("bgcolor"))
			{
				oldColor = row.getAttribute("bgcolor");
			}
			row.setStyle('background-color: ' + oldColor + ';');
		}
	}
}

function checkBoxClicked(cb)
{
	var idParts = cb.id.split('_');
	var id = idParts[1];
	if(cb.checked)
	{
		cb.checked = false;
	}
	else
	{
		cb.checked = true;
	}
}

function cellClicked(id)
{
	var cb = $('cb_' + id);
	if(cb.checked)
	{
		cb.checked = false;
	}
	else
	{
		cb.checked = true;
	}
	changeRowStyle(cb);
}

function userButtonClicked(varPrefix,buttonKey,confirmMsg)
{
	var info = new Object();
	info['buttonKey'] = buttonKey;
	info['checkboxes'] = new Object();
	var numRows = 0;
	var tableForm = $(varPrefix + '_table_form');
	for(i=0; i < tableForm.elements.length; i++)
	{
		var cb = tableForm.elements[i];
		if(cb.checked && cb.id != 'select_all_cb')
		{
			info['checkboxes'][i] = cb.value;
			numRows++;
		}
	}
	if(numRows == 0)
	{
		alert(mateSelectRow);	
	}
	else if(confirmMsg.length > 0)
	{
		if(confirm(confirmMsg))
		{
			toAjaxTableEditor('user_button_clicked',info);
		}
	}
	else
	{
		toAjaxTableEditor('user_button_clicked',info);		
	}
}

function userIconClicked(action,info,confirmMsg)
{
	if(confirmMsg.length > 0)
	{
		if(confirm(confirmMsg))
		{
			toAjaxTableEditor(action,info);
		}
	}
	else
	{
		toAjaxTableEditor(action,info);		
	}
}

function editCopyViewDelete(varPrefix,action)
{
	var info = new Object();
	var numRows = 0;
	var selectedIndex;
	var tableForm = $(varPrefix + '_table_form');
	for(i=0; i < tableForm.elements.length; i++)
	{
		var cb = tableForm.elements[i];
		if(cb.checked && cb.type.toLowerCase() == 'checkbox' && cb.id != 'select_all_cb')
		{
			info[i] = cb.value;
			selectedIndex = i;
			numRows++;
		}
	}
	if(numRows == 0)
	{
		alert(mateSelectRow);
	}
	else
	{
		if(action == 'edit_row')
		{
			if(numRows == 1)
			{
				toAjaxTableEditor(action,info[selectedIndex],{updateHistory: true});
			}
			else
			{
				//alert(mateEdit1Row);
				toAjaxTableEditor('edit_mult_rows',info,{updateHistory: true});				
			}
		}
		else if(action == 'view_row')
		{
			if(numRows == 1)
			{
				toAjaxTableEditor(action,info[selectedIndex],{updateHistory: true});
			}
			else
			{
				alert(mateView1Row);	
			}
		}
		else if(action == 'delete_mult_rows')
		{
			var confirmMsg;
			if(numRows == 1)
			{
				confirmMsg = mateDeleteMsg;
			}
			else
			{
				confirmMsg = mateDeleteMultMsg.replace(/#num_rows#/,numRows);
			}
			if(confirm(confirmMsg))
			{
				toAjaxTableEditor(action,info);
			}
		}
		else if(action == 'copy_mult_rows')
		{
			if(numRows == 1)
			{
				toAjaxTableEditor('copy_row',info[selectedIndex]);
			}
			else if(confirm(mateCopyMultMsg.replace(/#num_rows#/,numRows)))
			{
				toAjaxTableEditor(action,info);
			}
		}
	}
}

function formatDate(dateStr,dateFormat)
{
	var date = new Date(dateStr.substring(0,4),dateStr.substring(5,7) - 1,dateStr.substring(8,10),dateStr.substring(11,13),dateStr.substring(14,16),dateStr.substring(17,19));
	info = new Object();
	info["disp_date"] = date.print(dateFormat);
	info["php_date"] = dateStr;
	info["js_date"] = date;
	return info;
}

function prepareForCalendar(input,id,dateFormat,resetDate,extraInfo)
{
	var jsPath2 = jsPath == null ? 'js/' : jsPath;
	if(input)
	{
		if(dateFormat == null || dateFormat == '') { dateFormat = '%d %B %Y'; }
		if(extraInfo == null || extraInfo == '') { extraInfo = ''; }
		input.id = id;
		var phpDate = '0000-00-00';
		var dispDate = mateNoDate;
		var jsDate = new Date();
		var result = input.value.search(/0000-00-00/);
		if(resetDate == null || resetDate == '')
		{
			var resetDate = ''; 
		}
		else
		{
			resetDate = '<a class="resetDate" href="javascript: void(0);" onclick="resetDate(\''+id+'\');" title="'+mateRemoveDate+'"><img src="'+jsPath2.substring(0,jsPath2.length - 3)+'images/reset_date.gif" alt="reset" /></a>';
		}
		if(result == -1 && input.value.length > 0)
		{
			dateInfo = formatDate(input.value,dateFormat);
			dispDate = dateInfo["disp_date"];
			jsDate = dateInfo["js_date"];
			phpDate = dateInfo["php_date"];
		}
		var container = input.parentNode;
		container.innerHTML = '<span id="show_'+id+'">'+dispDate+'</span><img src="'+jsPath2+'jscalendar/img.gif" id="trigger_'+id+'" style="cursor: pointer; border: 1px solid red; margin: 0 3px 0 3px;" title="Date selector" onMouseOver="this.style.background=\'red\';" onmouseout="this.style.background=\'\'" />'+resetDate+extraInfo+'<input type="hidden" name="'+id+'" id="'+id+'" value="'+phpDate+'" />';
		Calendar.setup({
			inputField     :    id,     // id of the input field
			ifFormat       :    "%Y-%m-%d %H:%M:%S",     // format of the input field (even if hidden, this format will be honored)
			displayArea    :    "show_"+id,       // ID of the span where the date is to be shown
			daFormat       :    dateFormat,     // format of the displayed date
			button         :    "trigger_"+id,  // trigger button (well, IMG in our case)
			align          :    "Tl",
			date           :    jsDate,
			singleClick    :    true,		
			weekNumbers    :    false
		});			
	}
}

function resetDate(id)
{
	$(id).value = '0000-00-00';
	$('show_'+id).innerHTML = mateNoDate;
}

function resetScrollTop()
{
	document.documentElement.scrollTop = 0;
	document.body.scrollTop = 0;
}

function showHideColumn(cb,col)
{
    if(cb.checked)
    {
        toAjaxTableEditor('show_column',col);
    }
    else
    {
        toAjaxTableEditor('hide_column',col);
    }
}

function disableEnableInput(column,cb)
{
	if(cb.checked)
	{
		$(column).disabled = false;
		if($(column + '_req_mark') != null)
		{
			$(column + '_req_mark').setStyle("display: inline;");
		}
	}
	else
	{
		$(column).disabled = true;
		if($(column + '_req_mark') != null)
		{
			$(column + '_req_mark').setStyle("display: none;");
		}
	}
}

function updateCheckBoxValue(cb,checkedValue,unCheckedValue)
{
	if(cb.checked)
	{
		cb.value = checkedValue;
	}
	else
	{
		cb.value = unCheckedValue;
	}
}

function displayFilters(varPrefix)
{
	if($(varPrefix+'_header_row') != null)
	{
		var cellWidth = 0;
		var inputWidth = 0;
		var html = '<tr id="'+varPrefix+'_filter_row" style="display: table-row;">';
		var headerRow = $(varPrefix+'_header_row');
		var table = $(headerRow).up(0);
		var headerCells = headerRow.select('td');
		headerCells.each(
			function(td) {
				cellWidth = td.getWidth();
				html += '<td style="width: '+cellWidth+'px;">';
				if(td.hasAttribute('filterCol'))
				{
					var filterCol = td.getAttribute('filterCol');
					var filterStr = td.getAttribute('filterStr');
					inputWidth = cellWidth * .9;
					inputWidth = inputWidth.round();
					html += '<input id="'+varPrefix+'_filter_'+filterCol+'" class="filterInput" filterCol="'+filterCol+'" type="text" style="width: '+inputWidth+'px;" value="'+filterStr+'" onKeyPress="if(enterPressed(event)){handleFilterSearch(this); return false;}" />';
				}
				else
				{
					html += '&nbsp;';
				}
				html += '</td>';
			}
		);
		html += '</tr>';
		// Put filters at the top of the table
		//$(headerRow).insert({after: html});
		// Put filters at the bottom of the table
		$(table).insert(html);
	}
}

function handleFilterSearch(currentInput)
{
	var info = new Object();
	var filters = new Object();
	counter = 0;
	$$('.filterInput').each(
		function(input){
			filters[counter] = {filterStr: input.value, filterCol: input.getAttribute('filterCol')};
			counter++;
		}
	);
	info.filters = filters;
	if(currentInput != null)
	{
		info.currentFilterId = currentInput.id;
	}
	toAjaxTableEditor('handle_filter_search',info,{updateHistory: true});
}

function handleExport(url)
{
	var sessionData = getSessionData();
	window.location = url+'?export=1&session_data='+sessionData;
}

function displayObjProps(object) {
	var properties = '';
	for(var property in object) {
		properties += property+':\n'+object[property]+'\n';
	}
	alert(properties);
}

var Base64 = {
 
	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
 
	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = Base64._utf8_encode(input);
 
		while (i < input.length) {
 
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);
 
			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;
 
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
 
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
 
		}
 
		return output;
	},
 
	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
		while (i < input.length) {
 
			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));
 
			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
 
			output = output + String.fromCharCode(chr1);
 
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
 
		}
 
		output = Base64._utf8_decode(output);
 
		return output;
 
	},
 
	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
 
		for (var n = 0; n < string.length; n++) {
 
			var c = string.charCodeAt(n);
 
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
 
		}
 
		return utftext;
	},
 
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
 
		while ( i < utftext.length ) {
 
			c = utftext.charCodeAt(i);
 
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
 
		}
 
		return string;
	}
 
}

jQuery Timepicker Addon
=======================

Use
---
- To use this plugin you must include jQuery and jQuery UI with datepicker and slider
- Include timepicker-addon script
- now use timepicker with $('#selector').datetimepicker() or $('#selector').timepicker()

Contributing Code - Please Read!
--------------------------------
All code contributions and bug reports are much appreciated.  Please be sure to apply your fixes to the "dev" branch.

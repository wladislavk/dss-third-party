<? include"includes/top.htm"?>   
<table width="960" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="98" valign="top" class="head_bg1" style="padding-top:10px;">
			    <table width="940" border="0" align="center" cellpadding="5" cellspacing="1">
                <tr>
                  <td class="head_text">Heading</td>
                </tr>
                <tr>
                  <td  class="linetile"></td>
                </tr>
                <tr>
                  <td><table width="935" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="270" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr> 
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                           <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="" height="1"></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">
						  <a href="#" id="page3_tabs" >What is OSA Syndrome?</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="page3_bg2">&nbsp;</td>
                        </tr>
                      </table></td>
                      <td width="665" valign="top"><table width="640" border="0" align="right" cellpadding="5" cellspacing="1">
                        <tr>
                          <td width="19" valign="top"><img src="images/bullet_1.gif" width="19" height="13" /></td>
                          <td width="618" valign="top" class="suntab_head">What is Obstructive Sleep Apnea Syndrome?</td>
                        </tr>
                        <tr>
                          <td colspan="2" valign="top"><img src="images/sub_image1.gif" width="160" height="131" hspace="5" vspace="5" align="left" />Apnea literally means &quot;cessation of breath&quot;.Obstructive Sleep Apnea is simply what the words state - obstructions that happen during sleep that cause a cessation of breath. The human upper airway is encircled by muscles. The largest of these muscles is the tongue. When we are awake we have tonicity or tightness in these muscles of the upper airway but during sleep these muscles relax.<br /></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
            </tr>
         
          
        </table>
<? include"includes/bottom.htm"?>
<?php

require_once('admin/includes/config.php');
include("includes/sescheck.php");
require_once("admin/includes/general.htm");
require_once('includes/constants.inc');
require_once('includes/formatters.php');

if (isset($_POST['partial_name'])) {
	$partial = $_POST['partial_name'];
	$partial = ereg_replace("[^ A-Za-z'\-]", "", $partial);
	$partial = s_for($partial);
}

$names = explode(" ", $partial);

$sql = "SELECT p.patientid, p.lastname, p.firstname, p.middlename, p.status AS stat, p.premedcheck,  "
  .   " s.fspage1_complete, s.next_visit, s.last_visit, s.last_treatment,  "
  .		" s.delivery_date, s.vob, s.ledger, d.device "
	.		" FROM dental_patients p"
  .   " LEFT JOIN dental_patient_summary s ON p.patientid = s.pid  "
  .   " LEFT JOIN dental_device d ON s.appliance = d.deviceid "
	.		" WHERE ((lastname LIKE '" . $names[0] . "%' OR firstname LIKE '" . $names[0] . "%')" 
	.		" AND (lastname LIKE '" . $names[1] . "%' OR firstname LIKE '" . $names[1] . "%'))"
	.		" AND docid = '" . $_SESSION['docid'] . "' ORDER BY lastname ASC;";
$result = mysql_query($sql);

$patients = array();
$i = 0;
while ($row = mysql_fetch_assoc($result)) {
	$patients[$i]['patientid'] = $row['patientid'];
  $patients[$i]['lastname'] = $row['lastname'];
  $patients[$i]['firstname'] = $row['firstname'];
  $patients[$i]['middlename'] = $row['middlename'];
  $patients[$i]['stat'] = $row['stat'];
  $patients[$i]['premedcheck'] = $row['premedcheck'];
  $patients[$i]['fspage1_complete'] = ($row['fspage1_complete'] == 1 ? "Yes" : "<span class=\"red\">No</span>");
  $patients[$i]['next_visit'] = format_date($row['next_visit']);
  $patients[$i]['last_visit'] = format_date($row['last_vist'], true);
  $patients[$i]['last_treatment'] = ($row['last_treatment'] == null ? 'N/A' : $row['last_treatment']);
  $patients[$i]['delivery_date'] = format_date($row['delivery_date'], true);
  $patients[$i]['vob'] = ($row['vob'] == null ? 'N/A' : $dss_preauth_status_labels[$row['vob']]);
  $patients[$i]['ledger'] = ($row['ledger'] == null ? 'N/A' : format_ledger($row['ledger']));
  $patients[$i]['device'] = ($row['device'] == null ? 'N/A' : $row['device']);
  $i++;
}

if (!$result) {
	$patients = array("error" => "Error: Could not select patients from database");
}

echo json_encode($patients);

?>
